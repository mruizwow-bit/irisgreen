# Decisiones y pendientes · Cielo 3D R02

Cada decisión con su motivo y su coste. Lo que queda abierto está al final, sin
disimular.

## 1. Canvas 2D con geometría 3D real, no WebGL

La cámara es una dirección de mirada y un campo de visión; cada estrella es una
dirección unitaria proyectada en perspectiva desde el centro de la esfera. Eso
es 3D de verdad: hay delante y detrás, el giro es continuo y lo que queda a la
espalda no se dibuja ni cuenta como observado. El dibujo se hace con canvas 2D.

**Por qué**: 1.660 estrellas y 3.731 puntos de nube no necesitan GPU —medido:
**1,2 ms por cuadro** a 1440×900—, y con esto el paquete se abre con doble clic
sin servidor, sin CDN y sin depender de WebGL. La orden pedía un mensaje
comprensible y una recuperación si WebGL fallara o se perdiera el contexto: al
no usar WebGL **no hay contexto que perder**, y no se promete ningún fallback
que no viaje. Si el navegador no pudiera abrir ni el lienzo 2D, se avisa y se
remite a la experiencia 2D existente.

**Coste**: con muchas más estrellas o efectos por píxel haría falta GPU. Para
este piloto no.

## 2. Sin horizonte

El paquete 2D dibuja un horizonte como referencia visual. Aquí no. Sin fecha,
hora ni lugar no existe una transformación coherente entre el cielo y un
horizonte real, y ponerlo sería decorado que además mentiría sobre qué se ve
desde dónde. Es una **vista celeste curada**, y así se dice en la portada.

**Consecuencia medible**: la evidencia sólo se pierde por quedar detrás de la
cámara, fuera de pantalla o tapada por la interfaz —y en este piloto nada se
dibuja encima del cielo, así que lo tercero no ocurre—. Cada examen registra
cuál de los tres motivos ha recortado la evidencia.

## 3. La vecina es Tauro, y por qué

Se eligió **leyendo el inventario**, no por gusto:

- Orión está en `campo-06`. El campo **más cercano** es `campo-03`, a 38,0° de
  su etiqueta; los demás están a 60° o más. Esa es la zona adyacente.
- Dentro de `campo-03`, las dos más cercanas a Orión son **Auriga** (24,0°) y
  **Tauro** (29,2°).
- Se elige Tauro porque la relación entre las dos está **medida**: el cinturón
  mide 2,73° con separaciones de 1,35° y 1,39° y una desviación de la recta de
  **0,088°**; prolongando esa recta se llega a **Aldebarán a 23,1°, con 5,27° de
  desviación**. La pista de la vecina no es una frase bonita: es esa medida.
- Y porque Tauro tiene un **subpatrón documentado con mínimo propio**: la V de
  las Híades, cinco estrellas unidas por el dibujo (Aldebarán, Chamukuy, Prima
  Hyadum, Secunda Hyadum, Ain) en 4,13°, de las que hacen falta **cuatro**.

**Lo que no se ha ocultado**: prolongando el cinturón hacia el otro lado se
llega a **Sirio** con sólo 2,61° de desviación —mejor alineación que Aldebarán—,
pero Sirio está en el **mismo campo** que Orión y no serviría para probar que
dos zonas se unen sin costura. Por eso la vecina es Tauro.

## 4. La evidencia es un cono del cielo, no un círculo de píxeles

- `TOLERANCIA_ENTRADA_PX` = 24 px: puntería. Sirve para acertar con el dedo y
  para decidir a cuál de dos patrones se apuntaba. **No aporta ni una estrella.**
- `EVIDENCIA.apertura_radio_grados` = 6° (12° de diámetro): la región del cielo
  que sustenta una identificación. En grados, así que el mismo punto con la
  misma orientación decide lo mismo a 320, 390 y 1440. Es también el contorno
  que se dibuja —muestreado y proyectado, exacto también fuera del centro, donde
  un cono no se ve como una circunferencia—: **lo que se ve es lo que cuenta**.
- **La apertura no cambia con el acercamiento.** Acercarse afina la puntería, no
  la regla. Es lo que hace que la decisión sea estable; conviene confirmar que
  también es lo que se espera al usarlo.

## 5. Mínimos semánticos

- Orión: sus **tres** estrellas del cinturón, observables y con su relación.
- Tauro: **cuatro de las cinco** Híades, seguidas.
- Las otras diez: el mayor trozo **seguido** del dibujo que de verdad cabe en la
  apertura, entre dos y tres puntos. Nunca uno.
- El mínimo **no se rebaja** porque parte de la figura quede oculta: si no hay
  bastante evidencia observable, no se identifica a nadie y se dice por qué.

## 6. El paso del teclado está acotado

5° por pulsación, por debajo del radio de la apertura (6°): orientando con
flechas no se puede cruzar por encima de un patrón sin llegar a examinarlo.
**Coste**: recorrer mucho cielo con teclado lleva más pulsaciones.

## 7. Nada se dibuja encima del cielo

Los controles alternativos (orientar, acercar, capa de hallazgos) van **debajo**
del lienzo, no flotando sobre él. Así la interfaz nunca tapa evidencia, y el
cielo se lee entero. **Coste**: en pantallas estrechas esos controles ocupan una
fila más, y el cielo baja al 53,5 % del viewport a 320 px.

## 8. Alcance deliberadamente corto

Dos zonas, doce constelaciones, dos figuras en el recorrido guiado. No hay
cuaderno, ni vista general, ni las 88. El piloto existe para responder una
pregunta —¿orientar un cielo continuo aporta?—, no para sustituir nada.

---

## Decisiones nuevas de R02

### El recorrido es un dato, no código

La interfaz ya no sabe qué constelaciones existen. Lee `orden_saltos` de los
datos y la pista de cada una de su campo `pista`. **Por qué**: porque el único
camino honesto hacia 88 es que escalar sea cambiar el fichero de datos. Mientras
hubiera una lista escrita en el programa, cada ampliación sería una reescritura.

**Coste**: el programa depende de que los datos estén bien formados. Se paga con
`U12` y `U13`, que vuelven a medir las separaciones declaradas y comprueban que
ninguna pista nombre su objetivo.

### La regla del árbol de saltos, declarada

`coste = separación angular + 12° × magnitud del ancla de destino`. No es el
árbol más corto: es el más seguible, porque se salta a lo que se ve. El primer
intento fue un árbol mínimo puro y empezaba Orión → Liebre: un salto corto hacia
estrellas tenues, es decir, un mal segundo paso. **La regla está en los datos**,
en `regla_orden_saltos`, para que se pueda discutir en vez de adivinar.

### La ambigüedad se queda sin resolver antes que resuelta mal

Si dos patrones empatan en evidencia, no se identifica ninguno. Se ofrecen como
opciones descritas por su sitio en el cielo —octante y separación angular, los
dos independientes de la pantalla—, nunca por su nombre, que sería el spoiler
que toda la experiencia evita. **Coste**: hay un estado más que explicar a quien
pulsa. Se paga con texto claro y con dos botones que dicen dónde, no qué.

### La marca del centro depende de la última entrada real

No del foco. Un `focus()` del programa no la enciende. **Por qué**: porque si el
centro se ilumina solo, la metáfora pasa a ser «lleva la cosa al centro», que es
exactamente lo que este diseño no quiere.

### El cuaderno devuelve la vista, no un encuadre nuevo

Volver a un hallazgo restaura la orientación y el campo que había cuando se
encontró. **Por qué**: porque el valor de haber encontrado algo mirando es poder
volver a mirar igual. Recalcular el encuadre sería otra cosa.

## Pendientes, sin maquillar

1. **Esta ampliación no la ha usado nadie todavía.** María probó el piloto R01 y
   eligió la dirección; eso no es HUMAN QA de R02. Ni teléfono físico, ni lector
   de pantalla, ni una persona que no supiera dónde está Orión.
   Las preguntas para HUMAN QA están en `MANTENER_Y_CAMBIAR.md`.
2. **Sólo Chromium.** Las pruebas son portables, pero no se han ejecutado en
   otro navegador.
3. **El táctil es emulado.** Los gestos van por eventos del navegador:
   reproducen la lógica, no un dedo real sobre cristal.
4. **La apertura fija con el zoom** es una decisión de diseño sin validar con
   personas.
5. **La Vía Láctea** se dibuja como nube de densidad muy tenue; a campos muy
   cerrados se nota poco. No se ha ajustado con criterio editorial.
6. **Un punto de figura sin estrella asociada** (de 141), declarado en el
   inventario.
7. **Rendimiento medido sólo aquí**: 1,2 ms por cuadro a 1440×900 con DPR 1 en
   un Chromium de escritorio emulado. En un móvil real no está medido.
8. **No se ha escalado a 88/88.** Qué está demostrado y qué falta medir está en
   `ESCALAR_A_88.md`.
9. **La ambigüedad no se puede provocar con estas 12.** Probada con cielo de
   prueba y con la respuesta del motor interceptada; no con constelaciones
   reales, porque no existe el caso. Está en `NOTAS_DE_PRUEBAS.md`, 3.1.
