/* Cielo 3D · piloto R01 · PRUEBAS UNITARIAS con fixtures.

   ALCANCE DECLARADO: funciones puras de geometría y evidencia, en Node, sin
   navegador y sin interfaz. Comprueban la convención de ejes contra
   coordenadas reales y la regla de identificación con casos construidos. NO
   dicen nada sobre la experiencia: eso está en pruebas/navegador.js.

   node pruebas/unitarias.js                                                  */
const path = require('path');
const fs = require('fs');
const E = require('../js/esfera.js');
const CFG = require('../js/config.js');

const res = [];
function reg(id, ok, nota) {
  res.push({ id, estado: ok ? 'OK' : 'FALLO', nota });
  console.log((ok ? '✔' : '✘') + ' ' + id + ': ' + nota);
}
/* Los datos reales se leen del propio paquete, no de una copia aparte. */
const src = fs.readFileSync(path.join(__dirname, '..', 'datos', 'cielo3d.js'), 'utf8');
const IG3D = JSON.parse(src.slice(src.indexOf('{"'), src.lastIndexOf(';')));
const cielo = E.construirCielo(IG3D);
const Ori = cielo.porAbbr.Ori, Tau = cielo.porAbbr.Tau;
const W = 1440, H = 648;

/* ===== U01 · convención de ejes contra coordenadas reales ================= */
{
  const bet = E.aDireccion(5.9195, 7.4071);     /* Betelgeuse, hombro superior */
  const rig = E.aDireccion(5.2423, -8.2016);    /* Rigel, pie */
  const cam = { ra: 5.58, dec: 0, fov: 45 };
  const sb = E.aPantalla(bet, cam, W, H), sr = E.aPantalla(rig, cam, W, H);
  const polo = E.aPantalla(E.aDireccion(0, 90), { ra: 5.58, dec: 45, fov: 90 }, W, H);
  const detras = E.aPantalla(E.aDireccion(17.58, 0), cam, W, H);
  reg('U01', sb.x < sr.x && sb.y < sr.y && polo.delante && polo.y < H / 2 && !detras.delante,
    'mirando desde dentro de la esfera, Betelgeuse queda arriba y a la izquierda de Rigel ' +
    `(${Math.round(sb.x)},${Math.round(sb.y)} frente a ${Math.round(sr.x)},${Math.round(sr.y)}), ` +
    'el polo norte celeste queda arriba y lo que está a 180° no se dibuja: el cielo no está en espejo');
}

/* ===== U02 · ida y vuelta pantalla ↔ dirección ============================ */
{
  let peor = 0;
  for (const cam of [{ ra: 5.5, dec: 0, fov: 60 }, { ra: 3.1, dec: 40, fov: 20 },
                     { ra: 23.5, dec: -30, fov: 90 }]) {
    for (const p of [{ x: 100, y: 80 }, { x: W / 2, y: H / 2 }, { x: W - 30, y: H - 20 }]) {
      const v = E.dePantalla(p, cam, W, H);
      const s = E.aPantalla(v, cam, W, H);
      peor = Math.max(peor, Math.hypot(s.x - p.x, s.y - p.y));
    }
  }
  reg('U02', peor < 1e-6, `proyectar y deshacer la proyección devuelve el mismo píxel en 9 casos ` +
    `(error máximo ${peor.toExponential(1)} px)`);
}

/* ===== U03 · la apertura es angular y no depende de la pantalla =========== */
{
  const dir = Ori.puntos[Ori.especial.indices[1]].v;
  const cam = { ra: E.aCoordenadas(dir).ra, dec: E.aCoordenadas(dir).dec, fov: 50 };
  const medidas = [[320, 420], [390, 596], [1440, 648]].map(([w, h]) => {
    const p = E.aPantalla(dir, cam, w, h);
    const r = E.examinar(cielo, cam, w, h, [], p, {});
    return { w, h, ap: r.apertura_grados, dentro: r.detalle.filter(d => d.dentro > 0)
      .map(d => d.abbr + ':' + d.dentro).sort().join(','), res: r.resultado,
      mejor: r.mejor && r.mejor.abbr };
  });
  const iguales = new Set(medidas.map(m => m.ap + '|' + m.dentro + '|' + m.res + '|' + m.mejor)).size === 1;
  reg('U03', iguales, 'misma dirección del cielo y misma orientación a 320, 390 y 1440: misma apertura ' +
    `(${medidas[0].ap}° de diámetro), misma evidencia (${medidas[0].dentro}) y misma decisión ` +
    `(${medidas[0].res}/${medidas[0].mejor})`);
}

/* ===== U04 · el cinturón exige sus tres estrellas ========================= */
{
  const idx = Ori.especial.indices;
  const dir = Ori.puntos[idx[1]].v;
  const c = E.aCoordenadas(dir);
  const cam = { ra: c.ra, dec: c.dec, fov: 30 };
  const centro = E.aPantalla(dir, cam, W, H);
  const tapar = n => {
    const zonas = [];
    for (let i = 0; i < n; i++) {
      const s = E.aPantalla(Ori.puntos[idx[i]].v, cam, W, H);
      zonas.push({ x: s.x - 10, y: s.y - 10, w: 20, h: 20 });
    }
    const r = E.examinar(cielo, cam, W, H, zonas, centro, {});
    const d = r.detalle.find(x => x.abbr === 'Ori');
    return { res: r.resultado, mejor: r.mejor && r.mejor.abbr, dentro: d.dentro,
             visibles: d.visibles, minimo: d.minimo_semantico, recorte: r.recorte };
  };
  const tres = tapar(0), dos = tapar(1), una = tapar(2);
  reg('U04', tres.mejor === 'Ori' && !dos.mejor && !una.mejor,
    `3/3 identifica Orión; 2/3 da «${dos.res}» (dentro ${dos.dentro}, mínimo ${dos.minimo}) y 1/3 da ` +
    `«${una.res}» (dentro ${una.dentro}). Ocultar estrellas NO rebaja el mínimo, y el recorte queda ` +
    `registrado: ${JSON.stringify(dos.recorte)}`);
}

/* ===== U05 · la vecina tiene su propio mínimo documentado ================= */
{
  const idx = Tau.especial.indices;
  let s = { x: 0, y: 0, z: 0 };
  idx.forEach(i => { s.x += Tau.puntos[i].v.x; s.y += Tau.puntos[i].v.y; s.z += Tau.puntos[i].v.z; });
  const dir = E.unitario(s), c = E.aCoordenadas(dir);
  const cam = { ra: c.ra, dec: c.dec, fov: 30 };
  const centro = E.aPantalla(dir, cam, W, H);
  const todo = E.examinar(cielo, cam, W, H, [], centro, {});
  const d = todo.detalle.find(x => x.abbr === 'Tau');
  /* tapando dos de las cinco baja de su mínimo de cuatro */
  const zonas = idx.slice(0, 2).map(i => {
    const p = E.aPantalla(Tau.puntos[i].v, cam, W, H);
    return { x: p.x - 10, y: p.y - 10, w: 20, h: 20 };
  });
  const corto = E.examinar(cielo, cam, W, H, zonas, centro, {});
  reg('U05', todo.mejor && todo.mejor.abbr === 'Tau' && d.minimo_semantico === 4 && !corto.coincide,
    `las Híades piden 4 de sus 5 estrellas seguidas (mínimo ${d.minimo_semantico}, extensión ` +
    `${Tau.especial.extension_grados}°): con las cinco visibles identifica Tauro; tapando dos, «${corto.resultado}»`);
}

/* ===== U06 · la escasez de evidencia no se normaliza a 100 % ============== */
{
  /* Caso construido: una figura de tres puntos de la que sólo se ve uno.
     Aunque ese uno esté dentro y sea el 100 % de lo visible, no identifica. */
  const base = { ra: 0, dec: 0 };
  const falsa = {
    schema: 'fixture', estrellas: [[0, 0, 2, 0.1, null], [0, 2, 2, 0.1, null], [0, 4, 2, 0.1, null]],
    via_lactea: [],
    constelaciones: [{ abbr: 'XXX', zona: 'fixture', latin: 'X', genitivo: 'X',
      nombre_es: 'X', nombre_en: 'X', etiqueta: [0, 2],
      puntos: [[0, 0, 0], [0, 2, 1], [0, 4, 2]], aristas: [[0, 1], [1, 2]] }]
  };
  const f = E.construirCielo(falsa);
  const dir = f.porAbbr.XXX.puntos[0].v, c = E.aCoordenadas(dir);
  const cam = { ra: c.ra, dec: c.dec + 2, fov: 40 };   /* los tres caben en la zona */
  const centro = E.aPantalla(dir, cam, W, H);
  const zonas = [1, 2].map(i => {
    const s = E.aPantalla(f.porAbbr.XXX.puntos[i].v, cam, W, H);
    return { x: s.x - 9, y: s.y - 9, w: 18, h: 18 };
  });
  const r = E.examinar(f, cam, W, H, zonas, centro, {});
  const d = r.detalle[0];
  reg('U06', !r.coincide && d.dentro === 1 && d.visibles === 1,
    `con sólo 1 de 3 puntos observable y dentro de la zona, la proporción visible sería del 100 % y aun ` +
    `así el resultado es «${r.resultado}»: el mínimo del patrón no se rebaja por no ver el resto`);
}

/* ===== U07 · nada de lo que está detrás de la cámara cuenta =============== */
{
  const dir = Ori.puntos[Ori.especial.indices[1]].v, c = E.aCoordenadas(dir);
  const mirandoAlOtroLado = { ra: (c.ra + 12) % 24, dec: -c.dec, fov: 60 };
  const r = E.examinar(cielo, mirandoAlOtroLado, W, H, [], E.centroVista(W, H), {});
  const d = r.detalle.find(x => x.abbr === 'Ori');
  reg('U07', !r.coincide && d.visibles === 0 && d.ocultos.detras_de_la_camara === d.total,
    `mirando al punto opuesto del cielo, las ${d.total} estrellas del cinturón quedan detrás de la cámara, ` +
    `no cuentan como observadas (${d.ocultos.detras_de_la_camara}) y el resultado es «${r.resultado}»`);
}

/* ===== U08 · el paso de teclado no puede saltarse un patrón =============== */
{
  const paso = CFG.PASO_TECLADO_GRADOS, radio = E.aperturaRadioGrados();
  reg('U08', paso <= radio,
    `el paso de las flechas (${paso}°) no supera el radio de la región de evidencia (${radio}°): ` +
    'orientando con teclado no se puede cruzar por encima de un patrón sin examinarlo');
}

/* ===== U09 · ampliar conserva el punto señalado =========================== */
{
  let peor = 0;
  const cam = { ra: 5.5, dec: 0, fov: 60 };
  for (const p of [{ x: 300, y: 150 }, { x: 1100, y: 500 }, { x: W / 2, y: H / 2 }]) {
    const dir = E.dePantalla(p, cam, W, H);
    for (const fov of [30, 15, 80]) {
      const nueva = E.camaraAmpliada(cam, W, H, fov, p);
      const s = E.aPantalla(dir, nueva, W, H);
      peor = Math.max(peor, Math.hypot(s.x - p.x, s.y - p.y));
    }
  }
  reg('U09', peor < 1.0, `ampliar alrededor de un punto lo deja donde estaba en 9 casos ` +
    `(desplazamiento máximo ${peor.toFixed(3)} px), no se amplía por el centro de la pantalla`);
}

/* ===== U10 · dos zonas, un solo cielo, sin duplicados ==================== */
{
  const vistas = new Map();
  let dup = 0;
  cielo.estrellas.forEach(e => {
    const k = e.ra.toFixed(4) + '|' + e.dec.toFixed(4);
    if (vistas.has(k)) dup++;
    vistas.set(k, true);
  });
  const zonas = {};
  cielo.constelaciones.forEach(k => { zonas[k.zona] = (zonas[k.zona] || 0) + 1; });
  /* Ninguna constelación aparece dos veces, y las dos zonas comparten el mismo
     catálogo: no hay costura porque no hay dos cielos. */
  const abbrs = cielo.constelaciones.map(k => k.abbr);
  const repes = abbrs.filter((a, i) => abbrs.indexOf(a) !== i);
  reg('U10', dup === 0 && repes.length === 0 && Object.keys(zonas).length === 2,
    `${cielo.estrellas.length} estrellas de un solo catálogo, 0 duplicadas; ${abbrs.length} constelaciones ` +
    `repartidas en ${Object.keys(zonas).length} zonas (${JSON.stringify(zonas)}) y ninguna repetida`);
}

/* ===== U11 · la relación entre las dos zonas está medida ================== */
{
  const rel = Tau.relacion;
  const cint = Ori.especial;
  reg('U11', rel && rel.separacion_grados > 20 && rel.separacion_grados < 26 &&
    cint.extension_grados < 3 && cint.desviacion_de_la_linea_grados < 0.2,
    `el cinturón mide ${cint.extension_grados}° con separaciones de ${cint.separaciones_grados.join('° y ')}° y ` +
    `una desviación de la recta de ${cint.desviacion_de_la_linea_grados}°; prolongado llega a Aldebarán a ` +
    `${rel.separacion_grados}° con ${rel.desviacion_de_la_linea_del_cinturon_grados}° de desviación. ` +
    'La pista de la vecina no es una frase bonita: es esa medida');
}

/* ===== U12 · el recorrido es un grafo de vecinas REAL, medido ============= */
{
  const via = cielo.meta.orden_saltos;
  const vistas = new Set();
  const errores = [];
  let maxSalto = 0;
  via.forEach((a, i) => {
    const k = cielo.porAbbr[a];
    if (!k) { errores.push(a + ': no está en el catálogo'); return; }
    if (i === 0) {
      if (k.salto) errores.push(a + ': la raíz no debería tener salto');
    } else {
      const s = k.salto;
      if (!s) { errores.push(a + ': sin salto medido'); vistas.add(a); return; }
      /* El salto sale de una constelación que YA se ha visitado: sin eso no es
         star-hopping, es teletransporte. */
      if (!vistas.has(s.desde)) errores.push(a + ': salta desde ' + s.desde + ', que aún no se ha visto');
      /* La separación declarada se vuelve a medir sobre el catálogo. */
      const d = cielo.porAbbr[s.desde], anclaA = d.ancla, anclaB = k.ancla;
      const va = d.puntos[anclaA.punto_indice].v, vb = k.puntos[anclaB.punto_indice].v;
      const medido = E.anguloEntre(va, vb);
      if (Math.abs(medido - s.separacion_grados) > 0.1) {
        errores.push(a + ': declara ' + s.separacion_grados + '° y mide ' + medido.toFixed(1) + '°');
      }
      /* Un salto que no se puede abarcar con la vista no sirve de pista. */
      if (medido > 40) errores.push(a + ': salto de ' + medido.toFixed(1) + '°, demasiado largo para seguirlo');
      maxSalto = Math.max(maxSalto, medido);
      /* La dirección declarada es la que se ve: se comprueba contra la pantalla. */
      const cam = E.ajustarCamara({ ...E.aCoordenadas(va), fov: 60 });
      const pa = E.aPantalla(va, cam, W, H), pb = E.aPantalla(vb, cam, W, H);
      const oct = E.octanteCeleste(va, vb);
      if (pa.delante && pb.delante) {
        if (oct.indexOf('arriba') >= 0 && pb.y >= pa.y) errores.push(a + ': dice «' + oct + '» y en pantalla baja');
        if (oct.indexOf('abajo') >= 0 && pb.y <= pa.y) errores.push(a + ': dice «' + oct + '» y en pantalla sube');
        if (oct.indexOf('izquierda') >= 0 && pb.x >= pa.x) errores.push(a + ': dice «' + oct + '» y va a la derecha');
        if (oct.indexOf('derecha') >= 0 && pb.x <= pa.x) errores.push(a + ': dice «' + oct + '» y va a la izquierda');
      }
    }
    vistas.add(a);
  });
  const todas = cielo.constelaciones.map(k => k.abbr).sort().join(',');
  const cubre = via.slice().sort().join(',') === todas;
  reg('U12', errores.length === 0 && cubre && via.length >= 8,
    errores.length ? errores.join(' · ')
      : `${via.length} constelaciones encadenadas por saltos medidos (${via.join('→')}); cada salto parte de una ya ` +
        `vista, ninguno pasa de 40° (el mayor mide ${maxSalto.toFixed(1)}°) y la dirección que declara —arriba, abajo, ` +
        'izquierda, derecha— es la que se ve en pantalla. El recorrido cubre las 12 sin repetir');
}

/* ===== U13 · ninguna pista nombra lo que hay que encontrar ================ */
{
  const fallos = [];
  cielo.constelaciones.forEach(k => {
    const q = k.pista;
    if (!q) { fallos.push(k.abbr + ': sin pista'); return; }
    const textos = [q.es, q.en, q.sin_ancla_es, q.sin_ancla_en].filter(Boolean);
    /* Nombres propios del objetivo: los suyos y los de SUS estrellas. */
    const prohibidas = [k.nombre_es, k.nombre_en, k.latin, k.genitivo];
    if (k.ancla) prohibidas.push(k.ancla.estrella);
    k.puntos.forEach(p => {
      const e = p.estrella === null || p.estrella === undefined ? null : cielo.estrellas[p.estrella];
      if (e && e.datos && e.datos.n) prohibidas.push(e.datos.n);
    });
    textos.forEach(txt => {
      prohibidas.filter(Boolean).forEach(n => {
        if (txt.toLowerCase().indexOf(String(n).toLowerCase()) >= 0) {
          fallos.push(k.abbr + ': la pista dice «' + n + '»');
        }
      });
      /* Tampoco se cita una magnitud: es un número del catálogo, no algo que
         se vea. «mucho más clara que las demás» sí se ve. */
      if (/magnitud|magnitude|\bmag\b/i.test(txt)) fallos.push(k.abbr + ': la pista cita una magnitud');
      if (q.nombra_objetivo !== false) fallos.push(k.abbr + ': no declara que no nombra el objetivo');
    });
    /* La pista de salto cita la estrella de DONDE se viene, que ya se conoce. */
    if (q.tipo === 'salto') {
      const desde = cielo.porAbbr[q.ancla];
      if (!desde || q.es.indexOf(k.salto.desde_estrella) < 0) {
        fallos.push(k.abbr + ': la pista de salto no cita el ancla de partida');
      }
      if (q.sin_ancla_es.indexOf(k.salto.desde_estrella) >= 0) {
        fallos.push(k.abbr + ': la pista de respaldo cita una estrella que aún no se conoce');
      }
    }
  });
  reg('U13', fallos.length === 0,
    fallos.length ? fallos.slice(0, 6).join(' · ')
      : '12 de 12 pistas describen forma, relación y brillo relativo sin nombrar su objetivo, sin nombrar ninguna de ' +
        'sus estrellas y sin citar magnitudes; la pista de salto sólo nombra la estrella de la que se parte, y su ' +
        'respaldo —cuando ese patrón todavía no se ha encontrado— no nombra ninguna');
}

/* ===== U14 · la ambigüedad NO se resuelve con píxeles ===================== */
{
  /* Dos figuras cruzadas con la misma evidencia en la misma zona del cielo:
     ninguna gana. Antes se desempataba por distancia en píxeles al punto
     pulsado, y eso cambiaba con el ancho de la pantalla. */
  const c = { ra: 6, dec: 0, fov: 60 };
  /* El cielo de prueba se construye con construirCielo, igual que el real: así
     sus puntos son observables de verdad —tienen estrella dibujada— y no pasan
     por la puerta de atrás del motor. */
  const estrellasF = [], consF = [];
  [['AAA', -0.08], ['BBB', 0.08]].forEach(([abbr, dra]) => {
    const base0 = estrellasF.length;
    const pts = [[6 + dra, -1.2], [6 + dra + 0.15, 0], [6 + dra - 0.15, 1.2]];
    pts.forEach(q => estrellasF.push([q[0], q[1], 2.0, 0.1, null]));
    consF.push({ abbr, zona: 'prueba', latin: abbr, genitivo: abbr,
                 nombre_es: abbr, nombre_en: abbr, etiqueta: [6 + dra, 0],
                 puntos: pts.map((q, i) => [q[0], q[1], base0 + i]),
                 aristas: [[0, 1], [1, 2]] });
  });
  const falso = E.construirCielo({ schema: 'fixture', estrellas: estrellasF,
                                   via_lactea: [], constelaciones: consF });
  const anchos = [[320, 568], [390, 844], [1440, 900]];
  const firmas = anchos.map(([w, h]) => {
    const r = E.examinar(falso, c, w, h, [], { x: w / 2, y: h / 2 }, {});
    return r.resultado + '|' + (r.mejor ? r.mejor.abbr : '-') + '|' +
      r.plausibles.map(p => p.abbr + '@' + p.octante).sort().join(',');
  });
  const unica = firmas.every(f => f === firmas[0]);
  const noRevela = firmas[0].indexOf('ambiguo|-') === 0;
  const dos = firmas[0].split('|')[2].split(',').length === 2;
  reg('U14', unica && noRevela && dos,
    `dos patrones con la misma evidencia en la misma zona: a 320, 390 y 1440 la decisión es idéntica (${firmas[0]}). ` +
    'No se identifica ninguno y se devuelven los dos candidatos descritos por su sitio en el cielo, no por píxeles');
}

/* ===== U15 · las 12 son alcanzables, y con la misma decisión en 3 anchos == */
{
  /* La misma prueba que hizo falta para llegar a 88/88 en 2D: puntos de
     puntería «humanos» —centros de trozos seguidos y medios de los trazos—
     en lugar de un centro geométrico que a veces cae fuera de la figura. */
  function candidatos(k) {
    const ps = [];
    const n = k.puntos.length;
    for (let i = 0; i < n; i++) {
      for (let j = 0; j < n; j++) {
        if (i === j) continue;
        const s = { x: k.puntos[i].v.x + k.puntos[j].v.x, y: k.puntos[i].v.y + k.puntos[j].v.y,
                    z: k.puntos[i].v.z + k.puntos[j].v.z };
        ps.push(E.unitario(s));
      }
    }
    k.puntos.forEach(p => ps.push(p.v));
    ps.push(k.etiqueta);
    return ps;
  }
  const anchos = [[320, 568], [390, 844], [1440, 900]];
  const malas = [];
  let probados = 0;
  cielo.constelaciones.forEach(k => {
    let ok = false;
    for (const v of candidatos(k)) {
      const cam = E.ajustarCamara({ ...E.aCoordenadas(v), fov: 45 });
      const firmas = anchos.map(([w, h]) => {
        const r = E.examinar(cielo, cam, w, h, [], { x: w / 2, y: h / 2 }, {});
        return r.resultado + '|' + (r.mejor ? r.mejor.abbr : '-');
      });
      probados++;
      if (firmas.every(f => f === 'unico|' + k.abbr)) { ok = true; break; }
    }
    if (!ok) malas.push(k.abbr);
  });
  reg('U15', malas.length === 0,
    malas.length ? 'sin punto de puntería válido en los tres anchos: ' + malas.join(', ')
      : `las 12 constelaciones del recorrido se identifican desde un punto de puntería razonable, y la decisión es ` +
        `la MISMA a 320, 390 y 1440 (${probados} punterías probadas). Ninguna depende del tamaño de la pantalla`);
}

/* ===== U16 · VISIBLE_RENDERED_POINTS_ONLY_ORACLE ========================= */
{
  /* P1-01. Un punto de figura que el cielo no dibuja no puede sostener nada.
     Este oráculo falla si un punto con estrella=null cuenta, si contribuye al
     mínimo, o si aparece en el conjunto que la interfaz marcará en pantalla. */
  const fallos = [];
  const dibujadas = new Set(cielo.estrellas.map(e => e.i));
  let sinEstrella = 0, revisados = 0;

  cielo.constelaciones.forEach(k => {
    k.puntos.forEach((q, i) => {
      revisados++;
      const tieneEstrella = q.estrella !== null && q.estrella !== undefined;
      if (!tieneEstrella) sinEstrella++;
      if (q.observable !== tieneEstrella) {
        fallos.push(`${k.abbr}#${i}: observable=${q.observable} con estrella=${q.estrella}`);
      }
      /* lo observable tiene que estar REALMENTE entre lo que se dibuja */
      if (tieneEstrella && !dibujadas.has(q.estrella)) {
        fallos.push(`${k.abbr}#${i}: apunta a la estrella ${q.estrella}, que no está en el catálogo dibujado`);
      }
      /* la adyacencia de evidencia no puentea por encima de un punto no dibujado */
      (k.vecinosObs[i] || []).forEach(j => {
        if (!k.puntos[j].observable) fallos.push(`${k.abbr}: ${i}–${j} une con un punto no dibujado`);
        if ((k.vecinos[i] || []).indexOf(j) < 0) fallos.push(`${k.abbr}: ${i}–${j} no es una arista de la figura`);
      });
      if (!q.observable && (k.vecinosObs[i] || []).length) {
        fallos.push(`${k.abbr}#${i}: un punto no dibujado conserva vecinos de evidencia`);
      }
    });
    /* el mínimo alcanzable se calcula sobre lo observable, no sobre la figura */
    const soloObs = { puntos: k.puntos, vecinos: k.vecinosObs, vecinosObs: k.vecinosObs };
    if (E.trozoQueCabe(k) !== E.trozoQueCabe(soloObs)) {
      fallos.push(`${k.abbr}: el trozo que cabe no coincide con el calculado sólo sobre observables`);
    }
    /* y la declaración en los datos cuadra con lo que hace el motor */
    const dato = (cielo.meta.constelaciones.filter(x => x.abbr === k.abbr)[0] || {}).puntos_no_observables || [];
    if (dato.length !== k.no_observables) {
      fallos.push(`${k.abbr}: declara ${dato.length} puntos no observables y el motor cuenta ${k.no_observables}`);
    }
    dato.forEach(d => {
      if (k.puntos[d.indice].observable) fallos.push(`${k.abbr}#${d.indice}: declarado no observable pero cuenta`);
      if (!d.motivo) fallos.push(`${k.abbr}#${d.indice}: exclusión sin motivo declarado`);
    });
  });

  /* y, barriendo el cielo, NINGUNA decisión puede apoyarse en un punto no dibujado */
  let decisiones = 0;
  for (let ra = 0; ra < 24; ra += 0.25) {
    for (let dec = -40; dec <= 70; dec += 5) {
      const cam = E.ajustarCamara({ ra, dec, fov: 45 });
      const r = E.examinar(cielo, cam, W, H, [], { x: W / 2, y: H / 2 }, {});
      r.detalle.forEach(d => {
        d.puntos_dentro.forEach(q => {
          if (!q.observable) fallos.push(`evidencia con punto no dibujado en ${d.abbr} (AR ${ra}h, Dec ${dec}°)`);
        });
      });
      if (r.coincide) decisiones++;
    }
  }
  reg('U16', fallos.length === 0 && sinEstrella === 1,
    fallos.length ? fallos.slice(0, 5).join(' · ')
      : `${revisados} puntos de figura revisados: ${sinEstrella} no tiene estrella dibujada y queda fuera de toda ` +
        `evidencia —no cuenta, no suma al mínimo, no entra en el trozo seguido y la adyacencia no lo puentea—. ` +
        `Barriendo el cielo (${decisiones} identificaciones), ningún punto no dibujado sostiene ninguna decisión`);
}

/* ===== U17 · el caso exacto de Axioma sobre Perseo ======================== */
{
  /* Axioma: cámara AR 2,58 h, Dec +38,2°, FOV 45°, pulsación en el centro →
     antes decía «unico → Per» con puntos [15,16,17] y asociaciones
     [105,556,null]. El punto 17 es el vértice que no se dibuja. */
  const cam = E.ajustarCamara({ ra: 2.58, dec: 38.2, fov: 45 });
  const r = E.examinar(cielo, cam, W, H, [], { x: W / 2, y: H / 2 }, {});
  const per = cielo.porAbbr.Per;
  const d = r.detalle.filter(x => x.abbr === 'Per')[0];
  const idx = d.puntos_dentro.map(q => per.puntos.indexOf(q));
  const p17 = per.puntos[17];
  const noObs = (cielo.meta.constelaciones.filter(x => x.abbr === 'Per')[0] || {}).puntos_no_observables || [];
  const laEstrella = noObs.length ? noObs[0].estrella_en_catalogo : null;
  reg('U17', r.resultado === 'ninguno' && !r.coincide && d.dentro === 2 &&
    d.minimo_semantico === 3 && idx.join(',') === '15,16' && !p17.observable &&
    d.ocultos.no_renderizados === 1 && !!laEstrella && laEstrella.magnitud > cielo.meta.magnitud_limite,
    `el caso de Axioma ya no identifica nada: quedan ${d.dentro} puntos observables [${idx.join(',')}] frente a un ` +
    `mínimo de ${d.minimo_semantico}, y el vértice 17 (AR ${p17.ra} h, Dec ${p17.dec}°) queda declarado fuera ` +
    `porque su estrella —${laEstrella.designacion}, magnitud ${laEstrella.magnitud}— está por debajo de la ` +
    `magnitud límite del paquete (${cielo.meta.magnitud_limite}) y no se dibuja. No se ha tocado ningún master: ` +
    'la figura sigue teniendo sus 23 vértices y sus 23 aristas');
}

/* ===== U18 · P2: la raíz de entrada sale de los datos, sin cambiar nada ==== */
{
  /* La interfaz ya no nombra a Orión para decidir por dónde se entra: usa la
     raíz del recorrido. Con los datos actuales esa raíz ES Orión, así que la
     cámara de entrada tiene que salir IDÉNTICA a la de R02. Si algún día la
     raíz cambia, cambiará la entrada —y esta prueba lo dirá. */
  const raiz = cielo.meta.orden_saltos[0];
  const k = cielo.porAbbr[raiz];
  const comoR02 = (() => {
    const o = cielo.porAbbr.Ori;
    const c = E.aCoordenadas(o.puntos[o.especial.indices[1]].v);
    return E.ajustarCamara({ ra: (c.ra + 1.35 + 24) % 24, dec: c.dec + 15, fov: CFG.CAMPO_VISION.inicial });
  })();
  const ref = k.especial ? k.puntos[k.especial.indices[Math.floor(k.especial.indices.length / 2)]]
                         : (k.ancla ? k.puntos[k.ancla.punto_indice] : k.puntos[0]);
  const c2 = E.aCoordenadas(ref.v);
  const ahora = E.ajustarCamara({ ra: (c2.ra + 1.35 + 24) % 24, dec: c2.dec + 15,
                                  fov: CFG.CAMPO_VISION.inicial });
  const iguales = ['ra', 'dec', 'fov'].every(x => Math.abs(comoR02[x] - ahora[x]) < 1e-12);
  /* y la entrada NO centra el patrón: hay que buscarlo */
  const dir = E.aDireccion(ahora.ra, ahora.dec);
  const sep = E.anguloEntre(dir, ref.v);
  reg('U18', raiz === 'Ori' && iguales && sep > E.aperturaRadioGrados(),
    `la raíz de entrada sale de orden_saltos (${raiz}) en vez de estar escrita en la interfaz, y la cámara ` +
    `resultante es idéntica a la de R02 (${iguales}): AR ${ahora.ra.toFixed(4)} h, Dec ${ahora.dec}°, ` +
    `${ahora.fov}°. Sigue entrando a ${sep.toFixed(1)}° del patrón —más que el radio de la zona de examen ` +
    `(${E.aperturaRadioGrados()}°)—, así que hay que buscarlo igual que antes`);
}

fs.writeFileSync(path.join(__dirname, 'resultados-unitarias.json'), JSON.stringify(res, null, 2));
const fallos = res.filter(r => r.estado === 'FALLO').length;
console.log(`\n=== UNITARIAS: ${res.length} comprobaciones del autor · ${fallos} fallos ===`);
console.log('Funciones puras, sin navegador. No dicen nada sobre la experiencia.');
if (fallos) process.exitCode = 1;
