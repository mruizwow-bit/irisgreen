# KEEP / CHANGE · Cielo 3D R02.1

2026-10-07. Lo que conviene conservar, lo que habría que cambiar y lo que queda
pendiente. Sin adornos: esto es para que Nexo y Axioma decidan.

## 1. KEEP · conservar

| Qué | Por qué |
|---|---|
| Esfera celeste con observador fijo, cámara `{ra, dec, fov}` | Nada de vuelo, nada de roll. Es la decisión que hizo que el 3D se entendiera |
| Canvas 2D con matemática 3D real | No hay contexto que perder ni fallback prometido que no se entregue. 5.391 dibujables a ~1 ms/cuadro |
| Tolerancia de entrada separada de la evidencia angular | Es la corrección que arregló la dependencia del viewport. No volver a mezclarlas |
| Mínimo semántico derivado de la figura | Ocultar evidencia no rebaja lo que hace falta para nombrar algo |
| Ambigüedad sin resolver antes que resuelta mal | Y las opciones descritas por su sitio, nunca por su nombre |
| Pulsar donde se mira como interacción principal | El centro es apoyo del teclado, no la metáfora |
| Recorrido y pistas en los datos | La interfaz no sabe qué constelaciones existen. Por eso escalar es cambiar datos |
| Cuaderno que devuelve la vista original | Volver a donde encontraste algo, no a un encuadre recalculado |
| Ficha al lado que no tapa el hallazgo | Y el cielo arriba en pantalla estrecha |
| Datos locales, sin CDN, abriendo con `file://` | Funciona sin red y sin servidor |
| Ausencia de datos = `null` + motivo | Nunca un valor inventado para rellenar una ficha |
| Evidencia sólo de puntos que se dibujan | Un vértice sin estrella visible no identifica nada, y la adyacencia no lo puentea (R02.1) |
| Guardado de versión futura intacto | Lo que no se entiende no se destruye: sólo lectura y aviso (R02.1) |

## 2. CHANGE · cambiar o decidir

| Qué | Propuesta |
|---|---|
| El recorrido sugerido es una cadena de 12 pasos | A 88 no sirve una cadena. Hay que decidir agrupación (estación, región, ruta corta). **Decisión de producto** |
| El cono de evidencia es fijo: 6° de radio | A 88 habrá que medir cuántos puntos del cielo quedan ambiguos. Si son muchos, lo que hay que revisar es la apertura, no el mínimo |
| `convencion_distancias` usa el puño a brazo estirado | Es una costumbre observacional, declarada como tal. Si Axioma prefiere sólo grados, es un cambio de una línea en el generador |
| Las direcciones de las pistas son octantes de pantalla | Funciona con el norte celeste arriba. Si algún día el cielo pudiera inclinarse, esto habría que recalcular en vivo |
| La capa de hallazgos se enciende a mano | Con 88 encendida entera puede ser ruido. Habría que probar si conviene limitarla a la región visible |
| El cuaderno lista todo en una columna | Con 88 pide agrupación y, probablemente, un buscador |
| Las zonas del catálogo (`campo-03`, `campo-06`) siguen en los datos | No se ven en la interfaz y no deberían existir cuando el cielo sea uno solo. Son herencia del paquete 2D |
| El desvío de entrada (+1,35 h, +15°) es una constante en la interfaz | La raíz ya sale de `orden_saltos` (P2 hecho); el desvío debería pasar a los datos antes de 88/88 |
| Un guardado de versión ANTERIOR se sigue sobrescribiendo | No hay migración. Si alguna vez se define una, aquí es donde entra |

## 3. Pendientes declarados

1. **Ambigüedad real**: no se puede provocar con 12 constelaciones. Probada con
   cielo de prueba (`U14`) y con la respuesta del motor interceptada en la página
   (`N15`). Con 88 hay que barrer el cielo y medirla de verdad.
2. **Prueba táctil en teléfono físico**: no hecha. Los gestos van por CDP.
3. **Prueba con lector de pantalla real**: no hecha. Es de Axioma.
4. **Figuras que no caben en la apertura** (Hidra, Eridano, Serpiente): no
   probadas, porque no están en esta región.
5. **Peso del paquete y primera carga de ficha a 88**: sin medir.
6. **Rendimiento con el catálogo completo** (del orden de 5.000–6.000 estrellas a
   magnitud 5,6): sin medir. Aquí hay 1.660.
7. **El ancla de las pistas de salto no está etiquetada en el cielo.** «Desde
   Rigel…» exige que la persona sepa cuál es Rigel. La ficha lo presenta; el
   cielo no lo señala. Es la pregunta concreta de HUMAN QA, y a propósito **no**
   se ha resuelto por adelantado con etiquetas permanentes.
8. **Vértices sin estrella a escala 88**: aquí hay uno y está declarado; cuántos
   hay en las 88 está sin medir.
9. **B16**: este paquete no distribuye ningún asset nuevo ni reintroduce el
   sustituto revocado. Los 12 SVG que trae son los aprobados del paquete 2D y
   no hay ninguna referencia a B16 en el código, los datos ni los assets. La
   referencia de exclusión se conserva donde ya estaba, en el paquete 2D.
8. **El vídeo de 390 px no es un teléfono**: es Chromium con el recuadro a ese
   tamaño, y así se declara en `video/RECORRIDO.json`.
