# Alcance R03 · bloque Cielo nocturno

Contrato:
`EXPLORE → LOCATE → REVEAL`

## KEEP de R02.1

- observador fijo;
- esfera continua;
- drag / touch / teclado;
- zoom;
- selección donde se señala;
- evidencia angular de 6°;
- tolerancia motora separada;
- ambigüedad no resuelta por píxeles;
- revelado progresivo;
- cuaderno y retorno espacial;
- forward-compatible storage.

## Cambio R03

- 12 → 88 constelaciones;
- 1.660 → 3.248 estrellas al mismo límite 5,6;
- dos zonas → esfera global;
- cadena única → rutas humanas + libre + seguir desde aquí;
- entrada completa pasa a datos;
- procedencia R03 reconciliada;
- ambigüedad 88 medida.

## No cambia

Las constelaciones siguen siendo patrones angulares.
No se extruyen ni se convierten en objetos sólidos.

Los siguientes cuerpos físicos sí usarán volumen 3D real.
