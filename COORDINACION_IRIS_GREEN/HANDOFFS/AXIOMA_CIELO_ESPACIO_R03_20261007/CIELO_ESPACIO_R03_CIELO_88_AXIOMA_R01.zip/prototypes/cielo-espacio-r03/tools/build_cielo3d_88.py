#!/usr/bin/env python3
"""Build Cielo 3D R03 data: 88 constellations on one continuous celestial sphere."""
from __future__ import annotations
import argparse, json, math, re, hashlib
from pathlib import Path
from collections import defaultdict

MAG_LIMIT = 5.6
MATCH_LIMIT_DEG = 0.05
R02_1_SHA = "1f7e6ac7aab0b56d88b880375049a621bb85d9e0bc74105366f1d71073423ba8"
PIPELINE_R03_SHA = "6606430fcc0cf732bb794d8d582bcb31b3e643ac76c96e241c74a8418264df47"

def clamp(x,a,b): return max(a,min(b,x))
def ang(ra1, dec1, ra2, dec2):
    a1=math.radians(ra1*15.0); a2=math.radians(ra2*15.0)
    d1=math.radians(dec1); d2=math.radians(dec2)
    c=math.sin(d1)*math.sin(d2)+math.cos(d1)*math.cos(d2)*math.cos(a1-a2)
    return math.degrees(math.acos(clamp(c,-1,1)))

def load_js_obj(path: Path, name: str):
    t=path.read_text(encoding="utf-8")
    m=re.search(rf"{re.escape(name)}\s*=\s*(\{{.*\}});\s*$", t, re.S)
    if not m: raise RuntimeError(f"No JS assignment {name} in {path}")
    return json.loads(m.group(1))

def compact_star(s):
    return [s[0],s[1],s[2],s[3],{"con":s[4],"d":s[5],"n":s[6],"ly":s[7],"sp":s[8]}]

def coord_key(ra, dec): return (round(float(ra),4), round(float(dec),2))

def flatten_lines(lines):
    pts=[]; pmap={}; edges=[]; seen=set()
    def idx(pt):
        k=coord_key(pt[0],pt[1])
        if k not in pmap:
            pmap[k]=len(pts); pts.append([float(pt[0]),float(pt[1])])
        return pmap[k]
    for line in lines:
        last=None
        for p in line:
            cur=idx(p)
            if last is not None and last != cur:
                e=(last,cur)
                if e not in seen and (cur,last) not in seen:
                    edges.append([last,cur]); seen.add(e)
            last=cur
    return pts,edges

def nearest_star(ra,dec,stars):
    best_i=-1; best_s=None; bd=1e9
    for i,s in enumerate(stars):
        d=ang(ra,dec,s[0],s[1])
        if d<bd: bd=d; best_i=i; best_s=s
    return best_i,best_s,bd

def remap_special(base_k, pts):
    if not base_k or not base_k.get("especial"): return None
    out=json.loads(json.dumps(base_k["especial"],ensure_ascii=False))
    new=[]
    for old_i in out.get("indices",[]):
        p=base_k["puntos"][old_i]
        d,i=min((ang(p[0],p[1],q[0],q[1]),i) for i,q in enumerate(pts))
        if d>0.05: raise RuntimeError(f"special point not found {base_k['abbr']} {old_i} {d}")
        new.append(i)
    out["indices"]=new
    return out

def convert_rasgos(meta, n_points, n_obs):
    r=(meta or {}).get("rasgos") or {}
    return {
      "n_claras": r.get("n_brillantes", r.get("n_claras",0)),
      "brillo_relativo": r.get("brillo_relativo"),
      "forma": r.get("forma_puntos_claros", r.get("forma")),
      "extension_grados": r.get("extension_deg", r.get("extension_grados")),
      "figura_cerrada": r.get("figura_cerrada"),
      "n_puntos": n_points,
      "n_observables": n_obs,
      "base": r.get("base"),
      "pista_unica_en_campo_legacy": ((meta or {}).get("pista") or {}).get("unica_en_el_campo"),
      "pista_pendiente_revision_perceptual": ((meta or {}).get("pista") or {}).get("pendiente_revision_perceptual",False),
    }

def convert_pista(meta):
    p=(meta or {}).get("pista") or {}
    return {
      "es":p.get("es",""),"en":p.get("en",""),
      "tipo":"perceptual","nombra_objetivo":False,
      "legacy_unica_en_campo":p.get("unica_en_el_campo"),
      "pendiente_revision_perceptual":p.get("pendiente_revision_perceptual",False),
      "derivacion":p.get("derivacion"),
    }

def split_milkyway(points, max_chunk=128, gap_deg=6.0):
    out=[]; cur=[]
    for p in points:
        if cur and ang(cur[-1][0],cur[-1][1],p[0],p[1])>gap_deg:
            if cur: out.append(cur)
            cur=[]
        cur.append(p)
        if len(cur)>=max_chunk:
            out.append(cur); cur=[]
    if cur: out.append(cur)
    return out

def make_routes(constellations, neighbor_graph):
    by={c["abbr"]:c for c in constellations}
    regions=defaultdict(list)
    for c in constellations: regions[c["region_legacy"]].append(c["abbr"])
    routes=[{"id":"libre","type":"free","title_es":"Exploración libre","title_en":"Free exploration",
             "constellations":[],"note_es":"Sin orden: cualquier hallazgo cuenta.",
             "note_en":"No order: every valid finding counts."}]
    for rid,seq in sorted(regions.items()):
        n=rid.split("-")[-1]
        routes.append({"id":"region-"+n,"type":"region","title_es":"Región "+n,"title_en":"Region "+n,
                       "constellations":seq,
                       "note_es":"Ruta curada dentro de un cielo continuo; no cambia de campo.",
                       "note_en":"Curated route inside one continuous sky; it does not switch fields."})
    seasons={
      "invierno":({11,0,1},"Invierno","Winter"),
      "primavera":({2,3,4},"Primavera","Spring"),
      "verano":({5,6,7},"Verano","Summer"),
      "otono":({8,9,10},"Otoño","Autumn")
    }
    for rid,(months,es,en) in seasons.items():
        seq=sorted((c["abbr"] for c in constellations if c["mes"] in months),
                   key=lambda ab:(by[ab]["mes"],by[ab]["etiqueta"][0]))
        routes.append({"id":"temporada-"+rid,"type":"season","title_es":es,"title_en":en,
                       "constellations":seq,
                       "note_es":"Selección orientativa del preset curado; no es el cielo real de hoy.",
                       "note_en":"Approximate curated-preset selection; this is not today's real sky."})
    anchors=[
      ("orion","Desde Orión","From Orion","Ori"),
      ("osa-mayor","Desde Osa Mayor","From Ursa Major","UMa"),
      ("triangulo-verano","Triángulo de verano","Summer Triangle","Cyg"),
      ("cruz-sur","Desde Cruz del Sur","From Crux","Cru"),
      ("escorpio","Desde Escorpio","From Scorpius","Sco"),
    ]
    for rid,es,en,root in anchors:
        seq=[root]; seen={root}; cur=root
        while len(seq)<9:
            nxt=next((x["abbr"] for x in neighbor_graph.get(cur,[]) if x["abbr"] not in seen),None)
            if not nxt: break
            seq.append(nxt); seen.add(nxt); cur=nxt
        routes.append({"id":"ancla-"+rid,"type":"anchor","title_es":es,"title_en":en,
                       "constellations":seq,
                       "note_es":"Ruta corta que salta a anclas cercanas y visibles.",
                       "note_en":"Short route hopping to nearby visible anchors."})
    return routes

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--repo",required=True); ap.add_argument("--base-r02",required=True)
    ap.add_argument("--source-meta",required=True); ap.add_argument("--out",required=True); ap.add_argument("--report",required=True)
    a=ap.parse_args()
    repo=Path(a.repo); base=Path(a.base_r02)
    full=json.loads((repo/"es/intereses/cielo/cielo.json").read_text(encoding="utf-8"))
    idx=json.loads((repo/"assets/data/cielo-constellations-r03-index.json").read_text(encoding="utf-8"))
    meta=json.loads(Path(a.source_meta).read_text(encoding="utf-8"))
    base12=load_js_obj(base/"datos/cielo3d.js","window.IG3D")
    base_by={c["abbr"]:c for c in base12["constelaciones"]}
    idx_by={c["abbr"]:c for c in idx["constellations"]}

    runtime_src=[s for s in full["estrellas"] if float(s[2])<=MAG_LIMIT]
    runtime=[compact_star(s) for s in runtime_src]
    full_stars=list(full["estrellas"])
    weak=[[s[0],s[1],s[2],s[3],None,None,None,None,None] for s in full.get("debiles",[])]
    all_for_match=full_stars+weak

    const=[]; assoc_dists=[]; noobs_total=0; bright_anchor_issue=[]
    for f in full["constelaciones"]:
        ab=f["abbr"]
        if ab not in idx_by or ab not in meta["meta"]: raise RuntimeError(f"missing metadata {ab}")
        pts2,edges=flatten_lines(f["lines"])
        pts=[]; noobs=[]
        for pi,(ra,dec) in enumerate(pts2):
            ri,rs,rd=nearest_star(ra,dec,runtime_src)
            ai,as_,ad=nearest_star(ra,dec,all_for_match)
            star_idx=ri if rd<=MATCH_LIMIT_DEG else None
            if star_idx is None:
                noobs_total+=1
                reason="sin estrella asociada dentro de la tolerancia"; detail=None
                if ad<=MATCH_LIMIT_DEG:
                    reason="estrella por debajo de la magnitud límite" if as_[2]>MAG_LIMIT else "estrella no incluida en runtime"
                    detail={"designation":as_[5],"name":as_[6],"magnitude":as_[2],"separation_deg":round(ad,4)}
                noobs.append({"indice":pi,"ra":ra,"dec":dec,"motivo":reason,
                              "magnitud_limite":MAG_LIMIT,"estrella_en_catalogo":detail})
            else: assoc_dists.append(rd)
            pts.append([ra,dec,star_idx])

        old=base_by.get(ab); special=remap_special(old,pts) if old else None
        nobs=sum(p[2] is not None for p in pts)
        anchor=None
        if old and old.get("ancla"):
            olda=old["ancla"]; op=old["puntos"][olda["punto_indice"]]
            d,ni=min((ang(op[0],op[1],p[0],p[1]),i) for i,p in enumerate(pts))
            anchor={"estrella":olda["estrella"],"estrella_indice":pts[ni][2],"punto_indice":ni,
                    "magnitud":olda["magnitud"],"fuente":"R02.1_LOCKED"}
        else:
            b=f.get("bright") or {}; candidates=[]
            for ri,s in enumerate(runtime_src):
                if s[4]!=ab: continue
                if (b.get("n") and s[6]==b.get("n")) or (b.get("d") and s[5]==b.get("d")):
                    candidates.append((ri,s))
            if not candidates:
                candidates=sorted([(ri,s) for ri,s in enumerate(runtime_src) if s[4]==ab],key=lambda x:x[1][2])
            if candidates:
                ri,s=candidates[0]
                d,pi=min((ang(s[0],s[1],p[0],p[1]),i) for i,p in enumerate(pts))
                if d<=1.0:
                    anchor={"estrella":s[6] or s[5] or ab,"estrella_indice":ri,"punto_indice":pi,
                            "magnitud":s[2],"fuente":"cielo.json/bright" if ((b.get("n") and s[6]==b.get("n")) or (b.get("d") and s[5]==b.get("d"))) else "brightest_runtime_fallback"}
                else: bright_anchor_issue.append({"abbr":ab,"reason":"bright star not near figure","deg":round(d,3)})
            else: bright_anchor_issue.append({"abbr":ab,"reason":"no runtime star in constellation"})

        m=meta["meta"][ab]
        rasgos=(old.get("rasgos") if old and old.get("rasgos") else convert_rasgos(m,len(pts),nobs))
        if rasgos:
            rasgos=json.loads(json.dumps(rasgos,ensure_ascii=False)); rasgos["n_puntos"]=len(pts); rasgos["n_observables"]=nobs
        pista=(old.get("pista") if old and old.get("pista") else convert_pista(m))
        c={"abbr":ab,"latin":f["latin"],"genitivo":f["gen"],
           "nombre_es":idx_by[ab]["name_es"],"nombre_en":idx_by[ab]["name_en"],
           "descriptor_es":idx_by[ab]["descriptor_es"],
           "etiqueta":[float(f["label"][0]),float(f["label"][1])],
           "puntos":pts,"aristas":edges,"area_grados_cuadrados":f["area"],"mes":f["mes"],"n6":f["n6"],
           "region_legacy":m["campo"],"especial":special,"rasgos":rasgos,"pista":pista,"ancla":anchor,
           "puntos_no_observables":noobs}
        if old and old.get("relacion_con_orion"): c["relacion_con_orion"]=old["relacion_con_orion"]
        const.append(c)

    graph={}
    for c in const:
        if not c["ancla"] or c["ancla"]["estrella_indice"] is None:
            graph[c["abbr"]]=[]; continue
        s1=runtime_src[c["ancla"]["estrella_indice"]]; rows=[]
        for d in const:
            if d["abbr"]==c["abbr"] or not d["ancla"] or d["ancla"]["estrella_indice"] is None: continue
            s2=runtime_src[d["ancla"]["estrella_indice"]]
            sep=ang(s1[0],s1[1],s2[0],s2[1]); cost=sep+12.0*float(s2[2])
            rows.append({"abbr":d["abbr"],"separacion_grados":round(sep,1),"coste":round(cost,2),
                         "desde_estrella":c["ancla"]["estrella"],"hasta_estrella":d["ancla"]["estrella"]})
        graph[c["abbr"]]=sorted(rows,key=lambda x:(x["coste"],x["separacion_grados"],x["abbr"]))[:6]

    routes=make_routes(const,graph)
    route_links={}
    for r in routes:
        links={}
        seq=r.get("constellations",[])
        if r.get("type") in ("region","anchor"):
            for i in range(1,len(seq)):
                a0=next(c for c in const if c["abbr"]==seq[i-1]); a1=next(c for c in const if c["abbr"]==seq[i])
                if not a0.get("ancla") or not a1.get("ancla"): continue
                s0=runtime_src[a0["ancla"]["estrella_indice"]]; s1=runtime_src[a1["ancla"]["estrella_indice"]]
                links[seq[i]]={"from":seq[i-1],"separacion_grados":round(ang(s0[0],s0[1],s1[0],s1[1]),1),
                               "desde_estrella":a0["ancla"]["estrella"],"hasta_estrella":a1["ancla"]["estrella"]}
        route_links[r["id"]]=links
    data={"schema":"iris-green.cielo-3d.r03.88",
      "base_locked":{"artifact":"CIELO_3D_R02_1.zip","sha256":R02_1_SHA},
      "sources":{"catalogue":"es/intereses/cielo/cielo.json","runtime_index":"assets/data/cielo-constellations-r03-index.json",
                 "pipeline_r03_zip_sha256":PIPELINE_R03_SHA,
                 "r02_meta_sha256":hashlib.sha256(Path(a.source_meta).read_bytes()).hexdigest()},
      "convencion_ejes":base12["convencion_ejes"],"magnitud_limite":MAG_LIMIT,
      "fuentes":{**full.get("fuentes",{}),
                 "figura_r03":"Geometría de figura derivada de Stellarium, preservada por NIGHT_SKY_CONSTELLATION_PIPELINE_R03_FINAL_PASS.",
                 "pipeline_r03_sha256":PIPELINE_R03_SHA},
      "entrada":{"raiz":"Ori","desvio_ra_horas":1.35,"desvio_dec_grados":15,
                 "nota":"Preset curado; no es el cielo real de hoy."},
      "ruta_predeterminada":"ancla-orion",
      "orden_saltos":next(r["constellations"] for r in routes if r["id"]=="ancla-orion"),
      "estrellas_catalogo":len(runtime),
      "estrellas_excluidas_5_6_a_6_0":sum(1 for s in full["estrellas"] if s[2]>MAG_LIMIT),
      "estrellas":runtime,"via_lactea":split_milkyway(full["via_lactea"]),
      "constelaciones":const,"rutas":routes,"route_links":route_links,"vecinos_salto":graph,
      "regla_salto":"coste = separación angular + 12° por magnitud del ancla de destino; sólo sugiere, encontrar fuera de ruta siempre cuenta.",
      "convencion_distancias":base12.get("convencion_distancias"),
      "regla_observabilidad":"Un punto de figura sólo sostiene evidencia si su estrella se dibuja con el límite de magnitud vigente. La adyacencia de evidencia no puentea por puntos no observables.",
      "nota":"Esfera celeste continua. Los antiguos campo-XX sólo sobreviven como metadato de procedencia/agrupación de rutas; no son escenas ni límites de navegación."}
    Path(a.out).parent.mkdir(parents=True,exist_ok=True)
    Path(a.out).write_text("/* GENERADO R03 · 88 constelaciones · no editar a mano. */\nwindow.IG3D = "+json.dumps(data,ensure_ascii=False,separators=(",",":"))+";\n",encoding="utf-8")
    report={"gate_candidate":"SKY_R03_88_DATA_BUILD","constellations":len(const),"runtime_stars":len(runtime),
      "magnitude_limit":MAG_LIMIT,"points_total":sum(len(c["puntos"]) for c in const),
      "edges_total":sum(len(c["aristas"]) for c in const),"non_observable_points":noobs_total,
      "max_star_match_error_deg":round(max(assoc_dists),6) if assoc_dists else None,
      "anchor_issues":bright_anchor_issue,"routes":len(routes),
      "route_types":{t:sum(r["type"]==t for r in routes) for t in sorted({r["type"] for r in routes})},
      "large_scale":["Hya","Eri","Ser","Vir","UMa"],
      "perceptual_pending":[c["abbr"] for c in const if (c["pista"] or {}).get("pendiente_revision_perceptual")],
      "output_sha256":hashlib.sha256(Path(a.out).read_bytes()).hexdigest()}
    Path(a.report).write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(report,ensure_ascii=False,indent=2))

if __name__=="__main__": main()
