# Rutas humanas · SKY-SCALE-03

R03 no usa una cadena de 88 pasos.

## Tipos

- 1 exploración libre.
- 12 rutas de región heredadas únicamente como agrupación curada; no son campos de escena.
- 4 rutas de temporada del preset curado.
- 5 rutas de ancla: Orión, Osa Mayor, Triángulo de verano, Cruz del Sur y Escorpio.

Todas viven en `datos/cielo3d.js → rutas`.

## Reglas

- Una ruta sólo decide qué sugerir después.
- Cualquier hallazgo válido fuera de ruta cuenta.
- Se puede cambiar de ruta desde la portada sin borrar hallazgos.
- “Seguir desde aquí” usa `vecinos_salto` y nunca nombra el destino antes de localizarlo.
- En rutas de región/ancla, una pista perceptual puede incorporar el ancla ya aprendida y su separación angular.
- Temporada es un preset orientativo, no “tu cielo ahora”.

## Cha / Vol

Las pistas legacy de Chamaeleon y Volans son casi idénticas.
R03 no las presenta aisladas como única señal dentro de la misma región:
la ruta añade el ancla previa y la separación angular.

La marca `pendiente_revision_perceptual` se conserva en datos para trazabilidad.
