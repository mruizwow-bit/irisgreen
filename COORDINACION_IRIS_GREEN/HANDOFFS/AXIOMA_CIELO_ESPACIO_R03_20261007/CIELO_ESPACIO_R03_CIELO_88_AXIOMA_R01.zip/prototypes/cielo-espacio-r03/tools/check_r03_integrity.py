#!/usr/bin/env python3
import json, re, hashlib, pathlib, sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
REPO = ROOT.parents[2]
DATA = ROOT / "cielo" / "datos" / "cielo3d.js"
ASSETS = ROOT / "cielo" / "assets" / "constelaciones" / "svg"
FICHAS = ROOT / "cielo" / "datos" / "fichas"
SRCMETA = ROOT / "source" / "source-r02-meta-88.json"
CANON_SHA = "6606430fcc0cf732bb794d8d582bcb31b3e643ac76c96e241c74a8418264df47"

text = DATA.read_text(encoding="utf-8")
m = re.search(r"window\.IG3D\s*=\s*(\{.*\});\s*$", text, re.S)
assert m, "IG3D assignment missing"
d = json.loads(m.group(1))
abbr = [c["abbr"] for c in d["constelaciones"]]
assert len(d["constelaciones"]) == 88
assert len(set(abbr)) == 88
assert len(d["estrellas"]) == 3248
assert d["magnitud_limite"] == 5.6
assert len(d["rutas"]) == 22
assert d["ruta_predeterminada"] == "ancla-orion"
assert set(d["orden_saltos"]).issubset(set(abbr))
assert len(d["fuentes"]) >= 3
assert d["sources"]["pipeline_r03_zip_sha256"] == CANON_SHA

# All route refs valid, no duplicate member in a route.
for r in d["rutas"]:
    seq = r.get("constellations", [])
    assert len(seq) == len(set(seq)), ("duplicate in route", r["id"])
    assert set(seq).issubset(set(abbr)), ("unknown route member", r["id"])

# Every figure point with a star index points into rendered catalogue.
for c in d["constelaciones"]:
    for p in c["puntos"]:
        if p[2] is not None:
            assert 0 <= p[2] < len(d["estrellas"])
    for a,b in c["aristas"]:
        assert 0 <= a < len(c["puntos"]) and 0 <= b < len(c["puntos"])

# Exactly the two known non-observable vertices at this magnitude limit.
nonobs = {c["abbr"]: len(c["puntos_no_observables"]) for c in d["constelaciones"] if c["puntos_no_observables"]}
assert nonobs == {"Cet": 1, "Per": 1}, nonobs

# Full donor assets/fichas present.
svg = sorted(ASSETS.glob("*.svg"))
fichas = sorted(FICHAS.glob("*.js"))
assert len(svg) == 88, len(svg)
assert len(fichas) == 88, len(fichas)

# Source-meta 88/88.
sm = json.loads(SRCMETA.read_text(encoding="utf-8"))
assert sm["constellations_total"] == 88
assert set(sm["meta"]) == set(abbr)

# No old area-specific runtime dependency in active JS/HTML except documented metadata strings.
active = list((ROOT/"cielo"/"js").glob("*.js")) + [ROOT/"cielo"/"index.html"]
hardcoded = []
for p in active:
    s = p.read_text(encoding="utf-8")
    if re.search(r"campo-\d\d", s):
        hardcoded.append(str(p.relative_to(ROOT)))
assert not hardcoded, hardcoded

report = {
    "gate": "SKY_R03_88_INTEGRITY_PASS",
    "constellations": 88,
    "stars": len(d["estrellas"]),
    "routes": len(d["rutas"]),
    "svg_assets": len(svg),
    "fichas": len(fichas),
    "non_observable": nonobs,
    "data_sha256": hashlib.sha256(DATA.read_bytes()).hexdigest(),
    "source_meta_sha256": hashlib.sha256(SRCMETA.read_bytes()).hexdigest(),
    "pipeline_r03_sha256": CANON_SHA,
}
out = ROOT/"evidence"/"SKY_R03_88_INTEGRITY.json"
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps(report, ensure_ascii=False, indent=2))
