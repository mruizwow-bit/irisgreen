# Procedencia · Cielo 88 R03

## Base funcional

`CIELO_3D_R02_1.zip`
SHA-256:
`1f7e6ac7aab0b56d88b880375049a621bb85d9e0bc74105366f1d71073423ba8`

Se conserva:
esfera, cámara, evidencia angular, selección explícita, ambigüedad, cuaderno, storage forward-compatible, ES/EN y NORMAL/REDUCED/NONE.

## Geometría y catálogo

- `es/intereses/cielo/cielo.json`
- HYG Database v4.1
- IAU/WGSN
- d3-celestial / límites IAU según la procedencia ya registrada en el proyecto.

R03 usa magnitud límite 5,6:
3.248 estrellas del catálogo global.

## Índice R03

`assets/data/cielo-constellations-r03-index.json`

Fija 88 abreviaturas, nombres, descriptor, metadatos y el gate fuente:
`NIGHT_SKY_CONSTELLATION_PIPELINE_R03_FINAL_PASS`.

## Masters visuales

Copia canónica localizada:
`IRIS_GREEN_CIELO_CONSTELACIONES_01_88_PIPELINE_R03 (1).zip`

SHA-256:
`6606430fcc0cf732bb794d8d582bcb31b3e643ac76c96e241c74a8418264df47`

Los 88 SVG incluidos en este build han sido comparados contra esa copia:
88/88 byte a byte iguales.

Existe otra copia local con el mismo nombre base y SHA `4f1195...`; no se usa como fuente canónica.

## Metadata perceptual donor

`source/source-r02-meta-88.json`

Extraída del paquete 2D R02.1 auditado:
`DESCUBRIMIENTO_CIELO_COMPLETO_R02_1.zip`
SHA-256 `48fdc66fbeb7f0b644e28b4042e2c083d2d40b7d173fe763c607742c27a877f3`.

Aporta pistas/rasgos legacy y agrupación de procedencia; no reintroduce campos como escenas.

## Observabilidad

La figura geométrica puede contener vértices que no sostienen evidencia.
Con el límite 5,6 aparecen dos:
- Perseo · punto asociado a HIP 13949, mag 5,89;
- Cetus · un punto cuyo astro más cercano queda en mag 6,5.

Se dibuja la figura aprobada, pero esos puntos no cuentan para identificación.
