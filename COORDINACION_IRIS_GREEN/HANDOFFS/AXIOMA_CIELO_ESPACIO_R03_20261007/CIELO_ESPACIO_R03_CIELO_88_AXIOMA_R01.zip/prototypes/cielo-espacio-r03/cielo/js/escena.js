/* Cielo 3D · piloto R01 · DIBUJO.

   Canvas 2D con geometría 3D real: la cámara es una dirección de mirada y un
   campo de visión, y cada estrella es una dirección unitaria proyectada en
   perspectiva. No se usa WebGL —ni hace falta para 1.660 puntos—, así que no
   hay contexto que perder ni fallback prometido que no viaje. La decisión y su
   coste están en documentacion/DECISIONES.md.

   No hay horizonte: sin fecha, hora ni lugar no existe una transformación
   coherente que lo justifique, y no se inventa. Es una vista celeste curada. */
(function (g) {
  'use strict';
  var CFG = g.IG_CONFIG, E = g.IG_ESFERA;

  function colorPorBV(ci) {
    if (ci === null || ci === undefined) return '#DCE8F2';
    if (ci < -0.1) return '#D6E6FF';
    if (ci < 0.3) return '#E6EEFF';
    if (ci < 0.6) return '#F2EFE2';
    if (ci < 1.0) return '#F7E9C8';
    if (ci < 1.5) return '#F2DEC0';
    return '#EFCBB4';
  }
  /* El tamaño sale de la magnitud y del campo de visión: al acercarse, las
     estrellas no se hinchan sin medida, sólo se separan. */
  function radio(mag, fov) {
    var t = (CFG.ESTRELLA.mag_max - mag) / (CFG.ESTRELLA.mag_max - CFG.ESTRELLA.mag_min);
    t = Math.max(0, Math.min(1, t));
    var base = CFG.ESTRELLA.radio_min + Math.pow(t, 1.5) * (CFG.ESTRELLA.radio_max - CFG.ESTRELLA.radio_min);
    var z = Math.max(0.8, Math.min(1.8, Math.pow(55 / fov, 0.35)));
    return base * z;
  }

  /* Registro de LO ÚLTIMO QUE SE HA DIBUJADO. No decide nada: existe para que
     se pueda comprobar desde fuera que lo que se pinta es lo mismo que sostuvo
     la decisión, en vez de fiarse de que sí. */
  var ultimo = { figuras: [], marcadas: [], centro: false };
  function dibujar(ctx, o) {
    ultimo = { figuras: [], marcadas: [], centro: false };
    var cielo = o.cielo, cam = o.camara, W = o.ancho, H = o.alto;
    var base = E.baseCamara(cam);
    ctx.save();
    ctx.setTransform(o.dpr, 0, 0, o.dpr, 0, 0);
    ctx.clearRect(0, 0, W, H);
    ctx.fillStyle = '#0B1A2B';
    ctx.fillRect(0, 0, W, H);

    /* Vía Láctea: nube de densidad del catálogo, no una cinta inventada. Muy
       tenue a propósito: tiene que sugerir dónde se espesa el cielo sin tapar
       ni una estrella, porque las estrellas son lo que hay que reconocer. */
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    var rVia = 5 + 10 * Math.min(1, 55 / cam.fov);
    cielo.via.forEach(function (tramo) {
      tramo.forEach(function (p) {
        var s = E.aPantalla(p.v, cam, W, H, base);
        if (!s.delante || s.x < -40 || s.x > W + 40 || s.y < -40 || s.y > H + 40) return;
        ctx.globalAlpha = 0.0075 * (4 - p.n);
        ctx.fillStyle = '#35506E';
        ctx.beginPath();
        ctx.arc(s.x, s.y, rVia, 0, Math.PI * 2);
        ctx.fill();
      });
    });
    ctx.restore();

    /* Estrellas. */
    cielo.estrellas.forEach(function (e) {
      var s = E.aPantalla(e.v, cam, W, H, base);
      if (!s.delante || s.x < -8 || s.x > W + 8 || s.y < -8 || s.y > H + 8) return;
      var r = radio(e.mag, cam.fov);
      ctx.globalAlpha = Math.max(0.5, Math.min(1, 1.2 - (e.mag - CFG.ESTRELLA.mag_min) / 10));
      ctx.fillStyle = colorPorBV(e.ci);
      ctx.beginPath(); ctx.arc(s.x, s.y, r, 0, Math.PI * 2); ctx.fill();
      if (e.mag <= 2.5) {                       /* halo sobrio de las más claras */
        ctx.globalAlpha = 0.14;
        ctx.beginPath(); ctx.arc(s.x, s.y, r * 2.6, 0, Math.PI * 2); ctx.fill();
      }
    });
    ctx.globalAlpha = 1;

    /* Figuras: sólo la activa y, si se pide, la capa de hallazgos. Nada se
       dibuja antes de encontrarlo. */
    cielo.constelaciones.forEach(function (k) {
      if (o.estados[k.abbr] !== 'revelada') return;
      var activa = (o.activa === k.abbr);
      if (!activa && !o.capaHallazgos) return;
      ultimo.figuras.push(k.abbr);
      ctx.strokeStyle = activa ? 'rgba(238,244,248,0.78)' : 'rgba(238,244,248,0.28)';
      ctx.lineWidth = activa ? 1.5 : 1;
      ctx.beginPath();
      k.aristas.forEach(function (a) {
        var s1 = E.aPantalla(k.puntos[a[0]].v, cam, W, H, base);
        var s2 = E.aPantalla(k.puntos[a[1]].v, cam, W, H, base);
        if (!s1.delante || !s2.delante) return;
        ctx.moveTo(s1.x, s1.y); ctx.lineTo(s2.x, s2.y);
      });
      ctx.stroke();
      if (activa && k.etiqueta) {
        var se = E.aPantalla(k.etiqueta, cam, W, H, base);
        if (se.delante && se.x > 0 && se.x < W && se.y > 0 && se.y < H) {
          ctx.fillStyle = 'rgba(201,213,221,0.85)';
          ctx.font = '13px "Atkinson Hyperlegible", system-ui, sans-serif';
          ctx.textAlign = 'center';
          ctx.fillText(o.idioma === 'es' ? k.nombre_es : k.nombre_en, se.x, se.y);
        }
      }
    });

    /* Marcas de lo que se ha tomado: las mismas que sustentaron la evidencia. */
    var marcadas = o.marcadas || [];
    if (marcadas.length > 1) {
      ctx.strokeStyle = 'rgba(195,184,255,0.55)'; ctx.lineWidth = 1.2;
      ctx.setLineDash([4, 5]);
      ctx.beginPath();
      marcadas.forEach(function (p, i) {
        var s = E.aPantalla(p.v, cam, W, H, base);
        if (!s.delante) return;
        if (i === 0) ctx.moveTo(s.x, s.y); else ctx.lineTo(s.x, s.y);
      });
      ctx.stroke(); ctx.setLineDash([]);
    }
    marcadas.forEach(function (p) {
      var s = E.aPantalla(p.v, cam, W, H, base);
      if (!s.delante) return;
      ultimo.marcadas.push(Math.round(p.ra * 1e4) / 1e4 + '/' + Math.round(p.dec * 1e4) / 1e4);
      ctx.strokeStyle = '#C3B8FF'; ctx.lineWidth = 1.8;
      ctx.beginPath(); ctx.arc(s.x, s.y, 7.5, 0, Math.PI * 2); ctx.stroke();
    });

    if (o.estrellaSeleccionada) {
      var ss = E.aPantalla(o.estrellaSeleccionada.v, cam, W, H, base);
      if (ss.delante) {
        ctx.strokeStyle = '#C3B8FF'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(ss.x, ss.y, 10, 0, Math.PI * 2); ctx.stroke();
      }
    }

    /* Contorno exacto de la región de evidencia: lo que se ve es lo que
       cuenta, también fuera del centro, donde el cono no es un círculo. */
    function contorno(dir, color, guiones) {
      var pts = E.contornoEvidencia(dir, cam, W, H, 56).filter(function (p) { return p.delante; });
      if (pts.length < 8) return;
      ctx.strokeStyle = color; ctx.lineWidth = 1.5;
      if (guiones) ctx.setLineDash(guiones);
      ctx.beginPath();
      pts.forEach(function (p, i) { if (i === 0) ctx.moveTo(p.x, p.y); else ctx.lineTo(p.x, p.y); });
      ctx.closePath(); ctx.stroke(); ctx.setLineDash([]);
    }
    if (o.marca) contorno(o.marca, 'rgba(201,213,221,0.55)');
    if (o.centro) {
      ultimo.centro = true;
      var dirC = E.dePantalla(E.centroVista(W, H), cam, W, H, base);
      contorno(dirC, 'rgba(195,184,255,0.55)', [5, 6]);
      ctx.strokeStyle = 'rgba(195,184,255,0.55)'; ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(W / 2 - 6, H / 2); ctx.lineTo(W / 2 + 6, H / 2);
      ctx.moveTo(W / 2, H / 2 - 6); ctx.lineTo(W / 2, H / 2 + 6);
      ctx.stroke();
    }
    ctx.restore();
  }

  g.IG_ESCENA = { dibujar: dibujar, colorPorBV: colorPorBV, radio: radio,
                  ultimoDibujo: function () { return ultimo; } };
})(window);
