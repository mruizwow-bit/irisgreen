# Entrega · 11 de septiembre de 2026 · que el build no pueda publicar esto otra vez

Primera tanda del arreglo. No corrige fichas: pone las tres comprobaciones que hoy no existen y saca la comprobación previa de su rama escondida. Con esto, ninguno de los fallos del informe puede volver a la web sin que el build se pare.

Este chat no toca el repositorio. Todo lo de `repo/` va encima, respetando las rutas (5 archivos: sustituye 1 y añade 4).

## Qué hay en `repo/`

- `.github/workflows/comprobar-publicacion.yml` — sustituye al actual. Hoy se dispara solo en la rama `ajustes/auditoria-web` y solo si cambia su propio archivo, o sea: casi nunca. Ahora se dispara **en cada push y cada pull request a `main`**, construye el directorio que publicará Netlify y pasa por él las tres auditorías nuevas más los controles que ya existían.
- `scripts/audit_sin_js.py` — nuevo. Falla si una página publicada lleva variables de plantilla sin resolver. Las que todavía no están convertidas se declaran en `editorial/pendientes-sin-js.json`; la lista solo puede encoger.
- `editorial/pendientes-sin-js.json` — nuevo. Las seis páginas que hoy dependen de JavaScript, con su motivo y su orden. Libros va primera porque además su enlace de muestra no abre nada.
- `scripts/audit_accesibilidad.py` — nuevo. Recorre todo el HTML publicado y comprueba `<main>`, un solo `<h1>` con texto, nombre accesible en campos, botones y enlaces, y `alt` en imágenes. Solo biblioteca estándar: se puede ejecutar en el build, no solo en el workflow.
- `scripts/audit_sin_portugues.py` — va en la tanda del portugués (`entrega-2026-09-11-portugues/`). El workflow ya lo llama; si esa tanda no está aplicada, quita ese paso o aplícala antes.

## Procedimiento

```bash
git switch main && git pull
git branch backup/$(date +%Y%m%d-%H%M)-antes-comprobaciones
git switch -c integracion/$(date +%Y%m%d)-comprobaciones
# copiar repo/ encima
rm -rf dist && python3 scripts/build_site.py
python3 scripts/audit_sin_js.py --root dist            # las seis declaradas: pasa
python3 scripts/audit_accesibilidad.py --root dist --informe-solo
```

La primera vez conviene el `--informe-solo`: escribe `dist/reports/publicacion/accesibilidad.json` con la lista completa sin detener nada. Ahí saldrán, entre otros, los fallos que ya conocemos: la hoja de impresión de los cromos sin `<main>` ni `<h1>`, y los buscadores de Investigación y Vídeos sin nombre accesible.

Cuando esa lista esté a cero, quitar `--informe-solo` y añadir las dos líneas al final de `build_site.py`, junto a las otras auditorías:

```python
subprocess.run([sys.executable,str(ROOT/'scripts/audit_sin_js.py'),'--root',str(dst)],cwd=ROOT,check=True)
subprocess.run([sys.executable,str(ROOT/'scripts/audit_accesibilidad.py'),'--root',str(dst)],cwd=ROOT,check=True)
```

Se añaden a mano porque hay otra tanda pendiente que también sustituye `build_site.py` (la del 10 de septiembre): así no se pisan.

## Una cosa que el workflow no puede hacer solo

Netlify construye con cada push a `main`, sin esperar a GitHub Actions. Para que una comprobación en rojo **impida** publicar, hace falta una de estas dos, y es una decisión tuya:

1. Proteger `main` en GitHub (Settings → Branches): exigir esta comprobación en los pull request y dejar de subir directamente a `main`.
2. O decirle a Netlify que publique desde otra rama, y mover ahí lo que haya pasado la comprobación.

Sin una de las dos, el workflow avisa pero no frena. Con las auditorías dentro de `build_site.py` sí frena siempre, porque entonces el propio build de Netlify falla y no se publica nada.

## Lo que esta tanda no hace

- No convierte las seis páginas que dependen de JavaScript: las declara y las ordena.
- No corrige los fallos de accesibilidad: los saca a una lista con archivo y motivo.
- No toca fichas, fuentes, clasificaciones ni estados.
- No reabre el sitio.
