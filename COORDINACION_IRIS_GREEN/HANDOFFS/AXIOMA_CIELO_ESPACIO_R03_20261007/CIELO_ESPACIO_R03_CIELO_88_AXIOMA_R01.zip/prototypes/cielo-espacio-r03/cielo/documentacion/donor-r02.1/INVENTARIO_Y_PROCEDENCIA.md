# Inventario y procedencia · Cielo 3D R02.1

2026-10-07. Todo lo que hay aquí viene de paquetes que ya existían. **No se ha
generado ninguna estrella, ninguna figura ni ningún master nuevo.** Lo único que
R02 añade a los datos son MEDIDAS sobre ese mismo catálogo (rasgos, anclas,
saltos y pistas), y cada una dice de dónde sale.

## 1. Intake, con hashes comprobados

| Paquete | SHA256 | Estado |
|---|---|---|
| `DESCUBRIMIENTO_CIELO_COMPLETO_R02.zip` | `581368ff4b2db0208274f3d8cca65f4973b64a4038e4c15b209a8591cd814cfa` | **Coincide** con el hash declarado en la orden. Es la base conocida |
| `DESCUBRIMIENTO_CIELO_COMPLETO_R02_1.zip` | `48fdc66fbeb7f0b644e28b4042e2c083d2d40b7d173fe763c607742c27a877f3` | Patch R02.1 construido por Claude el mismo día. **Entregado para revisión, NO revisado ni aprobado**: no se afirma que R02.1 esté cerrado |
| `CIELO_NOCTURNO_BIBLIOTECA_COMPLETA_R01` → `datos_estelares/cielo.json` | `1bd47fa403d69c82111dbbaf616258144e1c00bc4c2e393987497d07e14f8a72` | Catálogo de origen |

| `CIELO_3D_PILOTO_R01.zip` | `369b37a569a26689f7b52197a6393280d538ef4a413d65ceae98042a19dfb813` | **Coincide** con el hash declarado en la orden R02. Es la base elegida por María y el punto de partida de esta ampliación |

Orden canónica leída: `ANALISIS_R02_Y_PATCH_R02_1.md`, commit `1f7d662`.
Orden del piloto: `ORDEN_CLAUDE_CIELO_3D_PILOTO_R01.md`, commit `2bf3c39`.
Orden de esta ampliación: `ORDEN_CLAUDE_CIELO_3D_AMPLIACION_R02.md`, commit
`5b880bc3ce33b36a67f0a29ad82da8c91bbde2e2`, registrada en #323, comentario
`6018816163`.

### Qué correcciones de R02.1 están efectivamente presentes aquí

Este piloto **no hereda el código 2D**: es un ejecutable aparte. Lo que sí
hereda, a propósito, son las decisiones que R02.1 dejó cerradas, reimplementadas
en geometría 3D y comprobadas de nuevo en este paquete:

| Decisión | Dónde se comprueba aquí |
|---|---|
| Tolerancia de entrada separada de la evidencia angular | `U03`, `N02` |
| Mínimo semántico que no se rebaja al ocultar evidencia | `U04`, `U06`, `N03` |
| El cinturón exige sus tres estrellas | `U04`, `N03` |
| Misma evidencia visible ⇒ misma decisión entre viewports | `U03`, `N02` |
| Apertura declarada en grados y contrastada con la geometría | `U03`, `U09` |
| Pinza → un dedo sin salto | `N05` |
| Foco al cambiar de pantalla y al redimensionar | `N09` |
| Siguiente pista sólo al continuar | `N01d`, `N01f` |
| Política de movimiento con NONE y elección explícita | `N07` |
| Portada sin nombrar Orión antes de localizar el cinturón | `N01a` |

## 2. De dónde sale cada cosa

| Pieza | Origen | Tratamiento |
|---|---|---|
| 1.660 estrellas (AR/Dec, magnitud, índice B-V, nombre, distancia, tipo) | `cielo.json`, HYG Database v4.1 | Mismo catálogo y misma magnitud límite (5,6) que el paquete 2D; seleccionadas por un casquete que cubre las dos zonas, **sin duplicados** |
| 12 figuras (141 puntos, 138 aristas) | `cielo.json`, líneas de d3-celestial | Convertidas a puntos con índice de estrella y aristas explícitas; ningún trazo añadido |
| Vía Láctea (167 tramos, 3.731 puntos) | `cielo.json` | Nube de densidad, dibujada muy tenue |
| 12 fichas | `DESCUBRIMIENTO_CIELO_COMPLETO_R02` | Copiadas tal cual |
| 12 masters SVG R03 | mismo paquete | Copiados byte a byte |
| Tipografías Atkinson Hyperlegible y Newsreader | mismo paquete | Copiadas, con la variante base64 para `file://` |
| Canon NAVY | `css/iris-green-navy.css` | Copiado sin tocar |

### Lo que R02 añade a `datos/cielo3d.js`, y de dónde sale

Nada de esto es texto escrito a mano: todo se calcula con `gen_3d_r02.py` sobre
las estrellas y las figuras que ya estaban.

| Campo | Cómo se deriva |
|---|---|
| `rasgos` (`n_claras`, `brillo_relativo`, `forma`, `extension_grados`, `figura_cerrada`, `n_puntos`) | Medido sobre las estrellas de la figura del catálogo. `brillo_relativo` compara la más clara con las demás; no se publica ninguna magnitud en el texto |
| `ancla` (`estrella`, `estrella_indice`, `punto_indice`, `magnitud`) | La estrella más clara de la figura. Los dos índices llevan nombres distintos a propósito: uno es el de la estrella en el catálogo, el otro el del punto dentro de la figura |
| `salto` (`desde`, `desde_estrella`, `hasta_estrella`, `separacion_grados`, `octante`, `direccion_es/en`, `punos_es/en`, `derivacion`) | Separación angular entre las anclas de las dos figuras, medida sobre el catálogo. La dirección es el octante tal como se ve en pantalla con el norte celeste arriba y la ascensión recta creciendo hacia la izquierda |
| `pista` (`es`, `en`, `tipo`, `nombra_objetivo`, `ancla`, `sin_ancla_es/en`) | Compuesta a partir de `rasgos` y `salto`. `nombra_objetivo` es `false` y se comprueba en `U13` |
| `orden_saltos`, `regla_orden_saltos` | El árbol de saltos y la regla con la que se construyó, declarada: `coste = separación + 12° × magnitud del ancla de destino` |
| `convencion_distancias` | El puño a brazo estirado ≈ 10°. Declarado como convención observacional, no como dato del catálogo |

Fuentes declaradas, tal como vienen del catálogo:

- Estrellas: HYG Database v4.1, David Nash (astronexus), CC BY-SA 4.0.
- Nombres: IAU WGSN, lista compilada por Cora Schneck (iau-star-names), MIT.
- Líneas, límites y nombres: d3-celestial, Olaf Frohn, BSD-3-Clause; límites
  oficiales de la IAU (Delporte, 1930).

## 3. Un dato ausente, medido y excluido

De los 141 puntos de figura, **1 no tiene estrella dibujada**: Perseo, punto 17,
AR 2,9944 h, Dec +41,03°.

En el catálogo completo sí hay una estrella ahí: **HIP 13949**, a 0,003° de ese
vértice, de **magnitud 5,89**. No se dibuja porque la magnitud límite de este
paquete es **5,6**, la misma del paquete 2D. No es una asociación que faltara:
es una estrella más débil que el límite declarado.

Desde R02.1 ese punto queda **fuera de toda evidencia**: no cuenta, no suma al
mínimo, no entra en el trozo seguido, la adyacencia de evidencia no lo puentea y
no puede marcarse en pantalla. La línea de la figura se sigue dibujando entera:
**no se ha tocado ningún master** para esconder el hueco.

Está declarado en los datos, en `puntos_no_observables` de Perseo y en la
`regla_observabilidad` global, y lo comprueban `U16`, `U17` y `N23`.

No se ha inventado ninguna estrella para rellenarlo, y no se ha subido la
magnitud límite para que entrara.

## 4. Lo que NO se ha tocado

- No se ha modificado ningún master, ni se ha regenerado ninguna imagen.
- No se ha escalado a las 88: aquí hay 12 constelaciones, las de dos zonas.
- No se ha añadido ni retocado ninguna arista ni ningún punto de figura para que
  un patrón cierre mejor.
- Este paquete no distribuye ningún asset nuevo y no reintroduce el sustituto
  revocado B16: no hay ninguna referencia a él en código, datos ni assets.
- No se ha tocado el paquete 2D: `DESCUBRIMIENTO_CIELO_COMPLETO_R02` y
  `R02_1` siguen como estaban, ahora como referencia y rollback —no como
  candidata pendiente de elección.
- No se ha tocado el paquete del piloto `CIELO_3D_PILOTO_R01`: esta ampliación
  es una copia aparte.
