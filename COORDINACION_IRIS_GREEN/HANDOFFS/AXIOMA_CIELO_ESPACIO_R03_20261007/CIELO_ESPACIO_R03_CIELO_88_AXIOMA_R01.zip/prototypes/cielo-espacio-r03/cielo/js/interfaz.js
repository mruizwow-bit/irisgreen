/* Cielo 3D · piloto R01 · INTERFAZ Y ESTADO.

   Observador fijo: orientar, señalar, localizar, revelar, profundizar y volver
   al mismo sitio. Nada se identifica solo y nada se revela antes de tiempo. */
(function (g) {
  'use strict';
  var CFG = g.IG_CONFIG, E = g.IG_ESFERA, R = g.IG_ESCENA, COPIA = g.IG_COPIA;

  /* R03. No existe una cadena única de 88. La ruta activa sale de datos:
     libre, región, temporada o ancla. Encontrar fuera de ruta siempre vale. */
  function rutas() { return (cielo && cielo.meta.rutas) || []; }
  function rutaPorId(id) { return rutas().find(function (r) { return r.id === id; }) || null; }
  function rutaActiva() { return rutaPorId(estado.rutaId) || rutaPorId(cielo && cielo.meta.ruta_predeterminada); }
  function recorrido() {
    var r = rutaActiva();
    return r ? (r.constellations || []) : ((cielo && cielo.meta.orden_saltos) || []);
  }
  var estado = {
    pantalla: 'portada',
    camara: null,
    estados: {}, descubiertas: {}, lugares: {},
    activa: null, capaHallazgos: false,
    localizada: null, marca: null, mensaje: null,
    panel: null, panelAbbr: null, seccion: null, estrellaSel: null,
    objetivo: null, enContextoHallazgo: false, ladoPanel: 'derecha',
    rutaId: null, seguirDesde: null, seguirModo: false,
    idioma: 'es', movimiento: 'NORMAL', movimientoExplicito: false,
    describir: false, tecladoActivo: false, ruedaArmada: false,
    ultimoExamen: null, plausibles: null
  };

  var el = {}, ctx, cielo = null, anim = null, tAnuncio = null, tResize = null;
  var ultimoFoco = null, guardadoRoto = false, tGuardado = null, tokenFicha = 0;
  /* P1-02. Si lo guardado viene de una versión posterior a la que este paquete
     entiende, no se toca: ni se escribe encima, ni se borra, ni se promete que
     se está guardando. La sesión funciona entera, pero sólo en memoria. */
  var soloLectura = false, avisoClave = null;
  var punteros = {}, gestoMulti = false, pinza = null, mqMovimiento = null;
  var focoProgramatico = false, dialogo = null, medidas = { cuadros: 0, ms: 0 };
  /* C3D-03. La retícula central es APOYO del teclado, no la metáfora. Sólo
     aparece si la última entrada real fue de teclado; un foco que mueve el
     programa no la enciende. */
  var ultimaEntrada = 'puntero';

  function t() { return COPIA[estado.idioma]; }
  function porAbbr(a) { return cielo.porAbbr[a]; }
  function nombreDe(a) { var k = porAbbr(a); return k ? (estado.idioma === 'es' ? k.nombre_es : k.nombre_en) : a; }
  function nombreRuta(r) { return r ? (estado.idioma === 'es' ? r.title_es : r.title_en) : ''; }
  function notaRuta(r) { return r ? (estado.idioma === 'es' ? r.note_es : r.note_en) : ''; }
  function pintarSelectorRutas() {
    if (!el['sel-ruta'] || !cielo) return;
    var actual = estado.rutaId || cielo.meta.ruta_predeterminada;
    el['sel-ruta'].textContent = '';
    rutas().forEach(function (r) {
      var o = document.createElement('option');
      o.value = r.id; o.textContent = nombreRuta(r); el['sel-ruta'].appendChild(o);
    });
    if (rutaPorId(actual)) estado.rutaId = actual;
    else if (rutas().length) estado.rutaId = rutas()[0].id;
    el['sel-ruta'].value = estado.rutaId || '';
    if (el['ruta-nota']) el['ruta-nota'].textContent = notaRuta(rutaActiva());
  }
  function relacionDesde(desde, hasta) {
    var g = cielo && cielo.meta.vecinos_salto && cielo.meta.vecinos_salto[desde];
    var r = g ? g.find(function (x) { return x.abbr === hasta; }) || null : null;
    if (r) return r;
    var links = cielo && cielo.meta.route_links && cielo.meta.route_links[estado.rutaId];
    var q = links && links[hasta];
    return q && q.from === desde ? q : null;
  }
  function siguienteDesde(abbr) {
    var g = cielo && cielo.meta.vecinos_salto && cielo.meta.vecinos_salto[abbr];
    if (!g) return null;
    var r = g.find(function (x) { return !estado.descubiertas[x.abbr]; });
    return r ? r.abbr : null;
  }

  /* ------------------------------------------------------- guardado ------ */
  var VERSION_GUARDADO = 1;
  function guardar() {
    if (tGuardado) { clearTimeout(tGuardado); tGuardado = null; }
    if (soloLectura) return;          /* los bytes de la versión futura se quedan como están */
    try {
      localStorage.setItem(CFG.CLAVE_GUARDADO, JSON.stringify({
        v: VERSION_GUARDADO, descubiertas: Object.keys(estado.descubiertas),
        lugares: estado.lugares, camara: estado.camara,
        movimiento: estado.movimientoExplicito ? estado.movimiento : null,
        ruta: estado.rutaId
      }));
    } catch (e) {
      if (!guardadoRoto) { guardadoRoto = true; avisar('aviso_guardado'); }
    }
  }
  function guardarDiferido() {
    if (tGuardado) return;
    tGuardado = setTimeout(function () { tGuardado = null; guardar(); }, 400);
  }
  function num(x, a, b) { return typeof x === 'number' && isFinite(x) && x >= a && x <= b; }
  function camaraValida(c) {
    return !!c && typeof c === 'object' && num(c.ra, 0, 24) && num(c.dec, -90, 90) &&
      num(c.fov, CFG.CAMPO_VISION.minimo, CFG.CAMPO_VISION.maximo);
  }
  function cargar() {
    var s;
    try { s = JSON.parse(localStorage.getItem(CFG.CLAVE_GUARDADO) || '{}'); } catch (e) { s = null; }
    /* Una versión POSTERIOR no se entiende, pero tampoco es basura: es progreso
       de alguien, guardado por una versión más nueva. No se lee —no se sabe qué
       significa— y, sobre todo, no se destruye. */
    if (s && typeof s === 'object' && typeof s.v === 'number' && isFinite(s.v) && s.v > VERSION_GUARDADO) {
      soloLectura = true;
      avisar('aviso_guardado_futuro');
      return;
    }
    if (!s || typeof s !== 'object' || s.v !== VERSION_GUARDADO) return;
    if (Array.isArray(s.descubiertas)) {
      s.descubiertas.forEach(function (a) { if (typeof a === 'string' && porAbbr(a)) estado.descubiertas[a] = true; });
    }
    if (s.lugares && typeof s.lugares === 'object') {
      Object.keys(s.lugares).forEach(function (a) {
        if (porAbbr(a) && camaraValida(s.lugares[a])) estado.lugares[a] = s.lugares[a];
      });
    }
    if (camaraValida(s.camara)) estado.camaraGuardada = { ra: s.camara.ra, dec: s.camara.dec, fov: s.camara.fov };
    if (typeof s.movimiento === 'string' && CFG.MOVIMIENTO[s.movimiento] !== undefined) {
      estado.movimiento = s.movimiento; estado.movimientoExplicito = true;
    }
    if (typeof s.ruta === 'string' && rutaPorId(s.ruta)) estado.rutaId = s.ruta;
  }

  /* -------------------------------------------------------- arranque ---- */
  function iniciar() {
    ['portada','escena','escenario','lienzo','panel','panel-titulo','panel-cuerpo',
     'btn-cerrar-panel','btn-examinar','mensaje','btn-revelar','btn-saber-mas','descripcion',
     'descripcion-region','descripcion-entorno','aviso','btn-describir','btn-fuentes','btn-borrar',
     'anuncio','sel-movimiento','sel-ruta','ruta-nota','btn-empezar','btn-continuar','btn-volver-portada','objetivo',
     'btn-continuar-pista','btn-seguir-desde','orientacion','btn-capa','btn-cuaderno','progreso-global','hero-intro','fuentes-fuera',
     'velo','dialogo','dialogo-titulo','dialogo-texto','dialogo-cancelar','dialogo-confirmar']
      .forEach(function (id) { el[id] = document.getElementById(id); });

    try { ctx = el.lienzo.getContext('2d'); } catch (e) { ctx = null; }
    if (!ctx) {                       /* sin canvas 2D no hay cielo que dibujar */
      mostrarAviso('Este navegador no ha podido abrir el lienzo. La experiencia 2D del paquete ' +
                   'DESCUBRIMIENTO_CIELO_COMPLETO sigue siendo la vía disponible.');
      return;
    }
    if (g.matchMedia) {
      mqMovimiento = g.matchMedia('(prefers-reduced-motion: reduce)');
      var seguirSistema = function () {
        if (estado.movimientoExplicito) return;
        estado.movimiento = mqMovimiento.matches ? 'REDUCED' : 'NORMAL';
        if (el['sel-movimiento']) el['sel-movimiento'].value = estado.movimiento;
      };
      if (mqMovimiento.addEventListener) mqMovimiento.addEventListener('change', seguirSistema);
      else if (mqMovimiento.addListener) mqMovimiento.addListener(seguirSistema);
      estado.movimiento = mqMovimiento.matches ? 'REDUCED' : 'NORMAL';
    }

    cielo = E.construirCielo(g.IG3D);
    estado.rutaId = cielo.meta.ruta_predeterminada || (rutas()[0] && rutas()[0].id) || null;
    cargar();
    enlazar();
    aplicarIdioma();
    pintarSelectorRutas();
    actualizarPulsados();
    mostrarPantalla('portada');
    if (g.matchMedia && g.matchMedia('(forced-colors: active)').matches) mostrarAviso(t().aviso_forced);
  }

  /* ------------------------------------------------------- pantallas ---- */
  function enfocar(nodo) {
    if (!nodo) return;
    focoProgramatico = true;
    setTimeout(function () { focoProgramatico = false; }, 0);
    if (nodo.tabIndex < 0 && !/^(A|BUTTON|INPUT|SELECT|TEXTAREA)$/.test(nodo.tagName)) {
      nodo.setAttribute('tabindex', '-1');
    }
    try { nodo.focus(); } catch (e) {}
  }
  function mostrarPantalla(p) {
    var cambia = estado.pantalla !== p;
    estado.pantalla = p;
    tokenFicha++;
    el.portada.hidden = p !== 'portada';
    el.escena.hidden = p !== 'escena';
    if (p === 'portada') pintarPortada();
    if (cambia) enfocar(p === 'portada' ? el['btn-empezar'] : el.escenario);
  }
  function pintarPortada() {
    var L = t(), via = recorrido();
    var rutaHechas = via.filter(function (a) { return estado.descubiertas[a]; }).length;
    var globales = Object.keys(estado.descubiertas).length;
    var hay = globales > 0;
    pintarSelectorRutas();
    el['btn-empezar'].textContent = L.empezar_explorar;
    el['btn-continuar'].hidden = !hay;
    el['btn-continuar'].textContent = L.continuar;
    el['progreso-global'].textContent = globales
      ? (via.length ? L.progreso_ruta(globales, rutaHechas, via.length) : L.progreso(globales, cielo.constelaciones.length))
      : '';
  }

  /* ----------------------------------------------------- entrar al cielo - */
  /* R03. La entrada completa —raíz y desvío— sale de los datos. El preset
     sigue siendo curado: no pretende representar el cielo real de hoy. */
  function camaraInicial() {
    var entrada = cielo.meta.entrada || {};
    var raiz = entrada.raiz || recorrido()[0];
    var k = raiz ? porAbbr(raiz) : null;
    if (!k) return E.ajustarCamara({ ra: 0, dec: 0, fov: CFG.CAMPO_VISION.inicial });
    var ref = k.especial ? k.puntos[k.especial.indices[Math.floor(k.especial.indices.length / 2)]]
                         : (k.ancla ? k.puntos[k.ancla.punto_indice] : k.puntos[0]);
    var c = E.aCoordenadas(ref.v);
    var dra = typeof entrada.desvio_ra_horas === 'number' ? entrada.desvio_ra_horas : 0;
    var ddec = typeof entrada.desvio_dec_grados === 'number' ? entrada.desvio_dec_grados : 0;
    return E.ajustarCamara({ ra: (c.ra + dra + 24) % 24,
                             dec: c.dec + ddec,
                             fov: CFG.CAMPO_VISION.inicial });
  }
  function abrirEscena(continuar) {
    estado.camara = (continuar && estado.camaraGuardada)
      ? { ra: estado.camaraGuardada.ra, dec: estado.camaraGuardada.dec, fov: estado.camaraGuardada.fov }
      : camaraInicial();
    E.ajustarCamara(estado.camara);
    estado.estados = {};
    Object.keys(estado.descubiertas).forEach(function (a) { estado.estados[a] = 'revelada'; });
    estado.localizada = null; estado.marca = null; estado.mensaje = null;
    estado.activa = null; estado.enContextoHallazgo = false; estado.ruedaArmada = false;
    estado.ambiguas = null;
    cerrarPanel(true);
    elegirObjetivo();
    mostrarPantalla('escena');
    redimensionar();
    pintarMensaje();
  }

  /* R03. El objetivo puede venir de una ruta humana o de “seguir desde aquí”.
     Ninguna ruta limita qué puede encontrarse: sólo decide la siguiente pista. */
  function elegirObjetivo() {
    if (estado.seguirModo && estado.seguirDesde) {
      var vecino = siguienteDesde(estado.seguirDesde);
      if (vecino) {
        estado.objetivo = vecino;
        pintarObjetivo();
        return;
      }
      estado.seguirModo = false; estado.seguirDesde = null;
    }
    var pend = recorrido().filter(function (a) { return !estado.descubiertas[a]; });
    estado.objetivo = pend.length ? pend[0] : null;
    pintarObjetivo();
  }
  function desdeDeRuta(abbr) {
    if (estado.seguirModo && estado.seguirDesde) return estado.seguirDesde;
    var r = rutaActiva(), via = r && r.constellations || [], i = via.indexOf(abbr);
    if (!r || (r.type !== 'anchor' && r.type !== 'region') || i <= 0) return null;
    for (var j = i - 1; j >= 0; j--) if (estado.descubiertas[via[j]]) return via[j];
    return null;
  }
  /* La pista base sigue siendo perceptual. En rutas de anclas, si el punto de
     partida YA se aprendió, se añade separación angular sin nombrar el destino. */
  function textoPista(abbr) {
    var k = porAbbr(abbr), es = estado.idioma === 'es';
    if (!k || !k.pista) return '';
    var q = k.pista, base;
    if (q.tipo === 'salto' && q.ancla && !estado.descubiertas[q.ancla]) {
      base = es ? q.sin_ancla_es : q.sin_ancla_en;
    } else base = es ? q.es : q.en;
    if (q.tipo === 'salto') return base;  /* R02.1 ya trae ancla, dirección y distancia */
    var desde = desdeDeRuta(abbr);
    if (desde && estado.descubiertas[desde]) {
      var rel = relacionDesde(desde, abbr);
      if (rel && rel.desde_estrella) return t().pista_desde(rel.desde_estrella, rel.separacion_grados, base);
    }
    return base;
  }
  function pintarObjetivo() {
    var L = t(), r = rutaActiva();
    el['btn-seguir-desde'].hidden = true;
    if (estado.enContextoHallazgo) {
      el.objetivo.textContent = L.contexto_hallazgo(nombreDe(estado.enContextoHallazgo));
      el['btn-continuar-pista'].hidden = false;
      el['btn-continuar-pista'].textContent = L.continuar;
      if (siguienteDesde(estado.enContextoHallazgo)) {
        el['btn-seguir-desde'].hidden = false;
        el['btn-seguir-desde'].textContent = L.seguir_desde_aqui;
      }
      return;
    }
    el['btn-continuar-pista'].hidden = true;
    if (estado.objetivo) el.objetivo.textContent = textoPista(estado.objetivo);
    else if (r && r.type === 'free') el.objetivo.textContent = L.objetivo_libre;
    else el.objetivo.textContent = L.todo_encontrado;
  }
  function activarSeguirDesde() {
    var a = estado.enContextoHallazgo || estado.activa;
    if (!a || !siguienteDesde(a)) return;
    estado.seguirModo = true; estado.seguirDesde = a; estado.enContextoHallazgo = false;
    elegirObjetivo(); enfocar(el.escenario); anunciar(t().siguiente_pista);
  }
  function volverAExplorar(mueveFoco) {
    if (!estado.enContextoHallazgo) return false;
    estado.enContextoHallazgo = false;
    pintarObjetivo();
    if (mueveFoco !== false) enfocar(el.escenario);
    anunciar(t().siguiente_pista);
    return true;
  }

  /* ---------------------------------------------------------- medidas --- */
  function medir() {
    var r = el.escenario.getBoundingClientRect();
    return { W: Math.max(1, Math.round(r.width)), H: Math.max(1, Math.round(r.height)),
             dpr: Math.min(g.devicePixelRatio || 1, 2) };
  }
  function redimensionar() {
    if (!cielo || !estado.camara) return;
    var m = medir();
    el.lienzo.width = Math.round(m.W * m.dpr);
    el.lienzo.height = Math.round(m.H * m.dpr);
    pintar();
    if (estado.describir) actualizarDescripcion(false);
  }
  /* Nada se dibuja encima del cielo: la lista de oclusores existe para que la
     evidencia sepa qué NO se está viendo, y en este piloto está vacía salvo
     que algo flote sobre el lienzo. */
  function zonasOcluidas() {
    var base = el.escenario.getBoundingClientRect(), zonas = [];
    var nodos = document.querySelectorAll('[data-occluder]');
    for (var i = 0; i < nodos.length; i++) {
      var n = nodos[i];
      if (n.hidden || n.offsetParent === null) continue;
      var r = n.getBoundingClientRect();
      if (r.right < base.left || r.left > base.right || r.bottom < base.top || r.top > base.bottom) continue;
      zonas.push({ x: r.left - base.left - 4, y: r.top - base.top - 4, w: r.width + 8, h: r.height + 8 });
    }
    return zonas;
  }
  function pintar() {
    if (!cielo || !estado.camara) return;
    var m = medir(), t0 = (g.performance || Date).now();
    R.dibujar(ctx, {
      cielo: cielo, camara: estado.camara, ancho: m.W, alto: m.H, dpr: m.dpr,
      estados: estado.estados, activa: estado.activa, capaHallazgos: estado.capaHallazgos,
      marca: estado.marca, centro: estado.tecladoActivo, idioma: estado.idioma,
      marcadas: estado.localizada ? estado.localizada.puntos : [],
      estrellaSeleccionada: estado.estrellaSel
    });
    medidas.cuadros++; medidas.ms += (g.performance || Date).now() - t0;
    pintarOrientacion();
  }
  function pintarOrientacion() {
    var L = t(), c = estado.camara;
    el.orientacion.textContent = L.orientacion_actual(
      (Math.round(c.ra * 100) / 100).toFixed(2), Math.round(c.dec), E.aperturaGrados());
  }

  /* ---------------------------------------------------------- cámara ---- */
  function cancelarAnimacion() { if (anim !== null) { cancelAnimationFrame(anim); anim = null; } }
  function congelarCamara() {
    if (anim === null) return false;
    cancelarAnimacion(); E.ajustarCamara(estado.camara); pintar();
    return true;
  }
  function irA(destino) {
    E.ajustarCamara(destino);
    cancelarAnimacion();
    var dur = CFG.MOVIMIENTO[estado.movimiento];
    if (dur <= 0) { estado.camara = destino; pintar(); trasMovimiento(); return; }
    var ini = { ra: estado.camara.ra, dec: estado.camara.dec, fov: estado.camara.fov };
    var dra = destino.ra - ini.ra;
    while (dra > 12) dra -= 24;
    while (dra < -12) dra += 24;
    var t0 = (g.performance || Date).now(), suave = estado.movimiento === 'NORMAL';
    function paso(ahora) {
      var p = Math.min(1, (ahora - t0) / dur);
      var e = suave ? 1 - Math.pow(1 - p, 3) : p;
      estado.camara.ra = (ini.ra + dra * e + 24) % 24;
      estado.camara.dec = ini.dec + (destino.dec - ini.dec) * e;
      estado.camara.fov = ini.fov + (destino.fov - ini.fov) * e;
      pintar();
      if (p < 1) anim = requestAnimationFrame(paso);
      else { anim = null; estado.camara = destino; pintar(); trasMovimiento(); }
    }
    anim = requestAnimationFrame(paso);
  }
  function trasMovimiento() {
    guardarDiferido();
    if (estado.describir) actualizarDescripcion(true);
  }
  function orientar(dra, ddec) {
    var paso = CFG.PASO_TECLADO_GRADOS * (estado.camara.fov / CFG.CAMPO_VISION.inicial);
    paso = Math.min(paso, CFG.PASO_TECLADO_GRADOS);
    var d = { ra: estado.camara.ra + dra * paso / 15 / Math.max(0.2, Math.cos(estado.camara.dec * E.GRADO)),
              dec: estado.camara.dec + ddec * paso, fov: estado.camara.fov };
    irA(E.ajustarCamara(d));
  }
  function ampliar(f, p) {
    var m = medir();
    var d = E.camaraAmpliada(estado.camara, m.W, m.H, estado.camara.fov / f, p);
    if (Math.abs(d.fov - estado.camara.fov) < 1e-9) return;
    irA(d);
  }

  /* -------------------------------------------------------- examinar ---- */
  function examinar(origen, p) {
    if (!cielo) return;
    volverAExplorar(false);
    congelarCamara();
    var m = medir();
    var punto = p || E.centroVista(m.W, m.H);

    if (origen === 'puntero') {
      var e = E.estrellaEn(cielo, estado.camara, m.W, m.H, punto, CFG.TOLERANCIA_ENTRADA_PX, zonasOcluidas());
      if (e && e.datos && e.datos.con && estado.descubiertas[e.datos.con]) { abrirEstrella(e); return; }
    }
    var hechas = {};
    Object.keys(estado.descubiertas).forEach(function (a) { hechas[a] = true; });
    var r = E.examinar(cielo, estado.camara, m.W, m.H, zonasOcluidas(), punto, hechas);
    estado.ultimoExamen = r;
    estado.marca = r.direccion;
    estado.estrellaSel = null;
    estado.plausibles = null;

    if (!r.coincide) {
      var ya = r.detalle.filter(function (d) { return d.excluida && d.sustenta; })
        .sort(function (x, y) { return y.dentro - x.dentro; })[0];
      if (ya) {
        estado.activa = ya.abbr; estado.localizada = null; estado.marca = null;
        estado.mensaje = { tipo: 'ya', abbr: ya.abbr };
      } else if (r.resultado === 'ambiguo') {
        /* C3D-02: no se identifica nada. Se dice que hay más de un patrón y se
           ofrecen las opciones DESCRITAS POR SU SITIO, nunca por su nombre.
           La orientación no se toca. */
        estado.localizada = null;
        estado.plausibles = r.plausibles;
        estado.mensaje = { tipo: 'ambiguo', n: r.plausibles.length };
      } else {
        estado.localizada = null;
        estado.mensaje = { tipo: 'neutral' };
      }
      pintarMensaje(); pintar(); anunciar(textoMensaje());
      if (estado.describir) actualizarDescripcion(false);
      return;
    }
    localizar(r.mejor.abbr, r.mejor.puntos_dentro, origen);
  }

  function localizar(abbr, puntos, origen) {
    var k = porAbbr(abbr);
    estado.localizada = { abbr: abbr, puntos: puntos };
    estado.marca = null;
    estado.mensaje = { tipo: k.especial ? k.especial.tipo : 'localizada', abbr: abbr, n: puntos.length };
    pintarMensaje(); pintar();
    asegurarVisible(el['btn-revelar']);
    if (origen === 'boton') el['btn-revelar'].focus();
    else if (origen === 'escenario') el.escenario.focus();
    anunciar(textoMensaje());
    if (estado.describir) actualizarDescripcion(false);
  }

  /* Identificar NO mueve la cámara, no centra nada y no cambia el zoom. */
  function revelar() {
    if (!estado.localizada) return;
    congelarCamara();
    var abbr = estado.localizada.abbr;
    estado.estados[abbr] = 'revelada';
    estado.descubiertas[abbr] = true;
    estado.activa = abbr;
    estado.lugares[abbr] = { ra: estado.camara.ra, dec: estado.camara.dec, fov: estado.camara.fov };
    estado.localizada = null;
    estado.mensaje = { tipo: 'hallada', abbr: abbr };
    estado.enContextoHallazgo = abbr;
    if (estado.seguirModo) estado.seguirDesde = abbr;
    guardar();
    pintarMensaje(); pintar();
    elegirObjetivo();
    asegurarVisible(el['btn-saber-mas']);
    el['btn-saber-mas'].focus();
    anunciar(t().has_encontrado(nombreDe(abbr)));
  }

  function textoMensaje() {
    var L = t(), m = estado.mensaje;
    if (!m) return '';
    if (m.tipo === 'neutral') return L.sin_patron;
    if (m.tipo === 'ambiguo') return L.ambiguo;
    if (m.tipo === 'cinturon') return L.encontradas_lbl + ' ' + L.es_cinturon;
    if (m.tipo === 'hiades') return L.hiades_lbl + ' ' + L.es_hiades;
    if (m.tipo === 'localizada') return L.localizado(m.n);
    if (m.tipo === 'ya') return L.ya_encontrada(nombreDe(m.abbr));
    return L.has_encontrado(nombreDe(m.abbr));
  }
  function pintarMensaje() {
    var L = t(), m = estado.mensaje;
    el.mensaje.textContent = '';
    el['btn-revelar'].hidden = true; el['btn-revelar'].textContent = '';
    el['btn-saber-mas'].hidden = true; el['btn-saber-mas'].textContent = '';
    el['btn-examinar'].hidden = false;
    if (!m) return;
    if (m.tipo === 'neutral') { el.mensaje.textContent = L.sin_patron; return; }
    if (m.tipo === 'ambiguo') {
      el.mensaje.appendChild(document.createTextNode(L.ambiguo + ' '));
      if (estado.plausibles && estado.plausibles.length) {
        var s = document.createElement('span');
        s.className = 'ig-mensaje-2';
        s.textContent = L.elige_uno;
        el.mensaje.appendChild(s);
        var caja = document.createElement('span');
        caja.className = 'ig-acciones';
        etiquetasPlausibles().forEach(function (o) {
          caja.appendChild(boton(o.texto, function () { elegirAmbigua(o.abbr); }));
        });
        el.mensaje.appendChild(caja);
      }
      return;
    }
    if (m.tipo === 'ya') {
      el.mensaje.textContent = L.ya_encontrada(nombreDe(m.abbr));
      el['btn-saber-mas'].textContent = L.saber_mas; el['btn-saber-mas'].hidden = false;
      return;
    }
    if (m.tipo === 'hallada') {
      el.mensaje.textContent = L.has_encontrado(nombreDe(m.abbr));
      el['btn-saber-mas'].textContent = L.saber_mas; el['btn-saber-mas'].hidden = false;
      return;
    }
    if (m.tipo === 'cinturon' || m.tipo === 'hiades') {
      el.mensaje.appendChild(document.createTextNode(m.tipo === 'cinturon' ? L.encontradas_lbl : L.hiades_lbl));
      var s2 = document.createElement('span');
      s2.className = 'ig-mensaje-2';
      s2.textContent = m.tipo === 'cinturon' ? L.es_cinturon : L.es_hiades;
      el.mensaje.appendChild(s2);
    } else {
      el.mensaje.textContent = L.localizado(m.n);
    }
    el['btn-revelar'].textContent = L.ver_constelacion;
    el['btn-revelar'].hidden = false;
    el['btn-examinar'].hidden = true;
  }
  /* Cada opción se describe por DÓNDE está respecto a lo que se señaló: un
     octante del cielo y una separación angular. Nada de píxeles —cambiarían
     con la pantalla— y nada de nombres —serían el spoiler que se evita. */
  function etiquetasPlausibles() {
    var L = t(), lista = (estado.plausibles || []).map(function (c) {
      return { abbr: c.abbr, dentro: c.dentro,
               texto: L.opcion_lugar(L.octantes[c.octante] || L.octantes.aqui, c.separacion_grados) };
    });
    var cuenta = {};
    lista.forEach(function (o) { cuenta[o.texto] = (cuenta[o.texto] || 0) + 1; });
    lista.forEach(function (o) {
      if (cuenta[o.texto] > 1) o.texto += ' · ' + L.n_estrellas(o.dentro);
    });
    return lista;
  }
  function elegirAmbigua(abbr) {
    var r = estado.ultimoExamen;
    if (!r) return;
    var d = r.detalle.filter(function (x) { return x.abbr === abbr; })[0];
    if (!d) return;
    estado.plausibles = null;
    localizar(abbr, d.puntos_dentro, 'boton');
  }

  /* ------------------------------------------------------------ panel --- */
  function asegurarVisible(nodo) {
    if (!nodo || nodo.hidden) return;
    var r = nodo.getBoundingClientRect();
    var alto = g.innerHeight || document.documentElement.clientHeight;
    if (r.top >= 0 && r.bottom <= alto) return;
    var falta = r.bottom - alto + 8;
    if (falta > 0) g.scrollBy(0, falta); else g.scrollBy(0, r.top - 8);
  }
  function boton(txt, fn, principal) {
    var b = document.createElement('button');
    b.type = 'button';
    b.className = 'ig-btn ig-pequeno' + (principal ? ' ig-primary' : '');
    b.textContent = txt;
    b.addEventListener('click', fn);
    return b;
  }
  function parrafo(txt, cls) {
    var p = document.createElement('p');
    if (cls) p.className = cls;
    p.textContent = txt; return p;
  }
  function h3(txt) { var h = document.createElement('h3'); h.textContent = txt; return h; }
  function valor(v) { return (v && typeof v === 'object' && 'motivo' in v) ? null : v; }
  function texto(v, L) { var x = valor(v); return (x === null || x === undefined || x === '') ? L.sin_dato : x; }
  function filas(pares) {
    var dl = document.createElement('dl');
    dl.className = 'ig-datos';
    pares.forEach(function (p) {
      var dt = document.createElement('dt'); dt.textContent = p[0];
      var dd = document.createElement('dd'); dd.textContent = p[1];
      dl.appendChild(dt); dl.appendChild(dd);
    });
    return dl;
  }
  /* C3D-08. En pantalla ancha la ficha se acopla al lado OPUESTO a lo que se
     acaba de observar, para no taparlo. En pantalla estrecha el cielo se queda
     arriba y la ficha debajo (lo decide el CSS). La orientación no cambia:
     abrir o cerrar la ficha no mueve la cámara. */
  function ladoOpuestoAlHallazgo(abbr) {
    if (!abbr || !cielo || !estado.camara) return 'derecha';
    var k = porAbbr(abbr);
    if (!k) return 'derecha';
    var m = medir();
    var centro = estado.localizada && estado.localizada.abbr === abbr && estado.localizada.puntos.length
      ? estado.localizada.puntos : null;
    var v = k.etiqueta;
    if (centro) {
      var s = { x: 0, y: 0, z: 0 };
      centro.forEach(function (q) { s.x += q.v.x; s.y += q.v.y; s.z += q.v.z; });
      v = E.unitario(s);
    }
    var p = E.aPantalla(v, estado.camara, m.W, m.H);
    if (!p.delante) return 'derecha';
    return p.x > m.W / 2 ? 'izquierda' : 'derecha';
  }
  function abrirPanel(tipo, abbr, origen) {
    if (tipo !== 'ficha') tokenFicha++;
    if (origen) ultimoFoco = origen;
    estado.panel = tipo; estado.panelAbbr = abbr || estado.panelAbbr;
    if (tipo !== 'ficha') estado.seccion = null;
    var wrap = document.querySelector('.ig-escenario-wrap');
    /* El lado se decide al abrir y se conserva mientras la ficha está abierta:
       que el cielo se mueva por detrás no debe hacerla saltar de sitio. */
    estado.ladoPanel = (tipo === 'ficha' || tipo === 'estrella')
      ? ladoOpuestoAlHallazgo(estado.panelAbbr) : 'derecha';
    construirPanel();
    el.panel.hidden = false;
    wrap.classList.add('con-panel');
    wrap.classList.toggle('panel-izquierda', estado.ladoPanel === 'izquierda');
    redimensionar();
    el.panel.focus({ preventScroll: true });
  }
  function cerrarPanel(silencioso) {
    if (!estado.panel) { return; }
    tokenFicha++;
    estado.panel = null; estado.panelAbbr = null; estado.seccion = null; estado.estrellaSel = null;
    el.panel.hidden = true;
    var wrap0 = document.querySelector('.ig-escenario-wrap');
    wrap0.classList.remove('con-panel');
    wrap0.classList.remove('panel-izquierda');
    estado.ladoPanel = 'derecha';
    redimensionar();
    if (silencioso) return;
    var vivo = ultimoFoco && document.contains(ultimoFoco) && !ultimoFoco.hidden && ultimoFoco.offsetParent !== null;
    enfocar(vivo ? ultimoFoco : el.escenario);
  }
  function abrirFicha(abbr, seccion) {
    estado.seccion = seccion || null;
    var mio = ++tokenFicha, dePantalla = estado.pantalla;
    var vigente = function () { return mio === tokenFicha && estado.pantalla === dePantalla; };
    if (g.IG_FICHA && g.IG_FICHA[abbr]) { abrirPanel('ficha', abbr, el['btn-saber-mas']); return; }
    var s = document.createElement('script');
    s.src = 'datos/fichas/' + abbr + '.js';
    s.onload = function () { if (vigente()) abrirPanel('ficha', abbr, el['btn-saber-mas']); };
    s.onerror = function () { if (vigente()) mostrarAviso(t().aviso_recurso); };
    document.head.appendChild(s);
  }
  /* Cuaderno de hallazgos: lo encontrado y DÓNDE se encontró. Volver a un
     hallazgo devuelve la misma orientación y el mismo acercamiento que tenía
     cuando se encontró; no re-centra ni reencuadra nada por su cuenta. */
  function volverAlLugar(abbr) {
    var l = estado.lugares[abbr];
    if (!l) return;
    cerrarPanel(true);
    estado.activa = abbr;
    estado.localizada = null; estado.marca = null;
    estado.mensaje = { tipo: 'ya', abbr: abbr };
    /* Volver a mirar algo ya encontrado no es acabar de encontrarlo: arriba
       vuelve la pista de lo que falta, no el contexto del hallazgo anterior. */
    estado.enContextoHallazgo = false;
    pintarObjetivo();
    pintarMensaje();
    irA(E.ajustarCamara({ ra: l.ra, dec: l.dec, fov: l.fov }));
    anunciar(t().vuelto_al_lugar(nombreDe(abbr)));
    enfocar(el.escenario);
  }
  function abrirCuaderno() {
    if (estado.panel === 'cuaderno') { cerrarPanel(); return; }
    abrirPanel('cuaderno', null, el['btn-cuaderno']);
  }
  function abrirEstrella(e) { estado.estrellaSel = e; abrirPanel('estrella', estado.panelAbbr, null); pintar(); }

  function construirPanel() {
    var L = t(), cuerpo = el['panel-cuerpo'];
    cuerpo.textContent = '';
    el['btn-cerrar-panel'].textContent = L.cerrar;
    var acc = document.createElement('div');
    acc.className = 'ig-acciones';

    if (estado.panel === 'cuaderno') {
      var via = recorrido();
      var hechas = via.filter(function (a) { return estado.descubiertas[a]; });
      /* También lo encontrado fuera del recorrido sugerido. */
      Object.keys(estado.descubiertas).forEach(function (a) {
        if (via.indexOf(a) < 0) hechas.push(a);
      });
      el['panel-titulo'].textContent = L.cuaderno;
      cuerpo.appendChild(parrafo(L.cuaderno_progreso(hechas.length, cielo.constelaciones.length), 'ig-nota'));
      if (!hechas.length) cuerpo.appendChild(parrafo(L.cuaderno_vacio, 'ig-nota'));
      hechas.forEach(function (a) {
        var fila = document.createElement('div');
        fila.className = 'ig-cuaderno-fila';
        var h = document.createElement('h3');
        h.className = 'ig-cuaderno-nombre'; h.textContent = nombreDe(a);
        fila.appendChild(h);
        var l = estado.lugares[a];
        fila.appendChild(parrafo(l
          ? L.encontrado_en((Math.round(l.ra * 100) / 100).toFixed(2), Math.round(l.dec), Math.round(l.fov))
          : L.sin_lugar, 'ig-nota'));
        var acc2 = document.createElement('div');
        acc2.className = 'ig-acciones';
        if (l) acc2.appendChild(boton(L.volver_al_lugar, function () { volverAlLugar(a); }));
        acc2.appendChild(boton(L.saber_mas, function () { abrirFicha(a, null); }));
        fila.appendChild(acc2);
        cuerpo.appendChild(fila);
      });
      acc.appendChild(boton(L.cerrar, function () { cerrarPanel(); }, true));

    } else if (estado.panel === 'fuentes') {
      el['panel-titulo'].textContent = L.fuentes;
      var ul = document.createElement('ul');
      Object.keys(cielo.meta.fuentes).forEach(function (k) {
        var li = document.createElement('li'); li.textContent = cielo.meta.fuentes[k]; ul.appendChild(li);
      });
      cuerpo.appendChild(ul);
      cuerpo.appendChild(parrafo(cielo.meta.nota, 'ig-nota'));
      cuerpo.appendChild(parrafo(cielo.meta.convencion_ejes, 'ig-nota'));
      acc.appendChild(boton(L.cerrar, function () { cerrarPanel(); }, true));

    } else if (estado.panel === 'estrella') {
      var e = estado.estrellaSel, d = e && e.datos;
      el['panel-titulo'].textContent = (d && (d.n || d.d)) || L.estrella;
      if (!d) cuerpo.appendChild(parrafo(L.estrella_sin_datos, 'ig-nota'));
      else cuerpo.appendChild(filas([
        [L.col_designacion, d.d || L.sin_dato], [L.col_nombre, d.n || L.sin_dato],
        [L.col_magnitud, String(e.mag)],
        [L.col_distancia, d.ly ? (d.ly + ' ' + L.anios_luz) : L.sin_dato],
        [L.col_tipo, d.sp || L.sin_dato]]));
      acc.appendChild(boton(L.seguir_explorando, function () { cerrarPanel(); }, true));

    } else if (estado.panel === 'ficha') {
      var f = g.IG_FICHA[estado.panelAbbr];
      el['panel-titulo'].textContent = estado.idioma === 'es' ? f.nombre_es : f.nombre_en;
      cuerpo.appendChild(parrafo(f.denominacion_canonica + ' · ' + f.genitivo, 'ig-nota'));
      if (!estado.seccion) {
        var k = porAbbr(estado.panelAbbr);
        if (k.especial) cuerpo.appendChild(parrafo(k.especial.nota));
        var idea = estado.idioma === 'es' ? valor(f.descriptor_es) : valor(f.descriptor_en);
        if (!idea && estado.idioma === 'es') idea = valor(f.significado_es);
        if (idea) cuerpo.appendChild(parrafo(L.idea_breve(idea)));
        if (k.relacion) cuerpo.appendChild(parrafo(k.relacion.nota + ' ' +
          '(' + k.relacion.separacion_grados + '°, desviación ' + k.relacion.desviacion_de_la_linea_del_cinturon_grados + '°)', 'ig-nota'));
        cuerpo.appendChild(h3(L.estrellas_relevantes));
        cuerpo.appendChild(filas(f.estrellas_principales.slice(0, 3).map(function (s) {
          var n = texto(s.nombre_propio, L);
          return [n === L.sin_dato ? texto(s.designacion, L) : n, L.magnitud_valor(s.magnitud_aparente)];
        })));
        cuerpo.appendChild(h3(L.mas_detalle));
        [['reconocer', L.sec_reconocer], ['estrellas', L.sec_estrellas], ['region', L.sec_region],
         ['visibilidad', L.sec_visibilidad], ['material', L.sec_material], ['fuentes', L.sec_fuentes]]
          .forEach(function (s) { acc.appendChild(boton(s[1], function () { abrirFicha(estado.panelAbbr, s[0]); })); });
        acc.appendChild(boton(L.seguir_explorando, function () { cerrarPanel(); volverAExplorar(); }, true));
      } else {
        cuerpo.appendChild(seccion(f, estado.seccion, L));
        acc.appendChild(boton(L.volver_al_resumen, function () { abrirFicha(estado.panelAbbr, null); }));
        acc.appendChild(boton(L.seguir_explorando, function () { cerrarPanel(); volverAExplorar(); }, true));
      }
    }
    cuerpo.appendChild(acc);
  }
  function seccion(f, sec, L) {
    var box = document.createElement('div');
    if (sec === 'reconocer') {
      box.appendChild(h3(L.sec_reconocer));
      box.appendChild(parrafo(f.como_reconocerlo[estado.idioma]));
      box.appendChild(parrafo(f.como_reconocerlo.derivacion, 'ig-nota'));
    } else if (sec === 'estrellas') {
      box.appendChild(h3(L.sec_estrellas));
      f.estrellas_principales.slice(0, 10).forEach(function (s) {
        var n = texto(s.nombre_propio, L);
        var h = document.createElement('p');
        h.className = 'ig-estrella-nombre';
        h.textContent = n === L.sin_dato ? texto(s.designacion, L) : n;
        box.appendChild(h);
        box.appendChild(filas([
          [L.col_designacion, texto(s.designacion, L)],
          [L.col_magnitud, L.magnitud_valor(s.magnitud_aparente)],
          [L.col_distancia, valor(s.distancia_anios_luz) === null ? L.sin_dato : valor(s.distancia_anios_luz) + ' ' + L.anios_luz],
          [L.col_tipo, texto(s.tipo_espectral, L)]]));
      });
      box.appendChild(parrafo(f.fuentes.estrellas, 'ig-nota'));
    } else if (sec === 'region') {
      box.appendChild(h3(L.sec_region));
      box.appendChild(parrafo(estado.idioma === 'es' ? f.dibujo_de_lineas.nota_es : f.dibujo_de_lineas.nota_en));
      box.appendChild(parrafo(estado.idioma === 'es' ? f.region_oficial.nota_es : f.region_oficial.nota_en));
      box.appendChild(filas([[L.r_area, f.region_oficial.area_grados_cuadrados + ' ' + L.grados_cuadrados]]));
    } else if (sec === 'visibilidad') {
      box.appendChild(h3(L.sec_visibilidad));
      var mv = valor(f.visibilidad_documentada.mejor_mes);
      box.appendChild(filas([
        [L.r_mes, mv ? (estado.idioma === 'es' ? mv.es : mv.en) : L.sin_dato],
        [L.r_peninsula, texto(f.visibilidad_documentada.desde_la_peninsula, L)],
        [L.r_canarias, texto(f.visibilidad_documentada.desde_canarias, L)]]));
      box.appendChild(parrafo(f.visibilidad_documentada.nota, 'ig-nota'));
    } else if (sec === 'material') {
      box.appendChild(h3(L.sec_material));
      var img = document.createElement('img');
      img.alt = estado.idioma === 'es' ? f.material_visual.alt_es : f.material_visual.alt_en;
      img.loading = 'lazy';
      img.onerror = function () { img.remove(); box.appendChild(parrafo(t().aviso_recurso, 'ig-nota')); };
      img.src = f.material_visual.svg;
      box.appendChild(img);
      box.appendChild(parrafo(estado.idioma === 'es' ? f.material_visual.pie_es : f.material_visual.pie_en, 'ig-nota'));
    } else if (sec === 'fuentes') {
      box.appendChild(h3(L.sec_fuentes));
      var ul = document.createElement('ul');
      [f.fuentes.estrellas, f.fuentes.nombres, f.fuentes.constelaciones,
       f.fuentes.figura_r03, f.fuentes.region_oficial, f.fuentes.master_visual].forEach(function (x) {
        if (!x) return;
        var li = document.createElement('li'); li.textContent = x; ul.appendChild(li);
      });
      box.appendChild(ul);
    }
    return box;
  }

  /* ------------------------------------------------------ descripción --- */
  var SECT = ['e', 'se', 's', 'so', 'o', 'no', 'n', 'ne'];
  function actualizarDescripcion(anunciarla) {
    if (!cielo || !estado.camara) return;
    var m = medir(), L = t();
    var base = E.baseCamara(estado.camara);
    var punto = estado.ultimoExamen ? estado.ultimoExamen.punto : E.centroVista(m.W, m.H);
    var dir = E.dePantalla(punto, estado.camara, m.W, m.H, base);
    var zonas = zonasOcluidas();
    var enZona = [], enVista = [];
    cielo.estrellas.forEach(function (e) {
      var s = E.aPantalla(e.v, estado.camara, m.W, m.H, base);
      if (!E.esVisible(s, m.W, m.H, zonas)) return;
      enVista.push({ e: e, x: s.x, y: s.y });
      if (E.enEvidencia(dir, e.v)) enZona.push({ e: e, x: s.x, y: s.y });
    });
    var brillantes = enZona.filter(function (p) { return p.e.mag <= CFG.UMBRAL_BRILLANTE; });
    var partes = [enZona.length ? L.desc_puntos(enZona.length) : L.desc_vacia];
    if (brillantes.length) partes.push(L.desc_brillantes(brillantes.length));
    var r = E.examinar(cielo, estado.camara, m.W, m.H, zonas, punto, {});
    if (r.coincide) partes.push(L.desc_forma(r.mejor.dentro));
    el['descripcion-region'].textContent = partes.join(' ');

    var cuenta = {};
    enVista.forEach(function (p) {
      if (p.e.mag > CFG.UMBRAL_BRILLANTE) return;
      if (E.enEvidencia(dir, p.e.v)) return;
      var i = ((Math.round(Math.atan2(p.y - punto.y, p.x - punto.x) / (Math.PI / 4)) % 8) + 8) % 8;
      cuenta[SECT[i]] = (cuenta[SECT[i]] || 0) + 1;
    });
    var mejor = null;
    Object.keys(cuenta).forEach(function (k) { if (!mejor || cuenta[k] > cuenta[mejor]) mejor = k; });
    el['descripcion-entorno'].textContent =
      ((mejor && cuenta[mejor] >= 2) ? L.desc_fuera(L.dir[mejor]) : L.desc_fuera_nada) +
      ' ' + L.desc_apertura(r.apertura_grados);
    if (anunciarla) anunciar(el['descripcion-region'].textContent);
  }
  function anunciar(txt) {
    if (tAnuncio) clearTimeout(tAnuncio);
    tAnuncio = setTimeout(function () {
      el.anuncio.textContent = ''; el.anuncio.textContent = txt; tAnuncio = null;
    }, 320);
  }
  function mostrarAviso(txt) { el.aviso.textContent = txt; el.aviso.hidden = false; }
  /* Un aviso que se vuelve a escribir al cambiar de idioma, en vez de quedarse
     congelado en el idioma en el que saltó. */
  function avisar(clave) { avisoClave = clave; mostrarAviso(t()[clave]); }

  /* ----------------------------------------------------------- idioma --- */
  function aplicarIdioma() {
    var L = t();
    document.documentElement.lang = L.lang;
    document.title = L.titulo_documento;
    var n = document.querySelectorAll('[data-t]');
    for (var i = 0; i < n.length; i++) {
      var k = n[i].getAttribute('data-t');
      if (typeof L[k] === 'string') n[i].textContent = L[k];
    }
    var ma = document.querySelectorAll('[data-ta]');
    for (var j = 0; j < ma.length; j++) {
      var c = ma[j].getAttribute('data-ta');
      if (L[c]) ma[j].setAttribute('aria-label', L[c]);
    }
    if (avisoClave) mostrarAviso(L[avisoClave]);
    el['btn-volver-portada'].textContent = L.volver_a_la_portada;
    el['btn-capa'].textContent = L.mis_hallazgos;
    el['btn-cuaderno'].textContent = L.cuaderno;
    el.escenario.setAttribute('aria-label', L.titulo);
    pintarSelectorRutas();
    if (estado.pantalla === 'portada') pintarPortada();
    if (estado.pantalla === 'escena' && estado.camara) {
      pintarObjetivo(); pintarMensaje(); pintarOrientacion(); pintar();
    }
    if (estado.panel) construirPanel();
    if (estado.describir) actualizarDescripcion(false);
  }
  function actualizarPulsados() {
    document.querySelectorAll('[data-idioma]').forEach(function (b) {
      b.setAttribute('aria-pressed', String(b.getAttribute('data-idioma') === estado.idioma));
    });
    el['sel-movimiento'].value = estado.movimiento;
    if (el['sel-ruta'] && estado.rutaId) el['sel-ruta'].value = estado.rutaId;
    el['btn-describir'].setAttribute('aria-pressed', String(estado.describir));
    el['btn-capa'].setAttribute('aria-pressed', String(estado.capaHallazgos));
  }

  /* ---------------------------------------------------------- diálogo --- */
  function abrirDialogo(op) {
    dialogo = op;
    el['dialogo-titulo'].textContent = op.titulo;
    el['dialogo-texto'].textContent = op.texto;
    el['dialogo-cancelar'].textContent = op.cancelar;
    el['dialogo-confirmar'].textContent = op.confirmar;
    el.velo.hidden = false; el.dialogo.hidden = false;
    document.querySelector('.ig-app').setAttribute('inert', '');
    enfocar(el['dialogo-cancelar']);
  }
  function cerrarDialogo(ok) {
    if (!dialogo) return;
    var op = dialogo; dialogo = null;
    el.dialogo.hidden = true; el.velo.hidden = true;
    document.querySelector('.ig-app').removeAttribute('inert');
    enfocar(op.origen && document.contains(op.origen) ? op.origen : el.escenario);
    if (ok && op.alConfirmar) op.alConfirmar();
  }
  function borrarHallazgos() {
    estado.descubiertas = {}; estado.lugares = {}; estado.estados = {};
    estado.activa = null; estado.localizada = null; estado.mensaje = null;
    estado.enContextoHallazgo = false; estado.seguirModo = false; estado.seguirDesde = null;
    estado.plausibles = null; estado.ultimoExamen = null;
    if (estado.panel === 'cuaderno') cerrarPanel(true);
    /* En sólo lectura se limpia esta sesión y NO se toca lo guardado: borrar lo
       de aquí no autoriza a destruir lo de una versión que no entendemos. */
    if (!soloLectura) { try { localStorage.removeItem(CFG.CLAVE_GUARDADO); } catch (e) {} }
    if (estado.pantalla === 'escena') { elegirObjetivo(); pintarMensaje(); pintar(); }
    if (estado.pantalla === 'portada') pintarPortada();
    anunciar(soloLectura ? t().borrado_hecho_solo_lectura : t().borrado_hecho);
  }

  /* ---------------------------------------------------------- eventos --- */
  function enlazar() {
    el['btn-empezar'].addEventListener('click', function () { abrirEscena(false); });
    el['btn-continuar'].addEventListener('click', function () { abrirEscena(true); });
    el['btn-volver-portada'].addEventListener('click', function () {
      cancelarAnimacion(); estado.camaraGuardada = estado.camara; guardar();
      cerrarPanel(true); mostrarPantalla('portada');
    });
    el['btn-continuar-pista'].addEventListener('click', function () { volverAExplorar(); });
    el['btn-seguir-desde'].addEventListener('click', activarSeguirDesde);
    el['sel-ruta'].addEventListener('change', function () {
      if (!rutaPorId(el['sel-ruta'].value)) return;
      estado.rutaId = el['sel-ruta'].value;
      estado.seguirModo = false; estado.seguirDesde = null;
      elegirObjetivo(); pintarSelectorRutas(); pintarPortada(); guardar();
    });
    el['btn-examinar'].addEventListener('click', function () {
      /* Con el ratón, este botón examina el centro pero NO convierte el centro
         en la metáfora: la marca aparece sólo si se está usando el teclado. */
      estado.tecladoActivo = (ultimaEntrada === 'teclado');
      examinar('boton');
    });
    el['btn-examinar'].addEventListener('focus', function () {
      if (focoProgramatico || ultimaEntrada !== 'teclado') return;
      estado.tecladoActivo = true; pintar();
    });
    el['btn-revelar'].addEventListener('click', revelar);
    el['btn-saber-mas'].addEventListener('click', function () {
      if (estado.mensaje && estado.mensaje.abbr) abrirFicha(estado.mensaje.abbr);
    });
    el['btn-cerrar-panel'].addEventListener('click', function () { cerrarPanel(); });
    el['btn-capa'].addEventListener('click', function () {
      estado.capaHallazgos = !estado.capaHallazgos;
      actualizarPulsados(); pintar();
      anunciar(estado.capaHallazgos ? t().capa_encendida : t().capa_apagada);
    });
    el['btn-cuaderno'].addEventListener('click', abrirCuaderno);
    el['btn-describir'].addEventListener('click', function () {
      estado.describir = !estado.describir;
      el.descripcion.hidden = !estado.describir;
      actualizarPulsados();
      if (estado.describir) actualizarDescripcion(true);
    });
    el['btn-fuentes'].addEventListener('click', function () {
      if (estado.pantalla === 'escena') {
        if (estado.panel === 'fuentes') cerrarPanel(); else abrirPanel('fuentes', null, el['btn-fuentes']);
        return;
      }
      var caja = el['fuentes-fuera'];
      if (!caja.hidden) { caja.hidden = true; return; }
      caja.textContent = '';
      var h = document.createElement('h2');
      h.className = 'ig-h2'; h.textContent = t().fuentes;
      caja.appendChild(h);
      var ul = document.createElement('ul');
      Object.keys(cielo.meta.fuentes).forEach(function (k) {
        var li = document.createElement('li'); li.textContent = cielo.meta.fuentes[k]; ul.appendChild(li);
      });
      caja.appendChild(ul);
      caja.appendChild(parrafo(cielo.meta.nota, 'ig-nota'));
      caja.hidden = false; caja.setAttribute('tabindex', '-1'); caja.focus();
    });
    el['btn-borrar'].addEventListener('click', function () {
      var L = t();
      abrirDialogo({ titulo: L.borrar_hallazgos, texto: L.borrar_aviso,
                     confirmar: L.borrar_confirmar, cancelar: L.cancelar,
                     origen: el['btn-borrar'], alConfirmar: borrarHallazgos });
    });
    el['dialogo-cancelar'].addEventListener('click', function () { cerrarDialogo(false); });
    el['dialogo-confirmar'].addEventListener('click', function () { cerrarDialogo(true); });
    el.velo.addEventListener('click', function () { cerrarDialogo(false); });
    document.addEventListener('keydown', function (ev) {
      if (!dialogo) return;
      if (ev.key === 'Escape') { cerrarDialogo(false); ev.preventDefault(); return; }
      if (ev.key !== 'Tab') return;
      var f = [el['dialogo-cancelar'], el['dialogo-confirmar']];
      var i = f.indexOf(document.activeElement);
      enfocar(f[ev.shiftKey ? (i <= 0 ? f.length - 1 : i - 1) : (i === f.length - 1 ? 0 : i + 1)]);
      ev.preventDefault();
    }, true);

    document.querySelectorAll('[data-idioma]').forEach(function (b) {
      b.addEventListener('click', function () {
        estado.idioma = b.getAttribute('data-idioma');
        actualizarPulsados(); aplicarIdioma();
      });
    });
    el['sel-movimiento'].addEventListener('change', function () {
      estado.movimiento = el['sel-movimiento'].value;
      estado.movimientoExplicito = true;
      congelarCamara(); pintar(); guardar();
      anunciar(t().movimiento_cambiado);
    });
    document.querySelectorAll('[data-orientar]').forEach(function (b) {
      b.addEventListener('click', function () {
        var d = b.getAttribute('data-orientar');
        orientar(d === 'izquierda' ? 1 : (d === 'derecha' ? -1 : 0),
                 d === 'arriba' ? 1 : (d === 'abajo' ? -1 : 0));
        anunciar(t().vista_movida);
      });
    });
    document.querySelectorAll('[data-zoom]').forEach(function (b) {
      b.addEventListener('click', function () {
        ampliar(b.getAttribute('data-zoom') === 'acercar' ? CFG.CAMPO_VISION.paso : 1 / CFG.CAMPO_VISION.paso);
      });
    });

    el.escenario.addEventListener('keydown', function (ev) {
      if (ev.target !== el.escenario || !cielo) return;
      if (ev.ctrlKey || ev.metaKey || ev.altKey) return;
      var k = ev.key, hecho = true;
      if (k === 'ArrowLeft') orientar(1, 0);
      else if (k === 'ArrowRight') orientar(-1, 0);
      else if (k === 'ArrowUp') orientar(0, 1);
      else if (k === 'ArrowDown') orientar(0, -1);
      else if (k === '+' || k === '=') ampliar(CFG.CAMPO_VISION.paso);
      else if (k === '-' || k === '_') ampliar(1 / CFG.CAMPO_VISION.paso);
      else if (k === 'Enter') examinar('escenario');
      else hecho = false;
      if (hecho) { estado.tecladoActivo = true; estado.ruedaArmada = true; pintar(); ev.preventDefault(); }
    });
    /* Una tecla real —cualquiera— declara que se está usando el teclado. */
    document.addEventListener('keydown', function (ev) {
      ultimaEntrada = 'teclado';
      if (ev.key === 'Escape' && estado.panel && !dialogo) { cerrarPanel(); ev.preventDefault(); }
    }, true);
    document.addEventListener('pointerdown', function () { ultimaEntrada = 'puntero'; }, true);
    el.escenario.addEventListener('focus', function () {
      estado.tecladoActivo = (!focoProgramatico && ultimaEntrada === 'teclado');
      if (!focoProgramatico) estado.ruedaArmada = true;
      pintar();
    });
    el.escenario.addEventListener('blur', function () {
      if (document.activeElement !== el['btn-examinar']) { estado.tecladoActivo = false; pintar(); }
    });

    /* ---- puntero: arrastrar orienta, pulsar selecciona ------------------ */
    function puntoEn(ev) {
      var c = el.lienzo.getBoundingClientRect();
      return { x: ev.clientX - c.left, y: ev.clientY - c.top };
    }
    function ids() { return Object.keys(punteros); }
    function n() { return ids().length; }
    function centroDedos() {
      var c = el.lienzo.getBoundingClientRect(), xs = 0, ys = 0;
      ids().forEach(function (i) { xs += punteros[i].x; ys += punteros[i].y; });
      return { x: xs / n() - c.left, y: ys / n() - c.top };
    }
    function distDedos() {
      var k = ids();
      if (k.length < 2) return 0;
      return Math.hypot(punteros[k[0]].x - punteros[k[1]].x, punteros[k[0]].y - punteros[k[1]].y);
    }

    el.lienzo.addEventListener('pointerdown', function (ev) {
      if (ev.button !== undefined && ev.button !== 0) return;
      estado.ruedaArmada = true;
      var m = medir();
      punteros[ev.pointerId] = { x: ev.clientX, y: ev.clientY,
        inicio: { x: ev.clientX, y: ev.clientY }, arrastrado: false,
        dir: E.dePantalla(puntoEn(ev), estado.camara, m.W, m.H) };
      if (n() >= 2) { gestoMulti = true; pinza = { dist: distDedos(), fov: estado.camara.fov }; }
      try { el.lienzo.setPointerCapture(ev.pointerId); } catch (e) {}
    });

    el.lienzo.addEventListener('pointermove', function (ev) {
      var p = punteros[ev.pointerId];
      if (!p || !cielo) return;
      p.x = ev.clientX; p.y = ev.clientY;
      var m = medir();
      if (n() >= 2 && pinza) {
        var d = distDedos();
        if (pinza.dist > 10) {
          var fov = pinza.fov * (pinza.dist / Math.max(1, d));
          var c = centroDedos();
          cancelarAnimacion();
          estado.camara = E.camaraAmpliada(estado.camara, m.W, m.H, fov, c);
          pintar();
        }
        return;
      }
      if (!p.arrastrado) {
        /* Tap o arrastre se deciden por DESPLAZAMIENTO, nunca por tiempo: una
           pulsación quieta sigue siendo una pulsación aunque dure. */
        if (Math.hypot(ev.clientX - p.inicio.x, ev.clientY - p.inicio.y) < CFG.UMBRAL_ARRASTRE) return;
        p.arrastrado = true;
        el.lienzo.classList.add('orientando');
      }
      cancelarAnimacion();
      estado.camara = E.ajustarCamara(E.camaraQueLleva(estado.camara, m.W, m.H, p.dir, puntoEn(ev)));
      pintar();
    });

    function soltar(ev, cancelado) {
      var p = punteros[ev.pointerId];
      if (!p) return;
      delete punteros[ev.pointerId];
      if (n() < 2) pinza = null;
      var m = medir();
      ids().forEach(function (i) {       /* el dedo que queda empieza de cero */
        punteros[i].inicio = { x: punteros[i].x, y: punteros[i].y };
        punteros[i].arrastrado = true;
        punteros[i].dir = E.dePantalla({ x: punteros[i].x - el.lienzo.getBoundingClientRect().left,
                                         y: punteros[i].y - el.lienzo.getBoundingClientRect().top },
                                       estado.camara, m.W, m.H);
      });
      if (n() === 0) {
        el.lienzo.classList.remove('orientando');
        var fueMulti = gestoMulti;
        gestoMulti = false;
        if (cancelado || p.arrastrado || fueMulti) { trasMovimiento(); return; }
        estado.tecladoActivo = false;
        examinar('puntero', puntoEn(ev));
      }
    }
    el.lienzo.addEventListener('pointerup', function (ev) { soltar(ev, false); });
    el.lienzo.addEventListener('pointercancel', function (ev) { soltar(ev, true); });

    el.lienzo.addEventListener('wheel', function (ev) {
      if (!cielo) return;
      if (CFG.RUEDA_REQUIERE_FOCO && (document.activeElement !== el.escenario || !estado.ruedaArmada)) return;
      ev.preventDefault();
      ampliar(ev.deltaY < 0 ? CFG.CAMPO_VISION.paso : 1 / CFG.CAMPO_VISION.paso, puntoEn(ev));
    }, { passive: false });

    g.addEventListener('resize', function () {
      if (tResize) clearTimeout(tResize);
      tResize = setTimeout(function () {
        tResize = null;
        redimensionar();
        if (!estado.panel) return;
        if (el.panel.contains(document.activeElement)) return;   /* no le quites el foco a nadie */
        var antes = document.activeElement;
        construirPanel();
        if (antes && document.contains(antes) && antes.offsetParent !== null) enfocar(antes);
      }, 120);
    });
    /* Al ocultar la pestaña no queda nada corriendo: no hay bucle continuo. */
    document.addEventListener('visibilitychange', function () {
      if (document.hidden) { cancelarAnimacion(); guardar(); }
    });
    g.addEventListener('pagehide', function () { cancelarAnimacion(); guardar(); });
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(function () { if (cielo && estado.camara) pintar(); });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', iniciar);
  else iniciar();

  g.IG_DEBUG = {
    estado: estado, cielo: function () { return cielo; }, medir: medir,
    hayAnimacion: function () { return anim !== null; },
    punterosActivos: function () { return Object.keys(punteros).length; },
    punterosIds: function () { return Object.keys(punteros).map(Number); },
    ocluidas: zonasOcluidas,
    medidas: function () { return { cuadros: medidas.cuadros, ms: Math.round(medidas.ms),
                                    ms_por_cuadro: medidas.cuadros ? Math.round(medidas.ms / medidas.cuadros * 100) / 100 : 0 }; },
    reiniciarMedidas: function () { medidas = { cuadros: 0, ms: 0 }; },
    examinarEn: function (p, excluir) {
      var m = medir();
      return E.examinar(cielo, estado.camara, m.W, m.H, zonasOcluidas(), p, excluir || {});
    },
    pantallaDe: function (abbr, i) {
      var m = medir(), k = cielo.porAbbr[abbr];
      var v = (i === undefined) ? k.etiqueta : k.puntos[i].v;
      return E.aPantalla(v, estado.camara, m.W, m.H);
    },
    abrirEscena: abrirEscena, abrirFichaDePrueba: abrirFicha,
    recorrido: recorrido, rutaActiva: rutaActiva, siguienteDesde: siguienteDesde,
    elegirObjetivo: elegirObjetivo, activarSeguirDesde: activarSeguirDesde,
    pistaDe: textoPista, etiquetasPlausibles: etiquetasPlausibles,
    ladoPanel: function () { return estado.ladoPanel; },
    soloLectura: function () { return soloLectura; },
    camaraInicial: camaraInicial,
    ultimaEntrada: function () { return ultimaEntrada; },
    abrirCuaderno: abrirCuaderno, volverAlLugar: volverAlLugar
  };
})(window);
