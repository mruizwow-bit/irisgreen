#!/usr/bin/env node
const fs=require('fs'), vm=require('vm'), path=require('path');
const ROOT=path.resolve(__dirname,'..');
const CFG=require(path.join(ROOT,'js','config.js'));
global.window={IG_CONFIG:CFG};
const E=require(path.join(ROOT,'js','esfera.js'));
function loadData(){
  const src=fs.readFileSync(path.join(ROOT,'datos','cielo3d.js'),'utf8');
  const ctx={window:{}}; vm.createContext(ctx); vm.runInContext(src,ctx); return ctx.window.IG3D;
}
const data=loadData(), sky=E.construirCielo(data);
const W=1440,H=900,center={x:W/2,y:H/2};
function coords(v){return E.aCoordenadas(v)}
function camAt(v){const c=coords(v);return {ra:c.ra,dec:c.dec,fov:60}}
function avg(vs){let s={x:0,y:0,z:0};vs.forEach(v=>{s.x+=v.x;s.y+=v.y;s.z+=v.z});return E.unitario(s)}
function candidates(k){
  const out=[];
  k.observables.forEach(i=>out.push(k.puntos[i].v));
  k.aristas.forEach(a=>{if(k.puntos[a[0]].observable&&k.puntos[a[1]].observable)out.push(avg([k.puntos[a[0]].v,k.puntos[a[1]].v]))});
  for(let i=0;i<k.puntos.length;i++){
    if(!k.puntos[i].observable)continue;
    const ns=k.vecinosObs[i]||[];
    for(let x=0;x<ns.length;x++)for(let y=x+1;y<ns.length;y++){
      const j=ns[x],l=ns[y]; if(!k.puntos[j].observable||!k.puntos[l].observable)continue;
      out.push(avg([k.puntos[i].v,k.puntos[j].v,k.puntos[l].v]));
    }
  }
  return out;
}
const per=[];
for(const k of sky.constelaciones){
  let best=null, counts={unico_correcto:0,ambiguo_con_objetivo:0,unico_otro:0,ninguno:0};
  for(const v of candidates(k)){
    const r=E.examinar(sky,camAt(v),W,H,[],center,{});
    let typ='ninguno';
    if(r.resultado==='unico')typ=r.mejor.abbr===k.abbr?'unico_correcto':'unico_otro';
    else if(r.resultado==='ambiguo')typ=r.plausibles.some(p=>p.abbr===k.abbr)?'ambiguo_con_objetivo':'ninguno';
    counts[typ]++;
    const score=(typ==='unico_correcto'?4:typ==='ambiguo_con_objetivo'?3:typ==='ninguno'?1:0)*100+(r.mejor&&r.mejor.abbr===k.abbr?r.mejor.dentro:0);
    if(!best||score>best.score)best={score,typ,result:r};
  }
  per.push({abbr:k.abbr,points:k.puntos.length,observable:k.observables.length,non_observable:k.no_observables,
            minimo:E.minimoSemantico(k),minimoPosible:k.minimoPosible,counts,
            best:best?{type:best.typ,resultado:best.result.resultado,mejor:best.result.mejor&&best.result.mejor.abbr,
                       plausibles:best.result.plausibles.map(x=>x.abbr)}:null});
}
// global grid
let grid={samples:0,ninguno:0,unico:0,ambiguo:0,max_candidates:0};
const ambiguity=[];
for(let dec=-80;dec<=80;dec+=5){
  for(let ra=0;ra<24;ra+=0.5){
    const r=E.examinar(sky,{ra,dec,fov:60},W,H,[],center,{});
    grid.samples++;grid[r.resultado]=(grid[r.resultado]||0)+1;grid.max_candidates=Math.max(grid.max_candidates,r.candidatas||0);
    if(r.resultado==='ambiguo'&&ambiguity.length<250)ambiguity.push({ra,dec,plausibles:r.plausibles});
  }
}
const large=['Hya','Eri','Ser','Vir','UMa'].map(ab=>per.find(x=>x.abbr===ab));
const noUnique=per.filter(x=>x.best.type!=='unico_correcto');
const wrong=per.filter(x=>x.counts.unico_otro>0);
const noobs=sky.constelaciones.filter(k=>k.no_observables).map(k=>({abbr:k.abbr,n:k.no_observables,minimo:E.minimoSemantico(k),minimoPosible:k.minimoPosible}));
const report={
 gate_candidate:'SKY_SCALE_01_02_PRECHECK',
 counts:{constellations:sky.constelaciones.length,stars:sky.estrellas.length,routes:data.rutas.length},
 large_scale:large,
 identification:{unique_possible:88-noUnique.length,no_unique:noUnique,with_wrong_unique_samples:wrong.length,wrong:wrong},
 ambiguity_grid:grid,ambiguity_examples:ambiguity.slice(0,40),non_observable:noobs,
 pass_data:sky.constelaciones.length===88&&sky.estrellas.length===3248
};
fs.mkdirSync(path.join(ROOT,'evidence'),{recursive:true});
fs.writeFileSync(path.join(ROOT,'evidence','SKY_SCALE_01_02_PRECHECK.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({counts:report.counts,large_scale:large,unique_possible:report.identification.unique_possible,
 no_unique:noUnique.map(x=>x.abbr),wrong:wrong.map(x=>x.abbr),ambiguity_grid:grid,non_observable:noobs},null,2));
