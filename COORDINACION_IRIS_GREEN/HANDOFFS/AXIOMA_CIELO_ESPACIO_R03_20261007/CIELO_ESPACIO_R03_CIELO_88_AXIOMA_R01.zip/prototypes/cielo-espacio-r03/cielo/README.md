# Cielo y Espacio R03 · Cielo nocturno 88/88 · build de relevo Axioma

Estado: `AXIOMA_TEMP_COVER_CIELO_ESPACIO_R03_ACTIVE`

Base LOCKED:
- `CIELO_3D_R02_1.zip`
- SHA-256 `1f7e6ac7aab0b56d88b880375049a621bb85d9e0bc74105366f1d71073423ba8`

Este directorio es el primer bloque de `CIELO_Y_ESPACIO_R03_FULL_PRODUCT_BUILD`.
No es main y no se despliega públicamente.

## Estado del cielo

- 88/88 constelaciones en una sola esfera continua.
- 3.248 estrellas con magnitud <= 5,6.
- 767 vértices de figura, 743 aristas.
- 2 vértices no observables declarados: Cetus y Perseus.
- 88/88 conservan ficha ES/EN y SVG aprobado.
- 88/88 SVG son byte a byte iguales al pipeline R03 canónico SHA `6606430f...`.
- 22 rutas: libre, 12 regiones, 4 temporadas y 5 rutas de ancla.
- “Seguir desde aquí” usa vecinos calculados por anclas.
- Encontrar fuera de ruta siempre cuenta.

## Escala

`SKY-SCALE-01`:
Hidra, Erídano, Serpiente, Virgo y Osa Mayor tienen zonas locales identificables sin rebajar el mínimo semántico.

`SKY-SCALE-02`:
`evidence/AMBIGUITY_88_REPORT.json`
- 1.584 muestras de rejilla;
- 4 ambiguas;
- tasa 0,2525 %;
- 88/88 tienen al menos una muestra de identificación única.

`SKY-SCALE-03`:
las rutas están en datos, no en el runtime. No existe una cadena lineal de 88.

## Regla de volumen para siguientes bloques

A partir de Sistema Solar, Axioma crea los objetos volumétricos necesarios dentro del runtime:
`TRUE_3D_WHERE_OBJECT_HAS_REAL_VOLUME`.

No se usarán billboards finales para Sol, planetas, lunas o planetas enanos.
Las superficies sólo se aplican cuando están respaldadas; para exoplanetas desconocidos:
`UNKNOWN_APPEARANCE_REPRESENTATION`.

## Fuentes

Ver `documentacion/PROCEDENCIA_R03.md`.

## Evidencia

- `evidence/DATA_88_BUILD.json`
- `evidence/AMBIGUITY_88_REPORT.json`
- `../evidence/ASSET_88_HASH_MATCH.json`

## Límites abiertos

- Cha / Vol conservan la pista perceptual legacy marcada para revisión; dentro de rutas de región se desambiguan con ancla + separación angular.
- teléfono físico y AT real siguen pendientes.
- el benchmark completo se repetirá al integrar todos los bloques de Cielo y Espacio.

NO MAIN · NO PUBLIC DEPLOY.
