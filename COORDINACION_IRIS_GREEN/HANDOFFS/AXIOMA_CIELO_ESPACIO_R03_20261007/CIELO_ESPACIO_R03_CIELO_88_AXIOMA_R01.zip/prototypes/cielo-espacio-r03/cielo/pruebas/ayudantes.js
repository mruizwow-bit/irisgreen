/* Cielo 3D · R02 · AYUDANTES DE PRUEBA compartidos.

   Los usan pruebas/navegador.js y pruebas/recorrido-video.js. Dos reglas:
   LEER la pantalla no es inyectar nada, y para llegar a un patrón SE ARRASTRA,
   igual que lo haría una persona. Aquí no se toca la cámara a mano. */
'use strict';

/* Dónde se ve ahora mismo un punto del cielo. LEER no es inyectar: la cámara no
   se toca, se mira la pantalla igual que haría una persona. */
async function enPantalla(page, abbr, i) {
  return await page.evaluate(([a, j]) => {
    const s = IG_DEBUG.pantallaDe(a, j);
    const r = document.getElementById('lienzo').getBoundingClientRect();
    const m = IG_DEBUG.medir();
    return { x: r.left + s.x, y: r.top + s.y, px: s.x, py: s.y, delante: s.delante,
             dentro: s.delante && s.x > 20 && s.x < m.W - 20 && s.y > 20 && s.y < m.H - 20,
             W: m.W, H: m.H, left: r.left, top: r.top };
  }, [abbr, i]);
}
/* Arrastra de verdad hasta traer un punto del cielo A LA VISTA, no al centro:
   aquí nadie tiene que llevar nada a una retícula. El destino es un punto
   claramente descentrado de la pantalla. */
const DESTINO = { fx: 0.68, fy: 0.40 };
/* Qué se está pidiendo buscar ahora mismo, leído de la pantalla. */
async function pistaActual(page) {
  return await page.evaluate(() => ({
    abbr: IG_DEBUG.estado.objetivo,
    texto: document.getElementById('objetivo').textContent
  }));
}
/* Busca en la PANTALLA un sitio donde una persona acertaría: se prueban puntos
   como quien mira, no se inyecta nada. Devuelve null si no hay ninguno a la
   vista, que es información tan válida como encontrarlo. */
async function puntoQueIdentifica(page, abbr) {
  const r = await page.evaluate((a) => {
    const m = IG_DEBUG.medir(), caja = document.getElementById('lienzo').getBoundingClientRect();
    const hechas = {};
    Object.keys(IG_DEBUG.estado.descubiertas).forEach(k => { hechas[k] = true; });
    for (let y = 30; y < m.H - 30; y += 16) {
      for (let x = 30; x < m.W - 30; x += 16) {
        const q = IG_DEBUG.examinarEn({ x, y }, hechas);
        if (q.resultado === 'unico' && q.mejor.abbr === a) {
          return { x: caja.left + x, y: caja.top + y, px: x, py: y, W: m.W, H: m.H };
        }
      }
    }
    return null;
  }, abbr);
  return r;
}
/* Un salto completo como lo haría una persona: leer la pista, arrastrar hasta
   ver la zona, pulsar donde se reconoce el patrón y confirmar. */
async function seguirPista(page, cj) {
  const pista = await pistaActual(page);
  if (!pista.abbr) return { ...pista, encontrada: null, arrastres: 0 };
  const idx = await page.evaluate(a => IG_DEBUG.cielo().porAbbr[a].ancla.punto_indice, pista.abbr);
  let arrastres = await orientarHastaVer(page, pista.abbr, idx, 16);
  let p = await puntoQueIdentifica(page, pista.abbr);
  for (let intento = 0; !p && intento < 3; intento++) {
    /* No se ve del todo: se ajusta el encuadre arrastrando y se vuelve a mirar. */
    await page.mouse.move(cj.x, cj.y); await page.mouse.down();
    for (let q = 1; q <= 6; q++) { await page.mouse.move(cj.x - q * 6, cj.y - q * 4); await page.waitForTimeout(12); }
    await page.mouse.up(); await page.waitForTimeout(250);
    arrastres++;
    p = await puntoQueIdentifica(page, pista.abbr);
  }
  if (!p) return { ...pista, encontrada: null, arrastres };
  await page.mouse.click(p.x, p.y);
  await page.waitForTimeout(600);
  const loc = await page.evaluate(() => (IG_DEBUG.estado.localizada || {}).abbr || null);
  if (loc === pista.abbr) { await page.click('#btn-revelar'); await page.waitForTimeout(600); }
  const fuera = Math.hypot(p.px - p.W / 2, p.py - p.H / 2);
  return { ...pista, encontrada: loc, arrastres, fueraDelCentro: Math.round(fuera) };
}
async function orientarHastaVer(page, abbr, i, maxPasos = 10) {
  for (let n = 0; n < maxPasos; n++) {
    const s = await enPantalla(page, abbr, i);
    if (s.dentro) return n;
    const cx = s.left + s.W * DESTINO.fx, cy = s.top + s.H * DESTINO.fy;
    let dx, dy;
    if (s.delante) { dx = cx - s.x; dy = cy - s.y; }
    else { dx = s.W * 0.4; dy = 0; }                 /* está detrás: gira */
    const k = Math.min(1, (Math.min(s.W, s.H) * 0.35) / (Math.hypot(dx, dy) || 1));
    await page.mouse.move(s.left + s.W / 2, s.top + s.H / 2);
    await page.mouse.down();
    const pasos = 12;
    const ox = s.left + s.W / 2, oy = s.top + s.H / 2;
    for (let q = 1; q <= pasos; q++) {
      await page.mouse.move(ox + dx * k * q / pasos, oy + dy * k * q / pasos);
      await page.waitForTimeout(12);
    }
    await page.mouse.up();
    await page.waitForTimeout(160);
  }
  return -1;
}

module.exports = { DESTINO, enPantalla, pistaActual, puntoQueIdentifica, seguirPista, orientarHastaVer };
