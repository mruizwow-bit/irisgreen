# Pruebas · Cielo 3D R02.1

Dos bancos, separados por tipo, cada uno con su alcance escrito en su cabecera, y
un grabador de vídeo que usa los mismos ayudantes que el banco de navegador.

| Banco | Comprobaciones | Qué mide | Cómo |
|---|---|---|---|
| `unitarias.js` | 18 | geometría de la esfera, regla de evidencia, observabilidad, grafo de saltos y pistas | funciones puras en Node, con fixtures. Sin navegador |
| `navegador.js` | 37 | la experiencia completa | Chromium automatizado sobre el paquete entregado, con `file://` |
| `recorrido-video.js` | — | graba el recorrido real en `video/` | el mismo recorrido del banco, sin montaje y sin acelerar |

    node pruebas/unitarias.js
    npm install playwright && npx playwright install chromium
    PW_CHROMIUM=/ruta/al/chromium node pruebas/navegador.js
    PW_CHROMIUM=/ruta/al/chromium node pruebas/recorrido-video.js

Los bancos escriben su `resultados-*.json` y salen con código distinto de cero si
algo falla. `navegador.js` escribe además
`documentacion/MEDIDAS_R02.json`. No fijan rutas de máquina: la raíz sale de
`__dirname`.

## Los dos oráculos de R02.1

- **`VISIBLE_RENDERED_POINTS_ONLY_ORACLE` → `U16`.** Falla si un punto de figura
  con `estrella=null` cuenta como evidencia, si contribuye al mínimo, si la
  adyacencia de evidencia lo puentea, si lo declarado en los datos no coincide
  con lo que hace el motor, o si aparece como marca en pantalla. `U17` reproduce
  el caso exacto de Perseo y `N23` lo comprueba en la interfaz real.
- **`FUTURE_STORAGE_PRESERVED_BYTES_ORACLE` → `N22`.** Compara los bytes del
  guardado en ocho momentos —cargar, entrar, mover la cámara, descubrir, abrir y
  cerrar la ficha, cambiar de idioma, volver a la portada y borrar los hallazgos
  de la sesión— y falla si cambian o si se promete un guardado que no ocurre.

## Lo que estos bancos NO son

- **No son HUMAN QA ni la revisión independiente de Axioma.**
- **No son prueba táctil real**: los gestos van por eventos del navegador (CDP
  `Input.dispatchTouchEvent`). Reproducen la lógica del gesto, no un teléfono.
- **No son prueba con lector de pantalla.**
- En el recorrido **no se inyecta la cámara**: para llegar a un patrón se
  arrastra, como haría una persona, y el punto donde se pulsa se busca mirando la
  pantalla. Leer dónde se ve algo no es moverlo.
- **La ambigüedad no se prueba con constelaciones reales**, porque con estas 12 y
  una apertura de 6° de radio no existe el caso: `U14` la prueba con un cielo de
  prueba y `N15` interceptando la respuesta del motor en la página.
- Ningún resultado ajeno se presenta como propio.

Lo que queda sin probar está en `../documentacion/NOTAS_DE_PRUEBAS.md`, 3.
