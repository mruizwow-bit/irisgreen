/* Cielo 3D · piloto R01 · PRUEBAS DE NAVEGADOR.

   ALCANCE DECLARADO: Chromium automatizado sobre el paquete tal como se
   entrega, abierto con file://. El recorrido se hace con ratón, teclado y dedo
   REALES y SIN inyectar cámara: para llegar a un patrón se arrastra, igual que
   una persona. Los eventos táctiles son los del emulador (CDP
   Input.dispatchTouchEvent): reproducen la lógica del gesto, NO son un teléfono
   físico, y aquí no se declara prueba táctil real ni con lector de pantalla.

   Las funciones puras están en pruebas/unitarias.js. El juicio humano no lo
   sustituye ninguna de las dos.

   PW_CHROMIUM=/ruta/al/chromium node pruebas/navegador.js                     */
const { chromium } = require('playwright');
const path = require('path');
const fs = require('fs');

const RAIZ = path.resolve(__dirname, '..');
const URL = 'file://' + path.join(RAIZ, 'index.html');
const CAP = path.join(RAIZ, 'capturas');
const EXE = process.env.PW_CHROMIUM;
const res = [];
function reg(id, ok, nota) {
  res.push({ id, estado: ok ? 'OK' : 'FALLO', nota });
  console.log((ok ? '✔' : '✘') + ' ' + id + ': ' + nota);
}
async function abrir(browser, w = 1440, h = 900, extra = {}) {
  const ctx = await browser.newContext({ viewport: { width: w, height: h }, deviceScaleFactor: 1, ...extra });
  const page = await ctx.newPage();
  const errores = [], externas = [];
  page.on('pageerror', e => errores.push(e.message));
  page.on('console', m => { if (m.type() === 'error') errores.push(m.text()); });
  page.on('request', r => { const u = r.url(); if (!/^(file|data|blob):/.test(u)) externas.push(u); });
  await page.goto(URL);
  await page.waitForTimeout(400);
  return { ctx, page, errores, externas };
}
/* Ayudantes compartidos con pruebas/recorrido-video.js: el mismo recorrido que
   graba el vídeo es el que comprueba este banco. */
const { DESTINO, enPantalla, pistaActual, puntoQueIdentifica, seguirPista,
        orientarHastaVer } = require('./ayudantes.js');

(async () => {
  const browser = await chromium.launch(EXE ? { executablePath: EXE } : {});

  /* ===== N01 · recorrido real, sin inyectar cámara ======================== */
  {
    const { ctx, page, errores, externas } = await abrir(browser, 1440, 900);
    const portada = await page.evaluate(() => ({
      accion: document.getElementById('btn-empezar').textContent,
      nombra: /Ori[oó]n|Tauro|Taurus|Aldebar|cintur/i.test(document.body.innerText),
      figuras: document.querySelectorAll('canvas').length
    }));
    reg('N01a', /explorar|exploring/i.test(portada.accion) && !portada.nombra,
      `la portada ofrece «${portada.accion}» y no nombra Orión, Tauro, Aldebarán ni el cinturón`);
    await page.screenshot({ path: path.join(CAP, '1440-01-portada.png') });

    await page.click('#btn-empezar');
    await page.waitForTimeout(900);
    const entrada = await page.evaluate(() => ({
      objetivo: document.getElementById('objetivo').textContent,
      figuras: Object.keys(IG_DEBUG.estado.estados).length,
      foco: document.activeElement.id,
      cam: { ...IG_DEBUG.estado.camara }
    }));
    await page.screenshot({ path: path.join(CAP, '1440-02-entrada.png') });
    reg('N01b', /casi en línea|almost in a line/i.test(entrada.objetivo) && entrada.figuras === 0,
      `se entra al cielo con la pista «${entrada.objetivo.slice(0, 46)}…», sin figuras dibujadas y con el ` +
      `foco en ${entrada.foco}`);

    /* Orientar DE VERDAD antes de nada: un arrastre deliberado, que además tiene
       que mover el cielo sin seleccionar nada. Después se pulsa donde SE VE el
       cinturón, lejos del centro: aquí no hay retícula que perseguir. */
    const camEntrada = await page.evaluate(() => ({ ...IG_DEBUG.estado.camara }));
    const cj = await page.evaluate(() => {
      const r = document.getElementById('lienzo').getBoundingClientRect(), m = IG_DEBUG.medir();
      return { x: r.left + m.W / 2, y: r.top + m.H / 2 };
    });
    await page.mouse.move(cj.x, cj.y);
    await page.mouse.down();
    for (let q = 1; q <= 14; q++) { await page.mouse.move(cj.x - q * 9, cj.y + q * 5); await page.waitForTimeout(14); }
    await page.mouse.up();
    await page.waitForTimeout(350);
    const trasOrientar = await page.evaluate(() => ({
      cam: { ...IG_DEBUG.estado.camara }, localizada: (IG_DEBUG.estado.localizada || {}).abbr || null,
      mensaje: document.getElementById('mensaje').textContent }));
    const orientoSinSeleccionar = (Math.abs(trasOrientar.cam.ra - camEntrada.ra) > 1e-6 ||
      Math.abs(trasOrientar.cam.dec - camEntrada.dec) > 1e-6) && !trasOrientar.localizada;
    const pasos = await orientarHastaVer(page, 'Ori', 22);
    const antes = await page.evaluate(() => ({ ...IG_DEBUG.estado.camara }));
    const s = await enPantalla(page, 'Ori', 22);
    const fueraDelCentro = Math.hypot(s.px - s.W / 2, s.py - s.H / 2);
    await page.mouse.click(s.x, s.y);
    await page.waitForTimeout(700);
    const loc = await page.evaluate(() => ({
      localizada: (IG_DEBUG.estado.localizada || {}).abbr,
      mensaje: document.getElementById('mensaje').innerText,
      avance: document.getElementById('btn-revelar').hidden ? null : document.getElementById('btn-revelar').textContent,
      cam: { ...IG_DEBUG.estado.camara }
    }));
    const quieta = ['ra', 'dec', 'fov'].every(k => Math.abs(antes[k] - loc.cam[k]) < 1e-9);
    await page.screenshot({ path: path.join(CAP, '1440-03-cinturon.png') });
    reg('N01c', orientoSinSeleccionar && loc.localizada === 'Ori' && quieta && fueraDelCentro > 100,
      `un arrastre deliberado orienta el cielo sin seleccionar nada (${orientoSinSeleccionar}); después, ` +
      `${pasos} arrastres más de ajuste y un clic a ${Math.round(fueraDelCentro)} px del centro localizan el ` +
      `cinturón: «${loc.mensaje.replace(/\n/g, ' ')}», y la cámara no se mueve al identificar (${quieta})`);

    await page.click('#btn-revelar');
    await page.waitForTimeout(700);
    const rev = await page.evaluate(() => ({
      revelada: IG_DEBUG.estado.estados['Ori'], activa: IG_DEBUG.estado.activa,
      cam: { ...IG_DEBUG.estado.camara }, objetivo: document.getElementById('objetivo').textContent,
      saber: !document.getElementById('btn-saber-mas').hidden
    }));
    const sinSalto = ['ra', 'dec', 'fov'].every(k => Math.abs(loc.cam[k] - rev.cam[k]) < 1e-9);
    await page.screenshot({ path: path.join(CAP, '1440-04-orion.png') });
    reg('N01d', rev.revelada === 'revelada' && sinSalto && rev.saber && /Ori[oó]n/.test(rev.objetivo),
      `«Ver la constelación» dibuja la figura sobre las mismas estrellas sin mover la cámara (${sinSalto}); ` +
      `arriba queda el contexto del hallazgo («${rev.objetivo.slice(0, 40)}…»)`);

    await page.click('#btn-saber-mas');
    await page.waitForTimeout(1000);
    const ficha = await page.evaluate(() => ({
      titulo: document.getElementById('panel-titulo').textContent,
      vacio: document.getElementById('panel-cuerpo').innerText.trim().length < 40,
      apartados: [...document.querySelectorAll('#panel-cuerpo .ig-acciones button')].map(b => b.textContent),
      cam: { ...IG_DEBUG.estado.camara }
    }));
    await page.screenshot({ path: path.join(CAP, '1440-05-ficha.png') });
    await page.click('#btn-cerrar-panel');
    await page.waitForTimeout(600);
    const cerrada = await page.evaluate(() => ({
      cam: { ...IG_DEBUG.estado.camara }, foco: document.activeElement.id,
      panel: document.getElementById('panel').hidden
    }));
    const mismoSitio = ['ra', 'dec'].every(k => Math.abs(ficha.cam[k] - cerrada.cam[k]) < 1e-9);
    reg('N01e', !ficha.vacio && ficha.apartados.length >= 6 && mismoSitio && cerrada.panel,
      `la ficha de «${ficha.titulo}» llega con contenido y ${ficha.apartados.length} apartados; cerrarla ` +
      `devuelve el mismo encuadre (${mismoSitio}) y el foco a ${cerrada.foco}`);

    /* la siguiente: sin cambiar de campo, sólo orientando y siguiendo la pista
       que dan los datos —no una pareja escrita a mano en el programa. */
    await page.click('#btn-continuar-pista');
    await page.waitForTimeout(500);
    const camAntesVecina = await page.evaluate(() => ({ ...IG_DEBUG.estado.camara }));
    const salto1 = await seguirPista(page, cj);
    const camTrasVecina = await page.evaluate(() => ({ ...IG_DEBUG.estado.camara }));
    const giroContinuo = Math.hypot((camTrasVecina.ra - camAntesVecina.ra) * 15,
                                    camTrasVecina.dec - camAntesVecina.dec);
    await page.screenshot({ path: path.join(CAP, '1440-06-salto-1.png') });
    const nombraObjetivo1 = /Can Mayor|Canis|Sirius/i.test(salto1.texto);
    reg('N01f', salto1.encontrada === salto1.abbr && salto1.abbr === 'CMa' &&
      giroContinuo > 10 && !nombraObjetivo1,
      `la pista que dan los datos («${salto1.texto.slice(0, 64)}…») no nombra lo que hay que encontrar y se sigue ` +
      `arrastrando: ${Math.round(giroContinuo)}° de giro continuo y ${salto1.arrastres} arrastres llevan de Orión a ` +
      `${salto1.abbr}, que se identifica pulsando a ${salto1.fueraDelCentro} px del centro. Sin selector de campo, ` +
      'sin carga intermedia y sin ningún salto de orientación');

    /* dos saltos más de la cadena, siempre arrastrando */
    await page.click('#btn-continuar-pista'); await page.waitForTimeout(400);
    const salto2 = await seguirPista(page, cj);
    await page.click('#btn-continuar-pista'); await page.waitForTimeout(400);
    const salto3 = await seguirPista(page, cj);
    const cadena = await page.evaluate(() => ({
      descubiertas: Object.keys(IG_DEBUG.estado.descubiertas),
      zonas: [...new Set(Object.keys(IG_DEBUG.estado.descubiertas)
        .map(a => IG_DEBUG.cielo().porAbbr[a].zona))].sort(),
      objetivo: IG_DEBUG.estado.objetivo
    }));
    await page.screenshot({ path: path.join(CAP, '1440-07-cadena.png') });
    reg('N01f2', salto2.encontrada === salto2.abbr && salto3.encontrada === salto3.abbr &&
      cadena.descubiertas.length === 4,
      `la cadena sigue: ${cadena.descubiertas.join(' → ')} encontradas una desde otra, cada una desde la anterior ` +
      `y sin que aparezca ningún selector de campo ni ninguna carga; lo siguiente que se pide buscar es ` +
      `${cadena.objetivo}`);

    /* fuera de orden: Tauro no es lo que se pide, y vale igual */
    await page.click('#btn-continuar-pista'); await page.waitForTimeout(400);
    const pedido = await pistaActual(page);
    await orientarHastaVer(page, 'Tau', 7, 16);
    let pTau = await puntoQueIdentifica(page, 'Tau');
    if (!pTau) {
      await orientarHastaVer(page, 'Tau', 1, 8);
      pTau = await puntoQueIdentifica(page, 'Tau');
    }
    let fueraDeOrden = null, objetivoTras = null;
    if (pTau) {
      await page.mouse.click(pTau.x, pTau.y);
      await page.waitForTimeout(600);
      fueraDeOrden = await page.evaluate(() => (IG_DEBUG.estado.localizada || {}).abbr || null);
      if (fueraDeOrden === 'Tau') { await page.click('#btn-revelar'); await page.waitForTimeout(600); }
      objetivoTras = await page.evaluate(() => IG_DEBUG.estado.objetivo);
    }
    const zonasFin = await page.evaluate(() => [...new Set(Object.keys(IG_DEBUG.estado.descubiertas)
      .map(a => IG_DEBUG.cielo().porAbbr[a].zona))].sort());
    await page.screenshot({ path: path.join(CAP, '1440-08-fuera-de-orden.png') });
    reg('N01h', pedido.abbr !== 'Tau' && fueraDeOrden === 'Tau' && objetivoTras === pedido.abbr &&
      zonasFin.length === 2,
      `se pedía buscar ${pedido.abbr} y se encuentra Tauro, que no tocaba: se acepta igual, con su ficha y su ` +
      `sitio, y lo que se sigue sugiriendo es ${objetivoTras}. El orden es una sugerencia, no una puerta. Las cinco ` +
      `encontradas salen de ${zonasFin.length} zonas del catálogo (${zonasFin.join(' y ')}) y se han recorrido ` +
      'arrastrando, sin selector de campo y sin ninguna carga intermedia');

    /* el cuaderno: lo encontrado y DÓNDE se encontró */
    await page.click('#btn-cuaderno');
    await page.waitForTimeout(500);
    const cuad = await page.evaluate(() => ({
      titulo: document.getElementById('panel-titulo').textContent,
      filas: [...document.querySelectorAll('#panel-cuerpo .ig-cuaderno-fila')].map(f => ({
        nombre: f.querySelector('.ig-cuaderno-nombre').textContent,
        sitio: f.querySelector('p').textContent,
        vuelve: !![...f.querySelectorAll('button')].find(b => /Volver a donde/.test(b.textContent))
      }))
    }));
    await page.screenshot({ path: path.join(CAP, '1440-09-cuaderno.png') });
    const lugares = await page.evaluate(() => JSON.parse(JSON.stringify(IG_DEBUG.estado.lugares)));
    /* volver a un hallazgo devuelve EXACTAMENTE la vista desde la que se vio */
    const primera = Object.keys(lugares)[0];
    await page.evaluate(() => {
      const f = [...document.querySelectorAll('#panel-cuerpo .ig-cuaderno-fila')][0];
      [...f.querySelectorAll('button')].find(b => /Volver a donde/.test(b.textContent)).click();
    });
    await page.waitForTimeout(1200);
    const vuelta = await page.evaluate(() => ({ ...IG_DEBUG.estado.camara }));
    const mismaVista = ['ra', 'dec', 'fov'].every(k => Math.abs(vuelta[k] - lugares[primera][k]) < 1e-6);
    const arribaTrasVolver = await page.evaluate(() => document.getElementById('objetivo').textContent);
    await page.screenshot({ path: path.join(CAP, '1440-09b-vuelta-al-lugar.png') });
    reg('N14', cuad.filas.length === 5 && cuad.filas.every(f => f.vuelve && /ascensión recta/.test(f.sitio)) &&
      mismaVista && !/Acabas de encontrar/.test(arribaTrasVolver),
      `el cuaderno lista las ${cuad.filas.length} encontradas con el sitio desde el que se vio cada una ` +
      `(«${cuad.filas[0].sitio.slice(0, 58)}…»); volver a ${cuad.filas[0].nombre} devuelve exactamente esa ` +
      `orientación y ese campo (${mismaVista}), no un encuadre recalculado. Volver a mirar algo no se cuenta como ` +
      `acabar de encontrarlo: arriba vuelve lo que falta por buscar («${arribaTrasVolver.slice(0, 44)}…»)`);

        reg('N01g', errores.length === 0 && externas.length === 0,
      `el recorrido entero no deja errores de consola (${errores.length}) ni pide nada fuera del paquete ` +
      `(${externas.length} peticiones externas)`);
    await ctx.close();
  }

  /* ===== N02 · misma evidencia y misma decisión a 320/390/1440 ============ */
  {
    const lect = [];
    for (const [w, h] of [[320, 568], [390, 844], [1440, 900]]) {
      const { ctx, page } = await abrir(browser, w, h);
      await page.click('#btn-empezar'); await page.waitForTimeout(800);
      lect.push(await page.evaluate(() => {
        /* misma orientación exacta en los tres, y se examina la MISMA dirección */
        const E = IG_ESFERA, D = IG_DEBUG, m = D.medir();
        const k = D.cielo().porAbbr.Ori;
        const dir = k.puntos[k.especial.indices[1]].v;
        const c = E.aCoordenadas(dir);
        D.estado.camara.ra = c.ra + 0.4; D.estado.camara.dec = c.dec + 3; D.estado.camara.fov = 50;
        const s = E.aPantalla(dir, D.estado.camara, m.W, m.H);
        const r = D.examinarEn({ x: s.x, y: s.y });
        return { w: m.W, h: m.H, ap: r.apertura_grados, res: r.resultado,
                 mejor: r.mejor && r.mejor.abbr,
                 ev: r.detalle.filter(d => d.dentro > 0).map(d => d.abbr + ':' + d.dentro).sort().join(','),
                 recorte: r.recorte.length };
      }));
      await ctx.close();
    }
    const unico = new Set(lect.map(l => l.ap + '|' + l.res + '|' + l.mejor + '|' + l.ev)).size === 1;
    reg('N02', unico,
      'la misma dirección del cielo con la misma orientación decide lo mismo en los tres anchos: ' +
      lect.map(l => `${l.w}×${l.h}→${l.res}/${l.mejor} [${l.ev}] apertura ${l.ap}°`).join(' · '));
  }

  /* ===== N03 · negativos del cinturón en la interfaz real ================= */
  {
    const { ctx, page } = await abrir(browser, 1440, 900);
    await page.click('#btn-empezar'); await page.waitForTimeout(800);
    const r = await page.evaluate(() => {
      const E = IG_ESFERA, D = IG_DEBUG, m = D.medir();
      const k = D.cielo().porAbbr.Ori, idx = k.especial.indices;
      const dir = k.puntos[idx[1]].v, c = E.aCoordenadas(dir);
      D.estado.camara.ra = c.ra; D.estado.camara.dec = c.dec; D.estado.camara.fov = 28;
      const centro = { x: m.W / 2, y: m.H / 2 };
      const tapar = n => {
        const zs = [];
        for (let i = 0; i < n; i++) {
          const s = E.aPantalla(k.puntos[idx[i]].v, D.estado.camara, m.W, m.H);
          zs.push({ x: s.x - 10, y: s.y - 10, w: 20, h: 20 });
        }
        const res = IG_ESFERA.examinar(D.cielo(), D.estado.camara, m.W, m.H, zs, centro, {});
        return { res: res.resultado, mejor: res.mejor && res.mejor.abbr };
      };
      return { tres: tapar(0), dos: tapar(1), una: tapar(2) };
    });
    reg('N03', r.tres.mejor === 'Ori' && !r.dos.mejor && !r.una.mejor,
      `con las tres del cinturón observables identifica Orión; con 2/3 da «${r.dos.res}» y con 1/3 ` +
      `«${r.una.res}». No se normaliza la escasez de evidencia`);
    await ctx.close();
  }

  /* ===== N04 · clic lento, cancelación y arrastre sin selección =========== */
  {
    const { ctx, page } = await abrir(browser, 1440, 900);
    await page.click('#btn-empezar'); await page.waitForTimeout(800);
    await orientarHastaVer(page, 'Ori', 22);
    const s = await enPantalla(page, 'Ori', 22);

    /* pulsación QUIETA de más de un segundo: sigue siendo una pulsación */
    await page.mouse.move(s.x, s.y);
    await page.mouse.down();
    await page.waitForTimeout(1200);
    await page.mouse.up();
    await page.waitForTimeout(600);
    const lento = await page.evaluate(() => (IG_DEBUG.estado.localizada || {}).abbr);

    /* arrastre: orienta y NO selecciona */
    await page.evaluate(() => { IG_DEBUG.estado.localizada = null; IG_DEBUG.estado.mensaje = null; });
    const camA = await page.evaluate(() => ({ ...IG_DEBUG.estado.camara }));
    await page.mouse.move(s.x, s.y);
    await page.mouse.down();
    for (let i = 1; i <= 10; i++) { await page.mouse.move(s.x + i * 12, s.y + i * 4); await page.waitForTimeout(14); }
    await page.mouse.up();
    await page.waitForTimeout(400);
    const tras = await page.evaluate(() => ({
      localizada: (IG_DEBUG.estado.localizada || {}).abbr || null,
      cam: { ...IG_DEBUG.estado.camara }
    }));
    const movio = Math.abs(camA.ra - tras.cam.ra) > 1e-6 || Math.abs(camA.dec - tras.cam.dec) > 1e-6;

    /* pointercancel: ni selecciona ni deja el gesto a medias */
    const cdp = await ctx.newCDPSession(page);
    await page.evaluate(() => { IG_DEBUG.estado.mensaje = null; });
    const cancel = await page.evaluate(([x, y]) => {
      const c = document.getElementById('lienzo');
      const r = c.getBoundingClientRect();
      const op = { pointerId: 7, bubbles: true, clientX: x, clientY: y, isPrimary: true };
      const antes = document.getElementById('mensaje').textContent;
      c.dispatchEvent(new PointerEvent('pointerdown', op));
      c.dispatchEvent(new PointerEvent('pointercancel', op));
      return { antes: antes, mensaje: document.getElementById('mensaje').textContent,
               colgados: IG_DEBUG.punterosActivos() };
    }, [s.x, s.y]);
    reg('N04', lento === 'Ori' && !tras.localizada && movio &&
      cancel.mensaje === cancel.antes && cancel.colgados === 0,
      `una pulsación quieta de 1,2 s sigue siendo una pulsación y localiza (${lento}); arrastrar orienta ` +
      `(${movio}) y no selecciona nada; pointercancel cancela sin seleccionar y sin dejar punteros colgados`);
    await ctx.close();
  }

  /* ===== N05 · pinza, pinza→un dedo y rueda anclada ======================= */
  {
    const { ctx, page } = await abrir(browser, 390, 844, { hasTouch: true, isMobile: true });
    const cdp = await ctx.newCDPSession(page);
    await page.click('#btn-empezar'); await page.waitForTimeout(900);
    const caja = await page.evaluate(() => {
      const r = document.getElementById('lienzo').getBoundingClientRect(), m = IG_DEBUG.medir();
      return { cx: r.left + m.W / 2, cy: r.top + m.H / 2, left: r.left, top: r.top, W: m.W, H: m.H };
    });
    const dos = (a, b) => [{ x: a.x, y: a.y, id: 1 }, { x: b.x, y: b.y, id: 2 }];
    const centro = { x: caja.cx - 50, y: caja.cy - 30 };
    const refAntes = await page.evaluate(([x, y]) => {
      const D = IG_DEBUG, m = D.medir();
      const r = document.getElementById('lienzo').getBoundingClientRect();
      const dir = IG_ESFERA.dePantalla({ x: x - r.left, y: y - r.top }, D.estado.camara, m.W, m.H);
      return { dir, fov: D.estado.camara.fov };
    }, [centro.x, centro.y]);
    await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart',
      touchPoints: dos({ x: centro.x - 35, y: centro.y }, { x: centro.x + 35, y: centro.y }) });
    for (const d of [50, 70, 90, 110]) {
      await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove',
        touchPoints: dos({ x: centro.x - d, y: centro.y }, { x: centro.x + d, y: centro.y }) });
      await page.waitForTimeout(50);
    }
    const trasPinza = await page.evaluate(d => {
      const D = IG_DEBUG, m = D.medir();
      const s = IG_ESFERA.aPantalla(d, D.estado.camara, m.W, m.H);
      const r = document.getElementById('lienzo').getBoundingClientRect();
      return { fov: D.estado.camara.fov, x: s.x + r.left, y: s.y + r.top };
    }, refAntes.dir);
    const deriva = Math.hypot(trasPinza.x - centro.x, trasPinza.y - centro.y);

    /* se levanta un dedo y el otro sigue: no puede saltar */
    const idsDosDedos = await page.evaluate(() => IG_DEBUG.punterosIds());
    await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd',
      touchPoints: [{ x: centro.x + 110, y: centro.y, id: 2 }] });
    await page.waitForTimeout(120);
    const camAntes = await page.evaluate(() => ({ ...IG_DEBUG.estado.camara }));
    /* C3D-04: el dedo que queda es el MISMO que ya estaba (id 1), no se cambia
       de dedo para que las cuentas salgan, y se mueve 1 px: pequeño y no nulo. */
    const idsVivos = await page.evaluate(() => IG_DEBUG.punterosIds());
    const desplazamiento = 1;
    await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove',
      touchPoints: [{ x: centro.x - 110 + desplazamiento, y: centro.y, id: 1 }] });
    await page.waitForTimeout(150);
    const camDespues = await page.evaluate(() => ({ ...IG_DEBUG.estado.camara }));
    const saltoGrados = Math.hypot((camDespues.ra - camAntes.ra) * 15 *
      Math.cos(camAntes.dec * Math.PI / 180), camDespues.dec - camAntes.dec);
    await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
    await page.waitForTimeout(300);
    const trasSoltar = await page.evaluate(() => ({
      mensaje: document.getElementById('mensaje').textContent,
      localizada: (IG_DEBUG.estado.localizada || {}).abbr || null,
      colgados: IG_DEBUG.punterosActivos() }));
    const porPixel = await page.evaluate(() => {
      const D = IG_DEBUG, m = D.medir();
      return D.estado.camara.fov / m.H;              /* grados por píxel */
    });
    /* el dedo que sigue es uno de los dos que ya estaban, no uno nuevo */
    const mismoDedo = idsDosDedos.length === 2 && idsVivos.length === 1 &&
      idsDosDedos.indexOf(idsVivos[0]) >= 0;
    reg('N05', mismoDedo && deriva <= 14 && saltoGrados < porPixel * 4 && !trasSoltar.localizada &&
      trasSoltar.colgados === 0,
      `la pinza amplía de ${Math.round(refAntes.fov)}° a ${Math.round(trasPinza.fov)}° de campo manteniendo ` +
      `su centro (deriva ${Math.round(deriva)} px); al soltar un dedo, el que sigue es uno de los que ya estaban ` +
      `(punteros ${idsDosDedos.join(' y ')} → ${idsVivos.join(',')}) y 1 px de movimiento real mueve el cielo ` +
      `${(saltoGrados / porPixel).toFixed(1)} px —sin salto— y el final del gesto no selecciona nada ` +
      `(localizada: ${trasSoltar.localizada}, mensaje: «${trasSoltar.mensaje}»)`);

    /* rueda anclada al punto señalado, con la escena enfocada y tras actuar */
    const { ctx: ctx2, page: p2 } = await abrir(browser, 1440, 900);
    await p2.click('#btn-empezar'); await p2.waitForTimeout(800);
    const fov0 = await p2.evaluate(() => IG_DEBUG.estado.camara.fov);
    await p2.mouse.move(900, 400);
    await p2.mouse.wheel(0, -200);
    await p2.waitForTimeout(400);
    const fovSinActuar = await p2.evaluate(() => IG_DEBUG.estado.camara.fov);
    await p2.keyboard.press('ArrowRight');
    await p2.waitForTimeout(400);
    const ancla = await p2.evaluate(() => {
      const D = IG_DEBUG, m = D.medir();
      const r = document.getElementById('lienzo').getBoundingClientRect();
      return { dir: IG_ESFERA.dePantalla({ x: 900 - r.left, y: 400 - r.top }, D.estado.camara, m.W, m.H),
               left: r.left, top: r.top };
    });
    await p2.mouse.wheel(0, -200);
    await p2.waitForTimeout(500);
    const trasRueda = await p2.evaluate(a => {
      const D = IG_DEBUG, m = D.medir();
      const s = IG_ESFERA.aPantalla(a.dir, D.estado.camara, m.W, m.H);
      return { fov: D.estado.camara.fov, dx: Math.abs(s.x + a.left - 900), dy: Math.abs(s.y + a.top - 400) };
    }, ancla);
    reg('N05b', Math.abs(fovSinActuar - fov0) < 1e-9 && trasRueda.fov < fov0 &&
      trasRueda.dx <= 6 && trasRueda.dy <= 6,
      `la rueda no atrapa el scroll de quien sólo pasa el puntero (campo ${fov0}° → ${fovSinActuar}°); tras ` +
      `actuar en el cielo amplía a ${Math.round(trasRueda.fov)}° dejando quieto el punto señalado ` +
      `(${Math.round(trasRueda.dx)} × ${Math.round(trasRueda.dy)} px)`);
    await ctx2.close();
    await ctx.close();
  }

  /* ===== N06 · sólo con teclado ========================================== */
  {
    const { ctx, page } = await abrir(browser, 1440, 900);
    await page.keyboard.press('Tab');
    const foco1 = await page.evaluate(() => document.activeElement.id);
    await page.keyboard.press('Enter');
    await page.waitForTimeout(900);
    const foco2 = await page.evaluate(() => document.activeElement.id);
    let n = 0, ok = false;
    for (; n < 40 && !ok; n++) {
      const s = await enPantalla(page, 'Ori', 22);
      const m = await page.evaluate(() => IG_DEBUG.medir());
      const dx = s.px - m.W / 2, dy = s.py - m.H / 2;
      if (s.delante && Math.hypot(dx, dy) < 30) { ok = true; break; }
      await page.keyboard.press(Math.abs(dx) > Math.abs(dy)
        ? (dx > 0 ? 'ArrowRight' : 'ArrowLeft') : (dy > 0 ? 'ArrowDown' : 'ArrowUp'));
      await page.waitForTimeout(130);
    }
    await page.keyboard.press('Enter');
    await page.waitForTimeout(700);
    const loc = await page.evaluate(() => ({
      localizada: (IG_DEBUG.estado.localizada || {}).abbr, foco: document.activeElement.id }));
    await page.keyboard.press('Tab');
    const antesEspacio = await page.evaluate(() => document.activeElement.id);
    await page.keyboard.press(' ');
    await page.waitForTimeout(600);
    const rev = await page.evaluate(() => ({
      revelada: IG_DEBUG.estado.estados['Ori'], foco: document.activeElement.id }));
    reg('N06', foco2 === 'escenario' && loc.localizada === 'Ori' && rev.revelada === 'revelada',
      `sólo con teclado: Tab llega a ${foco1}, Intro entra y deja el foco en ${foco2}, ${n} flechas reales ` +
      `orientan hasta el patrón, Intro lo localiza y Espacio sobre «${antesEspacio}» lo revela ` +
      `(foco final: ${rev.foco})`);
    await ctx.close();
  }

  /* ===== N07 · movimiento: NONE y cambio de modo sin salto ================ */
  {
    const ctx1 = await browser.newContext({ viewport: { width: 1200, height: 800 }, reducedMotion: 'reduce' });
    const p1 = await ctx1.newPage();
    await p1.goto(URL); await p1.waitForTimeout(500);
    const sistema = await p1.evaluate(() => ({ modo: IG_DEBUG.estado.movimiento,
      explicito: IG_DEBUG.estado.movimientoExplicito }));
    await p1.click('#btn-empezar'); await p1.waitForTimeout(800);
    await p1.selectOption('#sel-movimiento', 'NONE'); await p1.waitForTimeout(300);
    const camA = await p1.evaluate(() => ({ ...IG_DEBUG.estado.camara }));
    await p1.evaluate(() => document.getElementById('escenario').focus());
    await p1.keyboard.press('ArrowRight');
    await p1.waitForTimeout(80);
    const sinAnim = await p1.evaluate(() => ({ anim: IG_DEBUG.hayAnimacion(), cam: { ...IG_DEBUG.estado.camara } }));
    const movioYa = Math.abs(sinAnim.cam.ra - camA.ra) > 1e-9;
    await p1.selectOption('#sel-movimiento', 'NORMAL'); await p1.waitForTimeout(300);
    const trasModo = await p1.evaluate(() => ({
      cam: { ...IG_DEBUG.estado.camara }, explicito: IG_DEBUG.estado.movimientoExplicito,
      anim: IG_DEBUG.hayAnimacion(), hallazgos: Object.keys(IG_DEBUG.estado.descubiertas).length }));
    const quieta = ['ra', 'dec', 'fov'].every(k => Math.abs(sinAnim.cam[k] - trasModo.cam[k]) < 1e-9);
    reg('N07', sistema.modo === 'REDUCED' && !sistema.explicito && !sinAnim.anim && movioYa &&
      quieta && trasModo.explicito && !trasModo.anim,
      `sin elección propia manda el sistema (${sistema.modo}); con NONE la vista se actualiza de golpe y no ` +
      `queda interpolación (${!sinAnim.anim}); cambiar de modo conserva orientación (${quieta}) y hallazgos`);
    await ctx1.close();
  }

  /* ===== N08 · salir durante animación o carga, sin panel obsoleto ======== */
  {
    const { ctx, page, errores } = await abrir(browser, 1440, 900);
    await page.click('#btn-empezar'); await page.waitForTimeout(800);
    const anim = await page.evaluate(async () => {
      document.querySelector('[data-zoom="acercar"]').click();
      const enVuelo = IG_DEBUG.hayAnimacion();
      document.getElementById('btn-volver-portada').click();
      await new Promise(r => setTimeout(r, 150));
      return { enVuelo, tras: IG_DEBUG.hayAnimacion(), pantalla: IG_DEBUG.estado.pantalla };
    });
    await page.click('#btn-empezar'); await page.waitForTimeout(700);
    /* se pide una ficha, se cierra, y la carga llega tarde */
    const tarde = await page.evaluate(async () => {
      const orig = document.head.appendChild.bind(document.head);
      let pend = null;
      document.head.appendChild = function (n) {
        if (n.tagName === 'SCRIPT' && /datos\/fichas\//.test(n.src || '')) { pend = n; return n; }
        return orig(n);
      };
      IG_DEBUG.abrirFichaDePrueba('Gem');
      await new Promise(r => setTimeout(r, 60));
      document.getElementById('btn-volver-portada').click();
      await new Promise(r => setTimeout(r, 80));
      if (pend) orig(pend);
      await new Promise(r => setTimeout(r, 500));
      document.head.appendChild = orig;
      return { panel: document.getElementById('panel').hidden, pantalla: IG_DEBUG.estado.pantalla };
    });
    reg('N08', anim.enVuelo && !anim.tras && tarde.panel && tarde.pantalla === 'portada' && errores.length === 0,
      `salir a media transición la cancela (${anim.enVuelo} → ${anim.tras}); una ficha pedida y abandonada no ` +
      `abre ningún panel obsoleto cuando su carga llega tarde (panel cerrado: ${tarde.panel})`);
    await ctx.close();
  }

  /* ===== N08b · carga obsoleta sin salir de la zona ======================= */
  {
    const { ctx, page, errores } = await abrir(browser, 1440, 900);
    await page.click('#btn-empezar'); await page.waitForTimeout(800);
    /* C3D-06: se pide una ficha, se pide OTRA sin moverse de sitio, y la
       primera llega tarde. Debe ganar la última pedida, no la que llegue. */
    const r = await page.evaluate(async () => {
      const orig = document.head.appendChild.bind(document.head);
      const cola = [];
      document.head.appendChild = function (n) {
        if (n.tagName === 'SCRIPT' && /datos\/fichas\//.test(n.src || '')) { cola.push(n); return n; }
        return orig(n);
      };
      IG_DEBUG.abrirFichaDePrueba('Gem');          /* primera, lenta */
      await new Promise(s => setTimeout(s, 60));
      IG_DEBUG.abrirFichaDePrueba('Per');          /* segunda, sin cambiar de pantalla */
      await new Promise(s => setTimeout(s, 60));
      const pantalla = IG_DEBUG.estado.pantalla;
      orig(cola[1]);                               /* llega la segunda */
      await new Promise(s => setTimeout(s, 400));
      const trasSegunda = { titulo: document.getElementById('panel-titulo').textContent,
                            abbr: IG_DEBUG.estado.panelAbbr };
      orig(cola[0]);                               /* y AHORA la primera, obsoleta */
      await new Promise(s => setTimeout(s, 400));
      const trasPrimera = { titulo: document.getElementById('panel-titulo').textContent,
                            abbr: IG_DEBUG.estado.panelAbbr };
      document.head.appendChild = orig;
      /* y lo mismo cerrando: se pide una, se cierra, y llega */
      IG_DEBUG.abrirFichaDePrueba('Lep');
      await new Promise(s => setTimeout(s, 500));
      const abierta = !document.getElementById('panel').hidden;
      return { pantalla, trasSegunda, trasPrimera, abierta };
    });
    const noLaPisa = r.trasPrimera.abbr === 'Per' && /Perseo|Perseus/.test(r.trasPrimera.titulo);
    reg('N08b', r.pantalla === 'escena' && r.trasSegunda.abbr === 'Per' && noLaPisa && errores.length === 0,
      `pidiendo dos fichas seguidas sin salir de la zona, manda la última pedida: cuando la carga de la primera ` +
      `llega tarde no sustituye nada (sigue «${r.trasPrimera.titulo}»). Quedarse en el mismo sitio no es excusa ` +
      'para dejar viva una carga que ya no se quiere');
    await ctx.close();
  }

  /* ===== N09 · foco al cambiar de pantalla y al redimensionar ============= */
  {
    const { ctx, page } = await abrir(browser, 1440, 900);
    const pasos = [];
    const foco = () => page.evaluate(() => {
      const a = document.activeElement;
      return { id: a.id || a.tagName, visible: !!(a.offsetWidth || a.offsetHeight || a.getClientRects().length) };
    });
    await page.click('#btn-empezar'); await page.waitForTimeout(800);
    pasos.push({ p: 'Empezar', ...(await foco()) });
    await page.click('#btn-volver-portada'); await page.waitForTimeout(400);
    pasos.push({ p: 'Volver', ...(await foco()) });
    await page.click('#btn-empezar'); await page.waitForTimeout(700);
    await orientarHastaVer(page, 'Ori', 22);
    const s = await enPantalla(page, 'Ori', 22);
    await page.mouse.click(s.x, s.y); await page.waitForTimeout(500);
    await page.click('#btn-revelar'); await page.waitForTimeout(500);
    await page.click('#btn-saber-mas'); await page.waitForTimeout(900);
    await page.evaluate(() => {
      const b = [...document.querySelectorAll('#panel-cuerpo button')].find(x => /^Estrellas$/.test(x.textContent));
      if (b) b.focus();
    });
    const antes = await page.evaluate(() => document.activeElement.textContent.trim());
    await page.setViewportSize({ width: 820, height: 760 });
    await page.waitForTimeout(600);
    const medio = await page.evaluate(() => ({
      texto: document.activeElement.textContent.trim(), panel: !document.getElementById('panel').hidden }));
    await page.setViewportSize({ width: 1440, height: 900 });
    await page.waitForTimeout(600);
    const despues = await page.evaluate(() => document.activeElement.textContent.trim());
    reg('N09', pasos.every(x => x.id && x.id !== 'BODY' && x.visible) &&
      antes === medio.texto && medio.texto === despues && medio.panel,
      `el foco va a un destino visible al cambiar de pantalla (${pasos.map(x => x.p + '→' + x.id).join(', ')}) ` +
      `y sobrevive al cambio de tamaño con la ficha abierta («${antes}» se mantiene)`);
    await ctx.close();
  }

  /* ===== N10 · formato: cielo, acción alcanzable y texto al 200 % ========= */
  {
    for (const [w, h, nombre] of [[320, 568, '320'], [390, 844, '390'], [1440, 900, '1440']]) {
      const { ctx, page } = await abrir(browser, w, h);
      await page.click('#btn-empezar'); await page.waitForTimeout(800);
      const geo = await page.evaluate(() => {
        const vis = n => !!(n.offsetWidth || n.offsetHeight || n.getClientRects().length);
        const r = document.getElementById('escenario').getBoundingClientRect();
        const visible = Math.max(0, Math.min(r.bottom, innerHeight) - Math.max(r.top, 0));
        const bot = [...document.querySelectorAll('button, select')].filter(vis).map(b => {
          const q = b.getBoundingClientRect();
          return { id: b.id || b.textContent.trim().slice(0, 10), w: Math.round(q.width), h: Math.round(q.height) };
        });
        return { alto: Math.round(r.height), visible: Math.round(visible), vp: innerHeight,
                 docW: document.documentElement.scrollWidth, vpW: innerWidth,
                 pequenos: bot.filter(b => b.w < 44 || b.h < 44) };
      });
      await page.screenshot({ path: path.join(CAP, `${nombre}-entrada.png`) });
      /* tras pulsar, el mensaje y el avance tienen que verse */
      await orientarHastaVer(page, 'Ori', 22);
      const s = await enPantalla(page, 'Ori', 22);
      await page.mouse.click(s.x, s.y);
      await page.waitForTimeout(700);
      const alcance = await page.evaluate(() => {
        const v = sel => {
          const n = document.querySelector(sel);
          if (!n || n.hidden) return 0;
          const r = n.getBoundingClientRect();
          const d = Math.max(0, Math.min(r.bottom, innerHeight) - Math.max(r.top, 0));
          return r.height ? Math.round(d / r.height * 100) : 0;
        };
        return { mensaje: v('#mensaje'), revelar: v('#btn-revelar') };
      });
      await page.screenshot({ path: path.join(CAP, `${nombre}-localizado.png`) });
      reg('N10-' + nombre, geo.docW <= geo.vpW + 1 && geo.pequenos.length === 0 &&
        alcance.mensaje === 100 && alcance.revelar === 100,
        `sin scroll horizontal, ningún control visible por debajo de 44 px · cielo ${geo.alto} px de alto de ` +
        `componente, de los que se ven ${geo.visible} px de entrada (${Math.round(geo.visible / geo.vp * 1000) / 10} % ` +
        `del viewport, intersección real) · tras pulsar, el mensaje y «Ver la constelación» se ven enteros`);
      await ctx.close();
    }
    /* texto al 200 %: reflujo interno, no sólo ausencia de scroll horizontal */
    const { ctx, page } = await abrir(browser, 390, 844);
    await page.click('#btn-empezar'); await page.waitForTimeout(700);
    const antes = await page.evaluate(() => document.getElementById('objetivo').getBoundingClientRect().height);
    await page.addStyleTag({ content: 'html{font-size:32px!important}' });
    await page.waitForTimeout(500);
    const t200 = await page.evaluate(() => {
      const o = document.getElementById('objetivo').getBoundingClientRect();
      const recortados = [...document.querySelectorAll('button, .ig-objetivo, .ig-mensaje')]
        .filter(n => n.offsetParent !== null && (n.scrollWidth > n.clientWidth + 2 || n.scrollHeight > n.clientHeight + 2));
      return { alto: o.height, docW: document.documentElement.scrollWidth, vpW: innerWidth,
               recortados: recortados.map(n => n.id || n.className).slice(0, 5) };
    });
    await page.screenshot({ path: path.join(CAP, '390-texto-200.png') });
    reg('N10-200', t200.docW <= t200.vpW + 1 && t200.alto > antes * 1.4 && t200.recortados.length === 0,
      `al 200 % de texto el objetivo reflúye de ${Math.round(antes)} a ${Math.round(t200.alto)} px de alto ` +
      `(no se queda igual ni se recorta), sin scroll horizontal y sin elementos con contenido cortado`);
    await ctx.close();
  }

  /* ===== N11 · en móvil se puede salir de la escena para bajar la página == */
  {
    const { ctx, page } = await abrir(browser, 390, 844, { hasTouch: true, isMobile: true });
    const cdp = await ctx.newCDPSession(page);
    await page.click('#btn-empezar'); await page.waitForTimeout(800);
    const antes = await page.evaluate(() => scrollY);
    /* arrastrar DENTRO del cielo orienta y no desplaza la página */
    const c = await page.evaluate(() => {
      const r = document.getElementById('lienzo').getBoundingClientRect();
      return { x: r.left + r.width / 2, y: r.top + r.height / 2 };
    });
    await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x: c.x, y: c.y, id: 1 }] });
    for (let i = 1; i <= 8; i++) {
      await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [{ x: c.x, y: c.y - i * 20, id: 1 }] });
      await page.waitForTimeout(25);
    }
    await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
    await page.waitForTimeout(300);
    const trasCielo = await page.evaluate(() => scrollY);
    /* fuera del cielo, la página se desplaza con normalidad */
    const fuera = await page.evaluate(() => {
      const r = document.querySelector('.ig-bandeja').getBoundingClientRect();
      return { x: r.left + r.width / 2, y: r.top + 10 };
    });
    await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x: fuera.x, y: fuera.y, id: 2 }] });
    for (let i = 1; i <= 8; i++) {
      await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [{ x: fuera.x, y: fuera.y - i * 18, id: 2 }] });
      await page.waitForTimeout(25);
    }
    await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
    await page.waitForTimeout(400);
    const trasFuera = await page.evaluate(() => ({ y: scrollY, max: document.documentElement.scrollHeight - innerHeight }));
    reg('N11', trasCielo === antes && (trasFuera.y > antes || trasFuera.max <= 0),
      `arrastrar dentro del cielo orienta sin mover la página (scroll ${antes} → ${trasCielo}); fuera del ` +
      `cielo la página baja con normalidad (scroll ${trasFuera.y} de ${trasFuera.max} posibles): la captura ` +
      'de gestos no cubre toda la navegación');
    await ctx.close();
  }

  /* ===== N12 · rendimiento y reposo ====================================== */
  {
    const { ctx, page } = await abrir(browser, 1440, 900);
    await page.click('#btn-empezar'); await page.waitForTimeout(900);
    await page.evaluate(() => IG_DEBUG.reiniciarMedidas());
    await page.evaluate(() => document.getElementById('escenario').focus());
    for (let i = 0; i < 12; i++) { await page.keyboard.press('ArrowRight'); await page.waitForTimeout(90); }
    await page.waitForTimeout(600);
    const m = await page.evaluate(() => ({
      medidas: IG_DEBUG.medidas(), dpr: devicePixelRatio, vp: [innerWidth, innerHeight],
      estrellas: IG3D.estrellas.length, via: IG3D.via_lactea.reduce((a, t) => a + t.length, 0) }));
    /* reposo: nada se dibuja si nada cambia */
    const reposo = await page.evaluate(() => new Promise(r => {
      IG_DEBUG.reiniciarMedidas();
      let propios = 0;
      const orig = window.requestAnimationFrame;
      window.requestAnimationFrame = function (f) { propios++; return orig(f); };
      setTimeout(() => { window.requestAnimationFrame = orig;
        r({ propios, cuadros: IG_DEBUG.medidas().cuadros }); }, 3000);
    }));
    const oculto = await page.evaluate(async () => {
      Object.defineProperty(document, 'hidden', { value: true, configurable: true });
      document.dispatchEvent(new Event('visibilitychange'));
      await new Promise(r => setTimeout(r, 200));
      return IG_DEBUG.hayAnimacion();
    });
    reg('N12', m.medidas.ms_por_cuadro < 33 && reposo.cuadros === 0 && !oculto,
      `${m.estrellas} estrellas y ${m.via} puntos de Vía Láctea en ${m.vp[0]}×${m.vp[1]} con DPR ${m.dpr}: ` +
      `${m.medidas.ms_por_cuadro} ms por cuadro de media en ${m.medidas.cuadros} cuadros (emulación de ` +
      `escritorio, NO un móvil real) · 3 s en reposo: ${reposo.cuadros} cuadros dibujados, sin bucle · ` +
      'al ocultar la pestaña no queda ninguna animación viva');
    await ctx.close();
  }

  /* ===== N15 · ambigüedad: no se revela y no se nombra =================== */
  {
    /* Con estas 12 constelaciones y una apertura de 6° de radio NO se puede
       provocar una ambigüedad real: se barrió el cielo entero y no hay ni un
       punto con dos patrones sustentados (queda anotado en NOTAS_DE_PRUEBAS).
       La decisión está probada con funciones puras en U14. Aquí se prueba la
       OTRA mitad: que cuando el motor dice «ambiguo», la interfaz no identifica
       nada, no suelta ningún nombre y no mueve la orientación. Para eso se
       envuelve la función del motor en la página —se intercepta su respuesta,
       no se falsean los datos— y después se restaura. */
    const { ctx, page } = await abrir(browser, 1440, 900);
    await page.click('#btn-empezar');
    await page.waitForTimeout(700);
    const camAntes = await page.evaluate(() => ({ ...IG_DEBUG.estado.camara }));
    await page.evaluate(() => {
      const real = IG_ESFERA.examinar;
      window.__restaurar = () => { IG_ESFERA.examinar = real; };
      IG_ESFERA.examinar = function () {
        const r = real.apply(null, arguments);
        /* dos candidatos empatados, como los devolvería el motor */
        r.resultado = 'ambiguo';
        r.coincide = false;
        r.mejor = null;
        r.plausibles = [{ abbr: 'Ori', dentro: 3, octante: 'abajo_izquierda', separacion_grados: 3.4 },
                        { abbr: 'Tau', dentro: 3, octante: 'arriba', separacion_grados: 4.1 }];
        return r;
      };
    });
    const caja = await page.evaluate(() => {
      const r = document.getElementById('lienzo').getBoundingClientRect();
      return { x: r.left + r.width * 0.45, y: r.top + r.height * 0.55 };
    });
    await page.mouse.click(caja.x, caja.y);
    await page.waitForTimeout(500);
    const amb = await page.evaluate(() => ({
      texto: document.getElementById('mensaje').innerText,
      opciones: [...document.querySelectorAll('#mensaje button')].map(b => b.textContent),
      revelar: !document.getElementById('btn-revelar').hidden,
      localizada: (IG_DEBUG.estado.localizada || {}).abbr || null,
      cam: { ...IG_DEBUG.estado.camara }
    }));
    const quieta = ['ra', 'dec', 'fov'].every(k => Math.abs(amb.cam[k] - camAntes[k]) < 1e-9);
    const nombres = /Ori[oó]n|Tauro|Taurus|Aldebar|cintur|belt|Hyades|H[ií]ades/i;
    const sinNombres = !nombres.test(amb.texto) && !amb.opciones.some(o => nombres.test(o));
    const porSitio = amb.opciones.length === 2 &&
      amb.opciones.every(o => /abajo a la izquierda|arriba/.test(o) && /°/.test(o));
    await page.screenshot({ path: path.join(CAP, '1440-10-ambiguo.png') });
    /* se elige una opción: sólo entonces se localiza, y se localiza esa */
    await page.evaluate(() => window.__restaurar());
    await page.evaluate(() => document.querySelectorAll('#mensaje button')[0].click());
    await page.waitForTimeout(500);
    const tras = await page.evaluate(() => ({
      localizada: (IG_DEBUG.estado.localizada || {}).abbr || null,
      cam: { ...IG_DEBUG.estado.camara }
    }));
    const quietaTras = ['ra', 'dec', 'fov'].every(k => Math.abs(tras.cam[k] - camAntes[k]) < 1e-9);
    reg('N15', !amb.localizada && !amb.revelar && sinNombres && porSitio && quieta &&
      tras.localizada === 'Ori' && quietaTras,
      `con dos candidatos empatados no se identifica nada (localizada: ${amb.localizada}, sin botón de revelar) y ` +
      `las dos opciones se describen por su sitio en el cielo —«${amb.opciones.join('» y «')}»—, sin nombrar ` +
      `ninguna constelación ni ninguna de sus estrellas. La orientación no se toca (${quieta}); al elegir una, se ` +
      `localiza esa (${tras.localizada}) y la vista sigue donde estaba (${quietaTras})`);
    await ctx.close();
  }

  /* ===== N16 · la ficha no tapa lo que se acaba de encontrar ============== */
  {
    const { ctx, page } = await abrir(browser, 1440, 900);
    await page.click('#btn-empezar');
    await page.waitForTimeout(700);
    const cj = await page.evaluate(() => {
      const r = document.getElementById('lienzo').getBoundingClientRect(), m = IG_DEBUG.medir();
      return { x: r.left + m.W / 2, y: r.top + m.H / 2 };
    });
    await orientarHastaVer(page, 'Ori', 22);
    /* se lleva el hallazgo a la MITAD DERECHA arrastrando, y se encuentra ahí */
    for (let intento = 0; intento < 6; intento++) {
      const s = await enPantalla(page, 'Ori', 22);
      if (s.dentro && s.px > s.W * 0.62) break;
      const dx = (s.W * 0.72 + s.left - s.x), dy = (s.H * 0.5 + s.top - s.y);
      await page.mouse.move(cj.x, cj.y); await page.mouse.down();
      for (let q = 1; q <= 8; q++) { await page.mouse.move(cj.x + dx * q / 8, cj.y + dy * q / 8); await page.waitForTimeout(12); }
      await page.mouse.up(); await page.waitForTimeout(220);
    }
    const sDer = await enPantalla(page, 'Ori', 22);
    const pDer = await puntoQueIdentifica(page, 'Ori');
    let ladoDerecha = null, camFicha = null, camCerrada = null, tapa = null;
    if (pDer) {
      await page.mouse.click(pDer.x, pDer.y); await page.waitForTimeout(500);
      await page.click('#btn-revelar'); await page.waitForTimeout(500);
      const camPrevia = await page.evaluate(() => ({ ...IG_DEBUG.estado.camara }));
      await page.click('#btn-saber-mas'); await page.waitForTimeout(900);
      const info = await page.evaluate(() => {
        const p = document.getElementById('panel').getBoundingClientRect();
        const s = IG_DEBUG.pantallaDe('Ori', 22);
        const c = document.getElementById('lienzo').getBoundingClientRect();
        return { lado: IG_DEBUG.ladoPanel(), panelX: p.left + p.width / 2, hallazgoX: c.left + s.x,
                 hallazgoY: c.top + s.y, panel: { l: p.left, r: p.right, t: p.top, b: p.bottom },
                 cam: { ...IG_DEBUG.estado.camara } };
      });
      ladoDerecha = info.lado;
      camFicha = info.cam;
      tapa = info.hallazgoX >= info.panel.l && info.hallazgoX <= info.panel.r &&
             info.hallazgoY >= info.panel.t && info.hallazgoY <= info.panel.b;
      await page.screenshot({ path: path.join(CAP, '1440-11-ficha-lado-opuesto.png') });
      await page.click('#btn-cerrar-panel'); await page.waitForTimeout(500);
      camCerrada = await page.evaluate(() => ({ ...IG_DEBUG.estado.camara }));
      var orientacionIntacta = ['ra', 'dec', 'fov'].every(k => Math.abs(camPrevia[k] - camCerrada[k]) < 1e-9);
    }
    reg('N16', !!pDer && sDer.px > sDer.W * 0.55 && ladoDerecha === 'izquierda' && tapa === false &&
      orientacionIntacta === true,
      `con el hallazgo en la mitad derecha de la pantalla (x = ${Math.round(sDer.px)} de ${sDer.W}), la ficha se ` +
      `acopla al lado contrario (${ladoDerecha}) y no cae encima de lo que se acaba de encontrar (${tapa}); abrirla ` +
      `y cerrarla no cambia la orientación ni el campo (${orientacionIntacta})`);
    await ctx.close();
  }

  /* ===== N16b · en estrecho el cielo se queda arriba ====================== */
  {
    const { ctx, page } = await abrir(browser, 390, 844);
    await page.click('#btn-empezar');
    await page.waitForTimeout(700);
    await orientarHastaVer(page, 'Ori', 22);
    const p = await puntoQueIdentifica(page, 'Ori');
    let arriba = null, anchoCielo = null;
    if (p) {
      await page.mouse.click(p.x, p.y); await page.waitForTimeout(500);
      await page.click('#btn-revelar'); await page.waitForTimeout(500);
      await page.click('#btn-saber-mas'); await page.waitForTimeout(900);
      const g = await page.evaluate(() => {
        const e = document.getElementById('escenario').getBoundingClientRect();
        const a = document.getElementById('panel').getBoundingClientRect();
        return { cieloTop: e.top, cieloBottom: e.bottom, panelTop: a.top, ancho: e.width,
                 viewport: window.innerWidth };
      });
      arriba = g.panelTop >= g.cieloBottom - 2;
      anchoCielo = Math.round(g.ancho);
      await page.screenshot({ path: path.join(CAP, '390-07-ficha-debajo.png') });
    }
    reg('N16b', arriba === true && anchoCielo > 300,
      `a 390 px la ficha no se pone al lado: el cielo se queda arriba a ancho completo (${anchoCielo} px) y la ` +
      `ficha va debajo (${arriba}), que es donde no tapa nada`);
    await ctx.close();
  }

  /* ===== N17 · la marca del centro es apoyo del teclado, no la metáfora == */
  {
    const { ctx, page } = await abrir(browser, 1440, 900);
    await page.click('#btn-empezar');
    await page.waitForTimeout(700);
    const trasRaton = await page.evaluate(() => {
      const r = document.getElementById('lienzo').getBoundingClientRect();
      return { entrada: IG_DEBUG.ultimaEntrada(), centro: IG_DEBUG.estado.tecladoActivo, r: r.width };
    });
    const caja = await page.evaluate(() => {
      const r = document.getElementById('lienzo').getBoundingClientRect();
      return { x: r.left + r.width * 0.4, y: r.top + r.height * 0.5 };
    });
    await page.mouse.click(caja.x, caja.y);
    await page.waitForTimeout(400);
    const conRaton = await page.evaluate(() => IG_DEBUG.estado.tecladoActivo);
    /* el programa mueve el foco al botón: eso NO debe encender la marca */
    await page.evaluate(() => document.getElementById('btn-examinar').focus());
    await page.waitForTimeout(300);
    const conFocoProgramatico = await page.evaluate(() => IG_DEBUG.estado.tecladoActivo);
    /* una tecla real sí */
    await page.evaluate(() => document.getElementById('escenario').focus());
    await page.keyboard.press('ArrowLeft');
    await page.waitForTimeout(400);
    const conTeclado = await page.evaluate(() => ({
      centro: IG_DEBUG.estado.tecladoActivo, entrada: IG_DEBUG.ultimaEntrada() }));
    await page.screenshot({ path: path.join(CAP, '1440-12-centro-teclado.png') });
    /* y al volver al ratón se apaga */
    await page.mouse.click(caja.x, caja.y);
    await page.waitForTimeout(400);
    const deVuelta = await page.evaluate(() => IG_DEBUG.estado.tecladoActivo);
    reg('N17', trasRaton.centro === false && conRaton === false && conFocoProgramatico === false &&
      conTeclado.centro === true && deVuelta === false,
      'la marca del centro no aparece al entrar con ratón, ni al pulsar con ratón, ni cuando el programa mueve el ' +
      'foco al botón de examinar; aparece con una flecha real y se apaga en cuanto se vuelve a usar el ratón. ' +
      'Prioridad: pulsar donde se mira; el centro es apoyo del teclado');
    await ctx.close();
  }

  /* ===== N13 · colores forzados y vía descriptiva ======================== */
  {
    const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 }, forcedColors: 'active' });
    const page = await ctx.newPage();
    await page.goto(URL); await page.waitForTimeout(600);
    await page.click('#btn-empezar'); await page.waitForTimeout(800);
    await page.click('#btn-describir'); await page.waitForTimeout(400);
    await page.evaluate(() => document.getElementById('escenario').focus());
    await page.keyboard.press('ArrowRight');
    await page.waitForTimeout(600);
    const fc = await page.evaluate(() => ({
      aviso: document.getElementById('aviso').hidden ? null : document.getElementById('aviso').textContent.slice(0, 40),
      region: document.getElementById('descripcion-region').textContent,
      entorno: document.getElementById('descripcion-entorno').textContent }));
    await page.screenshot({ path: path.join(CAP, '1440-forced-colors.png') });
    reg('N13', !!fc.aviso && fc.region.length > 10 && /grados/.test(fc.entorno),
      `con colores forzados se avisa y la vía descriptiva funciona con teclado: «${fc.region.slice(0, 70)}…» ` +
      `· «${fc.entorno.slice(0, 60)}…»`);
    await ctx.close();
  }

  /* ===== N21 · overlay, hit-test y revelado: una sola observabilidad ====== */
  {
    const { ctx, page } = await abrir(browser, 1440, 900);
    await page.click('#btn-empezar'); await page.waitForTimeout(700);
    await orientarHastaVer(page, 'Ori', 22);
    const p = await puntoQueIdentifica(page, 'Ori');
    await page.mouse.click(p.x, p.y); await page.waitForTimeout(600);
    /* lo que se marca en pantalla es EXACTAMENTE lo que sostuvo la decisión */
    const comp = await page.evaluate(() => {
      const loc = IG_DEBUG.estado.localizada;
      const dibujo = IG_ESCENA.ultimoDibujo();
      const clave = q => Math.round(q.ra * 1e4) / 1e4 + '/' + Math.round(q.dec * 1e4) / 1e4;
      return {
        abbr: loc.abbr,
        marcadas: loc.puntos.map(clave).sort(),
        pintadas: dibujo.marcadas.slice().sort(),
        minimo: IG_ESFERA.minimoSemantico(IG_DEBUG.cielo().porAbbr[loc.abbr]),
        cuantas: loc.puntos.length
      };
    });
    const mismas = comp.marcadas.join(',') === comp.pintadas.join(',');
    const suficientes = comp.cuantas >= comp.minimo;
    /* y al revelar se dibuja la figura de ESA constelación, no otra */
    await page.click('#btn-revelar'); await page.waitForTimeout(600);
    const tras = await page.evaluate(() => {
      const d = IG_ESCENA.ultimoDibujo();
      return { figuras: d.figuras.slice().sort(), activa: IG_DEBUG.estado.activa };
    });
    reg('N21', mismas && suficientes && tras.figuras.join(',') === 'Ori' && tras.activa === 'Ori',
      `las ${comp.cuantas} estrellas que sostienen la decisión (mínimo ${comp.minimo}) son exactamente las que se ` +
      `marcan en el lienzo (${mismas}) y, al revelar, la figura que se dibuja es la de la misma constelación ` +
      `(${tras.figuras.join(',')}). Señalar, marcar y revelar miran la misma observabilidad: no hay tres reglas`);
    await ctx.close();
  }

  /* ===== N18 · el progreso vuelve, y lo corrupto no rompe nada =========== */
  {
    const { ctx, page, errores } = await abrir(browser, 1440, 900);
    await page.click('#btn-empezar'); await page.waitForTimeout(700);
    await orientarHastaVer(page, 'Ori', 22);
    const p1 = await puntoQueIdentifica(page, 'Ori');
    await page.mouse.click(p1.x, p1.y); await page.waitForTimeout(500);
    await page.click('#btn-revelar'); await page.waitForTimeout(600);
    const guardado = await page.evaluate(() => ({
      lugar: { ...IG_DEBUG.estado.lugares.Ori },
      bruto: localStorage.getItem(IG_CONFIG.CLAVE_GUARDADO)
    }));
    await page.reload(); await page.waitForTimeout(700);
    const tras = await page.evaluate(() => ({
      progreso: document.getElementById('progreso-global').textContent,
      continuar: !document.getElementById('btn-continuar').hidden
    }));
    await page.click('#btn-continuar'); await page.waitForTimeout(700);
    const sigue = await page.evaluate(() => ({
      descubiertas: Object.keys(IG_DEBUG.estado.descubiertas),
      lugar: IG_DEBUG.estado.lugares.Ori ? { ...IG_DEBUG.estado.lugares.Ori } : null,
      cam: { ...IG_DEBUG.estado.camara }
    }));
    const mismoLugar = sigue.lugar && ['ra', 'dec', 'fov']
      .every(k => Math.abs(sigue.lugar[k] - guardado.lugar[k]) < 1e-6);
    /* basura, versión futura y campos de más: ninguno debe tirar la escena ni
       colarse en el estado */
    const casos = [];
    const clave = await page.evaluate(() => IG_CONFIG.CLAVE_GUARDADO);
    await ctx.close();
    for (const [nombre, valor] of [
      ['texto que no es JSON', 'no-soy-json{{'],
      ['versión futura', JSON.stringify({ v: 99, descubiertas: ['Ori'], lugares: { Ori: { ra: 1, dec: 1, fov: 30 } } })],
      ['constelación inventada', JSON.stringify({ v: 1, descubiertas: ['XYZ', 'Ori'], lugares: { XYZ: { ra: 1, dec: 1, fov: 30 } } })],
      ['cámara imposible', JSON.stringify({ v: 1, descubiertas: ['Ori'], lugares: { Ori: { ra: 99, dec: 400, fov: -3 } }, camara: { ra: 'x', dec: null, fov: 1e9 } })]
    ]) {
      /* contexto nuevo y la memoria escrita antes de que corra nada: así se
         prueba lo que se quiere probar y no lo que la página acaba de guardar
         al cerrarse. */
      const c2 = await browser.newContext({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1 });
      const p2 = await c2.newPage();
      const fallos2 = [];
      p2.on('pageerror', e => fallos2.push(e.message));
      p2.on('console', m => { if (m.type() === 'error') fallos2.push(m.text()); });
      await p2.addInitScript(([k, v]) => { try { localStorage.setItem(k, v); } catch (e) {} }, [clave, valor]);
      await p2.goto(URL); await p2.waitForTimeout(600);
      const estado = await p2.evaluate(() => ({
        descubiertas: Object.keys(IG_DEBUG.estado.descubiertas),
        lugares: Object.keys(IG_DEBUG.estado.lugares),
        portadaViva: !document.getElementById('btn-empezar').hidden }));
      await p2.click('#btn-empezar'); await p2.waitForTimeout(600);
      const camOk = await p2.evaluate(() => {
        const c = IG_DEBUG.estado.camara;
        return isFinite(c.ra) && isFinite(c.dec) && isFinite(c.fov) &&
          c.fov >= IG_CONFIG.CAMPO_VISION.minimo && c.fov <= IG_CONFIG.CAMPO_VISION.maximo;
      });
      casos.push({ nombre, descubiertas: estado.descubiertas.join(',') || '—',
                   lugares: estado.lugares.join(',') || '—',
                   viva: estado.portadaViva && camOk && fallos2.length === 0 });
      await c2.close();
    }
    const sinInventos = casos.every(c => c.viva && !/XYZ/.test(c.descubiertas) && !/XYZ/.test(c.lugares));
    const futuraIgnorada = casos[1].descubiertas === '—';
    const camaraSaneada = casos[3].lugares === '—';
    const basuraIgnorada = casos[0].descubiertas === '—';
    const inventoFuera = casos[2].descubiertas === 'Ori';
    reg('N18', mismoLugar && tras.continuar && sigue.descubiertas.join() === 'Ori' && errores.length === 0 &&
      sinInventos && basuraIgnorada && futuraIgnorada && camaraSaneada && inventoFuera,
      `recargando, el progreso vuelve («${tras.progreso}») y el sitio del hallazgo es el mismo (${mismoLugar}); ` +
      `con la memoria corrupta, de una versión futura, con una constelación inventada o con una cámara imposible ` +
      'la escena abre igual y no se cuela nada: lo que no se reconoce se descarta en vez de adivinarlo ' +
      `(${casos.map(c => c.nombre + '→' + c.descubiertas).join(' · ')})`);
  }

  /* ===== N19 · ES/EN: mismas acciones, pista traducida, nada se pierde === */
  {
    const { ctx, page } = await abrir(browser, 1440, 900);
    await page.click('#btn-empezar'); await page.waitForTimeout(700);
    await orientarHastaVer(page, 'Ori', 22);
    const p1 = await puntoQueIdentifica(page, 'Ori');
    await page.mouse.click(p1.x, p1.y); await page.waitForTimeout(500);
    await page.click('#btn-revelar'); await page.waitForTimeout(500);
    await page.click('#btn-continuar-pista'); await page.waitForTimeout(400);
    const es = await page.evaluate(() => ({
      pista: document.getElementById('objetivo').textContent,
      cam: { ...IG_DEBUG.estado.camara }, objetivo: IG_DEBUG.estado.objetivo,
      cuaderno: document.getElementById('btn-cuaderno').textContent
    }));
    /* se cambia de idioma con el teclado: el foco tiene que seguir en el mismo
       botón después de redibujarlo todo, no perderse por el camino. */
    await page.evaluate(() => document.querySelector('[data-idioma="en"]').focus());
    await page.keyboard.press('Enter'); await page.waitForTimeout(500);
    const en = await page.evaluate(() => ({
      lang: document.documentElement.lang,
      pista: document.getElementById('objetivo').textContent,
      cam: { ...IG_DEBUG.estado.camara }, objetivo: IG_DEBUG.estado.objetivo,
      descubiertas: Object.keys(IG_DEBUG.estado.descubiertas),
      foco: document.activeElement.getAttribute('data-idioma') || document.activeElement.id,
      cuaderno: document.getElementById('btn-cuaderno').textContent
    }));
    await page.click('#btn-cuaderno'); await page.waitForTimeout(500);
    const cuadEn = await page.evaluate(() => ({
      titulo: document.getElementById('panel-titulo').textContent,
      sitio: (document.querySelector('.ig-cuaderno-fila p') || {}).textContent || '',
      volver: [...document.querySelectorAll('.ig-cuaderno-fila button')].map(b => b.textContent)
    }));
    await page.screenshot({ path: path.join(CAP, '1440-13-ingles.png') });
    const mismaVista = ['ra', 'dec', 'fov'].every(k => Math.abs(es.cam[k] - en.cam[k]) < 1e-9);
    const traducida = en.pista !== es.pista && /right ascension|From |Look for/i.test(cuadEn.sitio + en.pista);
    const sinSpoiler = !/Canis|Great Dog|Sirius/i.test(en.pista);
    reg('N19', en.lang === 'en' && mismaVista && traducida && sinSpoiler &&
      en.descubiertas.join() === 'Ori' && en.objetivo === es.objetivo && en.foco === 'en' &&
      /Notebook/.test(cuadEn.titulo),
      `cambiar a inglés conserva orientación (${mismaVista}), hallazgos y foco (${en.foco}); la pista se traduce ` +
      `(«${en.pista.slice(0, 56)}…») sin nombrar su objetivo, el foco se queda en el botón que se pulsó ` +
      `(${en.foco}) y el cuaderno también cambia («${cuadEn.titulo}», ` +
      `«${cuadEn.volver.join('» / «')}»). El objetivo sigue siendo el mismo: ${en.objetivo}`);
    await ctx.close();
  }

  /* ===== N20 · medidas a 320/390/1440 ==================================== */
  {
    const medidas = [];
    for (const [w, h] of [[320, 568], [390, 844], [1440, 900]]) {
      const ctx = await browser.newContext({ viewport: { width: w, height: h }, deviceScaleFactor: 1 });
      const page = await ctx.newPage();
      const t0 = Date.now();
      await page.goto(URL);
      await page.waitForFunction(() => !!window.IG_DEBUG && !!IG_DEBUG.cielo());
      const listo = Date.now() - t0;
      await page.click('#btn-empezar');
      await page.waitForTimeout(500);
      await page.evaluate(() => IG_DEBUG.reiniciarMedidas());
      /* 60 cuadros de orientación continua, como un arrastre largo */
      const caja = await page.evaluate(() => {
        const r = document.getElementById('lienzo').getBoundingClientRect();
        return { x: r.left + r.width / 2, y: r.top + r.height / 2 };
      });
      await page.mouse.move(caja.x, caja.y);
      await page.mouse.down();
      const tDrag = Date.now();
      for (let q = 1; q <= 60; q++) { await page.mouse.move(caja.x - q, caja.y + q * 0.6); }
      const msDrag = Date.now() - tDrag;
      await page.mouse.up();
      await page.waitForTimeout(200);
      const m = await page.evaluate(() => {
        const d = IG_DEBUG.medidas(), c = IG_DEBUG.cielo();
        return { ...d, estrellas: c.estrellas.length,
                 puntosVia: c.via.reduce((s, t) => s + t.length, 0),
                 heap: (performance.memory && performance.memory.usedJSHeapSize) || null,
                 W: IG_DEBUG.medir().W, H: IG_DEBUG.medir().H };
      });
      /* latencia de entrada: de pulsar a tener respuesta en pantalla */
      const lat = await page.evaluate(() => {
        const r = document.getElementById('lienzo').getBoundingClientRect();
        const t = performance.now();
        document.getElementById('lienzo').dispatchEvent(new PointerEvent('pointerdown',
          { clientX: r.left + r.width * 0.3, clientY: r.top + r.height * 0.4, button: 0, bubbles: true, pointerId: 7 }));
        document.getElementById('lienzo').dispatchEvent(new PointerEvent('pointerup',
          { clientX: r.left + r.width * 0.3, clientY: r.top + r.height * 0.4, button: 0, bubbles: true, pointerId: 7 }));
        return Math.round((performance.now() - t) * 100) / 100;
      });
      /* redimensionar en caliente: la orientación no debe moverse */
      const camA = await page.evaluate(() => ({ ...IG_DEBUG.estado.camara }));
      await page.setViewportSize({ width: w, height: Math.max(360, h - 120) });
      await page.waitForTimeout(400);
      const camB = await page.evaluate(() => ({ ...IG_DEBUG.estado.camara }));
      const estable = ['ra', 'dec', 'fov'].every(k => Math.abs(camA[k] - camB[k]) < 1e-9);
      medidas.push({ ancho: w, alto: h, lienzo: m.W + '×' + m.H, arranque_ms: listo,
                     cuadros: m.cuadros, ms_por_cuadro: m.ms_por_cuadro,
                     cuadros_por_segundo_equivalente: m.ms_por_cuadro ? Math.round(1000 / m.ms_por_cuadro) : null,
                     ms_de_60_movimientos: msDrag, latencia_pulsacion_ms: lat,
                     dibujables: m.estrellas + m.puntosVia, estrellas: m.estrellas, puntos_via: m.puntosVia,
                     heap_mb: m.heap ? Math.round(m.heap / 1048576 * 10) / 10 : null,
                     orientacion_estable_al_redimensionar: estable });
      await ctx.close();
    }
    fs.writeFileSync(path.join(RAIZ, 'documentacion', 'MEDIDAS_R02.json'),
      JSON.stringify({ entorno: 'Chromium automatizado en contenedor Linux, DPR 1. NO es un teléfono real: ' +
        'las cifras de 320 y 390 son de un navegador de escritorio con el recuadro a ese tamaño.',
        medidas }, null, 2));
    const peor = Math.max(...medidas.map(m => m.ms_por_cuadro));
    const todasEstables = medidas.every(m => m.orientacion_estable_al_redimensionar);
    reg('N20', peor < 16.7 && todasEstables,
      `medido en los tres anchos: ${medidas.map(m => m.ancho + 'px ' + m.ms_por_cuadro + ' ms/cuadro (~' +
        m.cuadros_por_segundo_equivalente + '/s), arranque ' + m.arranque_ms + ' ms, pulsación ' +
        m.latencia_pulsacion_ms + ' ms, ' + (m.heap_mb === null ? 'heap no medible' : m.heap_mb + ' MB') ).join(' · ')} ` +
      `· ${medidas[0].dibujables} dibujables (${medidas[0].estrellas} estrellas + ${medidas[0].puntos_via} de vía). ` +
      `El peor cuadro (${peor} ms) cabe en 60/s y redimensionar no mueve la orientación (${todasEstables}). ` +
      'Las cifras van a documentacion/MEDIDAS_R02.json');
  }

  /* ===== N22 · FUTURE_STORAGE_PRESERVED_BYTES_ORACLE ===================== */
  {
    /* P1-02, caso exacto de Axioma. Lo guardado por una versión posterior no se
       entiende, pero es de alguien: ni se lee, ni se pisa, ni se borra. */
    const BYTES = '{"v":99,"descubiertas":["Ori"],"future":"KEEP"}';
    const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1 });
    const page = await ctx.newPage();
    const fallosJS = [];
    page.on('pageerror', e => fallosJS.push(e.message));
    page.on('console', m => { if (m.type() === 'error') fallosJS.push(m.text()); });
    await page.addInitScript((v) => {
      try { localStorage.setItem('iris-green.cielo-3d.r02', v); } catch (e) {}
    }, BYTES);
    await page.goto(URL);
    await page.waitForTimeout(600);
    const clave = await page.evaluate(() => IG_CONFIG.CLAVE_GUARDADO);
    const leer = () => page.evaluate(k => localStorage.getItem(k), clave);
    const medir = async (paso) => ({ paso, bytes: await leer() });
    const pasos = [];
    pasos.push(await medir('al cargar'));

    const estadoInicial = await page.evaluate(() => ({
      soloLectura: IG_DEBUG.soloLectura(),
      descubiertas: Object.keys(IG_DEBUG.estado.descubiertas),
      aviso: document.getElementById('aviso').hidden ? null : document.getElementById('aviso').textContent
    }));

    await page.click('#btn-empezar');
    await page.waitForTimeout(700);
    pasos.push(await medir('al entrar'));

    /* 1 · mover la cámara, que es lo que antes disparaba el guardado diferido */
    await page.evaluate(() => document.getElementById('escenario').focus());
    await page.keyboard.press('ArrowRight');
    await page.waitForTimeout(1200);
    pasos.push(await medir('tras mover la cámara'));

    /* 2 · descubrir algo de verdad */
    await orientarHastaVer(page, 'Ori', 22);
    const pOri = await puntoQueIdentifica(page, 'Ori');
    await page.mouse.click(pOri.x, pOri.y);
    await page.waitForTimeout(500);
    await page.click('#btn-revelar');
    await page.waitForTimeout(900);
    pasos.push(await medir('tras descubrir'));

    /* 3 · abrir y cerrar la ficha */
    await page.click('#btn-saber-mas');
    await page.waitForTimeout(900);
    await page.click('#btn-cerrar-panel');
    await page.waitForTimeout(700);
    pasos.push(await medir('tras abrir y cerrar la ficha'));

    /* 4 · cambiar de idioma */
    await page.click('[data-idioma="en"]');
    await page.waitForTimeout(700);
    const avisoEN = await page.evaluate(() => document.getElementById('aviso').textContent);
    await page.click('[data-idioma="es"]');
    await page.waitForTimeout(500);
    pasos.push(await medir('tras cambiar de idioma'));

    /* 5 · y salir de la pantalla, que también guardaba */
    await page.click('#btn-volver-portada');
    await page.waitForTimeout(800);
    pasos.push(await medir('al volver a la portada'));

    /* 6 · incluso el borrado explícito deja intactos los bytes ajenos */
    await page.click('#btn-borrar');
    await page.waitForTimeout(400);
    await page.click('#dialogo-confirmar');
    await page.waitForTimeout(700);
    pasos.push(await medir('tras borrar los hallazgos de esta sesión'));

    const intactos = pasos.every(s => s.bytes === BYTES);
    const cambiado = pasos.filter(s => s.bytes !== BYTES).map(s => s.paso);
    const sinFalsoGuardado = !/guardad|saved/i.test(estadoInicial.aviso || '') ||
      /no se guardará|will not be saved/i.test(estadoInicial.aviso || '');
    const avisa = !!estadoInicial.aviso && /más nueva/.test(estadoInicial.aviso);
    const traducido = /newer version/.test(avisoEN || '');
    await page.screenshot({ path: path.join(CAP, '1440-14-storage-futuro.png') });
    reg('N22', intactos && estadoInicial.soloLectura === true &&
      estadoInicial.descubiertas.length === 0 && avisa && traducido && sinFalsoGuardado &&
      fallosJS.length === 0,
      intactos
        ? `con un guardado de versión 99 en el navegador, los bytes siguen idénticos en los ${pasos.length} pasos ` +
          `(cargar, entrar, mover, descubrir, ficha, idioma, portada y borrar): se entra en sólo lectura ` +
          `(${estadoInicial.soloLectura}), no se inyecta nada al estado (${estadoInicial.descubiertas.length} ` +
          `descubiertas), se avisa de que esta sesión no guardará —y el aviso cambia de idioma— y no se promete ` +
          'ningún guardado. Lo que no se entiende no se destruye'
        : 'los bytes cambiaron en: ' + cambiado.join(', '));
    await ctx.close();
  }

  /* ===== N23 · el caso de Perseo en la interfaz real ====================== */
  {
    const { ctx, page } = await abrir(browser, 1440, 900);
    await page.click('#btn-empezar');
    await page.waitForTimeout(700);
    /* Mismo encuadre que reprodujo Axioma. Llegar ahí arrastrando desde Orión
       llevaría medio cielo: aquí se comprueba la DECISIÓN y el marcado, que es
       lo que el P1 ponía en duda, no cómo se llega. */
    const r = await page.evaluate(() => {
      IG_DEBUG.estado.camara = IG_ESFERA.ajustarCamara({ ra: 2.58, dec: 38.2, fov: 45 });
      const m = IG_DEBUG.medir();
      const q = IG_DEBUG.examinarEn({ x: m.W / 2, y: m.H / 2 }, {});
      const per = IG_DEBUG.cielo().porAbbr.Per;
      const d = q.detalle.filter(x => x.abbr === 'Per')[0];
      return { resultado: q.resultado, mejor: q.mejor && q.mejor.abbr,
               dentro: d.dentro, minimo: d.minimo_semantico,
               noRenderizados: d.ocultos.no_renderizados,
               indices: d.puntos_dentro.map(p => per.puntos.indexOf(p)) };
    });
    /* y, barriendo la pantalla entera en este encuadre, el overlay nunca marca
       un punto que el cielo no dibuja */
    const barrido = await page.evaluate(() => {
      const m = IG_DEBUG.medir();
      let marcados = 0, fantasmas = 0, identificaciones = 0;
      for (let y = 30; y < m.H - 30; y += 24) {
        for (let x = 30; x < m.W - 30; x += 24) {
          const q = IG_DEBUG.examinarEn({ x, y }, {});
          if (q.coincide) identificaciones++;
          q.detalle.forEach(d => d.puntos_dentro.forEach(p => {
            marcados++;
            if (!p.observable) fantasmas++;
          }));
        }
      }
      return { marcados, fantasmas, identificaciones };
    });
    await page.screenshot({ path: path.join(CAP, '1440-15-perseo.png') });
    reg('N23', r.resultado === 'ninguno' && !r.mejor && r.dentro === 2 && r.minimo === 3 &&
      r.noRenderizados === 1 && barrido.fantasmas === 0,
      `en el encuadre exacto de Axioma (AR 2,58 h, Dec +38,2°, 45°) la interfaz ya no identifica nada: ` +
      `${r.dentro} puntos observables [${r.indices.join(',')}] frente a un mínimo de ${r.minimo}, con 1 vértice ` +
      `declarado no renderizado. Barriendo la pantalla entera en ese encuadre, de ${barrido.marcados} puntos de ` +
      `evidencia ninguno corresponde a un punto que el cielo no dibuje (${barrido.fantasmas})`);
    await ctx.close();
  }

  await browser.close();
  fs.writeFileSync(path.join(__dirname, 'resultados-navegador.json'), JSON.stringify(res, null, 2));
  const fallos = res.filter(r => r.estado === 'FALLO').length;
  console.log(`\n=== NAVEGADOR: ${res.length} comprobaciones del autor · ${fallos} fallos ===`);
  console.log('Chromium automatizado. No es un teléfono real, ni un lector de pantalla, ni HUMAN QA.');
  if (fallos) process.exitCode = 1;
})().catch(e => { console.error('ERROR BANCO:', e); process.exit(1); });
