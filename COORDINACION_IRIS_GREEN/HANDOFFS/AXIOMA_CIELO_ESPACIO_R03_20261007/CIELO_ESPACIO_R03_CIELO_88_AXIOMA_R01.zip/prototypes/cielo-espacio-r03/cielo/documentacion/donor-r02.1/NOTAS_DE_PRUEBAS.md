# Notas de pruebas · Cielo 3D R02.1

2026-10-07. Qué se prueba, cómo, y —sobre todo— qué **no** queda probado.

## 1. Los dos bancos

| Banco | Comprobaciones | Qué mide | Cómo |
|---|---|---|---|
| `pruebas/unitarias.js` | 18 | geometría de la esfera, regla de evidencia, observabilidad, grafo de saltos y pistas | funciones puras en Node, con fixtures y con los datos del propio paquete |
| `pruebas/navegador.js` | 37 | la experiencia completa | Chromium automatizado sobre el paquete entregado, abierto con `file://` |

Las 55 están en verde. Los dos oráculos que pedía la orden de R02.1 son `U16`
(`VISIBLE_RENDERED_POINTS_ONLY_ORACLE`) y `N22`
(`FUTURE_STORAGE_PRESERVED_BYTES_ORACLE`); `U17` y `N23` reproducen el caso
exacto de Perseo y `U18` comprueba que el P2 no cambió comportamiento. **Son comprobaciones del autor.** No son un PASS
independiente, no son HUMAN QA y no sustituyen el retest de Nexo ni la revisión
de Axioma.

`pruebas/recorrido-video.js` graba el recorrido real en vídeo. Usa los mismos
ayudantes (`pruebas/ayudantes.js`) que el banco de navegador: lo que se ve en el
vídeo es lo que comprueba el banco.

## 2. Reglas que se respetan en el banco

- **Para llegar a un patrón se arrastra.** No se inyecta cámara. Leer dónde se ve
  un punto en pantalla no es moverlo: eso lo hace `IG_DEBUG.pantallaDe`, que sólo
  proyecta.
- **El punto donde se pulsa se busca mirando la pantalla**
  (`puntoQueIdentifica`): se prueban posiciones como las probaría una persona y
  se pulsa en una que funcione. Si ninguna funciona, el banco lo dice; no
  recoloca el cielo a mano para fabricar un acierto.
- **Las pistas no se escriben en el banco**: se leen de la pantalla y se
  comprueba que no nombren su objetivo.

## 3. Lo que NO queda probado

1. **Ambigüedad real con constelaciones reales.** Con estas 12 y un cono de 6° de
   radio no existe: se barrió el cielo entero (ascensión recta en pasos de 0,1 h,
   declinación de −40° a +70° en pasos de 1°, tres aperturas) y **no hay ni un
   punto con dos patrones sostenidos**. Por eso:
   - `U14` prueba la decisión con un cielo de prueba de dos figuras cruzadas, y
     comprueba que es idéntica a 320/390/1440;
   - `N15` prueba la interfaz **interceptando la respuesta del motor** en la
     página —no se falsean los datos, se envuelve la función y luego se
     restaura— y comprueba que no se revela nada, que las opciones no sueltan
     ningún nombre y que la orientación no se mueve.
   Esto es menos que una ambigüedad real y se declara así. Con 88 habrá zonas
   donde sí ocurra, y entonces habrá que medirla de verdad.
2. **Teléfono físico.** Los gestos táctiles van por CDP
   (`Input.dispatchTouchEvent`). Reproducen la lógica del gesto, no un teléfono:
   ni su pantalla, ni su GPU, ni su navegador, ni cómo responde una mano real.
   Las cifras de 320 y 390 px son de un navegador de escritorio con el recuadro a
   ese tamaño.
3. **Lector de pantalla real.** Hay vía descriptiva, `aria-live` y recorrido
   completo con teclado, y están comprobados como DOM y como foco. Nada de eso
   dice cómo lo lee NVDA, JAWS o VoiceOver.
4. **Figuras que no caben en la apertura.** Hidra, Eridano o Serpiente no están
   en esta región. `trozoQueCabe` ya limita el mínimo a lo que cabe en 6°, pero
   con estas 12 nunca se activa el caso extremo.
5. **Rendimiento con el catálogo completo.** Aquí hay 1.660 estrellas y 3.731
   puntos de Vía Láctea. El cielo entero a magnitud 5,6 es del orden de tres
   veces eso, y no está medido.
6. **Memoria a lo largo del tiempo.** `heap_mb` es una lectura puntual de
   `performance.memory` (9,5 MB en los tres anchos), no un perfil de fugas.
7. **Carga de las 12 fichas seguidas.** Se cargan bajo demanda y se prueba la
   invalidación de cargas obsoletas (`N08`, `N08b`), pero no el peso acumulado.
8. **Otros vértices sin estrella, a escala 88.** En esta región hay exactamente
   uno (Perseo 17) y queda declarado y excluido. Con 88 constelaciones habrá
   más, y cada uno habrá que mirarlo: `U16` fallará si alguno cuenta, pero
   nadie ha medido todavía cuántos hay ni si alguno parte una figura en dos.
9. **Versiones de guardado anteriores.** Lo que protege R02.1 es el guardado de
   una versión POSTERIOR. Un guardado de una versión anterior se sigue
   descartando y sobrescribiendo: no hay migración, y no se promete ninguna.

## 4. Medidas

En `MEDIDAS_R02.json`, generadas por `N20` en la misma ejecución del banco:
arranque, ms por cuadro, equivalente en cuadros por segundo, latencia de
pulsación, dibujables, heap y estabilidad de la orientación al redimensionar, a
320, 390 y 1440.

Lectura honesta: el coste por cuadro (0,86–1,08 ms) lo manda el número de
estrellas, no el de figuras, y ninguna de las tres anchuras está cerca del
presupuesto de 16,7 ms. Eso dice que hay margen, no que un teléfono real vaya a
dar lo mismo.

R02.1 no cambia el rendimiento: no toca el dibujado ni añade estrellas. Las
medidas se vuelven a generar en cada ejecución del banco, así que el fichero
corresponde a este paquete.
