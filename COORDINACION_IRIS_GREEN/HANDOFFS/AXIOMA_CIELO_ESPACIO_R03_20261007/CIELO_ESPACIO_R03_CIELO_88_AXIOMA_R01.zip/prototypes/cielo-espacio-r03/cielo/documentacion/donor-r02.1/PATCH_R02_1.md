# Patch R02.1 · dos P1 de integridad de datos

2026-10-07. Orden: `ORDEN_CLAUDE_CIELO_3D_R02_1_DATA_INTEGRITY.md`, commit
`889abc2cabec6ee81509a18da8aa039a9f0a6b4e`. Base: `CIELO_3D_R02.zip`,
SHA256 `e64780f272fb21ed880e020bc2ac74364e456e1e533476a70d72401cc8d79bba`
(comprobado antes de empezar).

KEEP completo de R02. No se ha reabierto la esfera, las 12 constelaciones, el
recorrido, las pistas, el hallazgo fuera de orden, el cuaderno, LOCATE → REVEAL,
los gestos, el foco, el panel, el rendimiento, los assets ni el diseño visual.
Sólo los dos P1, el P2 trivial y el retest dirigido.

## P1-01 · Perseo podía identificarse con un punto que no se dibuja

**Reproducido tal cual lo describió Axioma**, antes de tocar nada:

    cámara AR 2,58 h · Dec +38,2° · FOV 45° · examen en el centro
    resultado = unico · mejor = Per · mínimo = 3
    puntos = [15,16,17] · asociaciones = [105,556,null]

El dibujante recorre las estrellas del catálogo; el motor de evidencia recorría
**todos** los puntos de la figura, incluido el vértice 17, que no tiene estrella
asociada. Con él, Perseo llegaba al mínimo de 3. Sin él, se queda en 2.

### Qué es ese punto, medido

Antes de elegir vía, se buscó en el catálogo **completo** (`cielo.json`, HYG
v4.1) qué hay en esa posición:

| | |
|---|---|
| Vértice | Perseo, punto 17 · AR 2,9944 h · Dec +41,03° |
| Estrella en el catálogo | **HIP 13949** (Per), a **0,003°** de ese vértice |
| Magnitud | **5,89** |
| Magnitud límite del paquete | **5,6** |

No es una asociación que faltara por error: es una estrella **más débil que el
límite declarado del paquete**, y por eso no se dibuja. La otra vía que permitía
la orden —asociarla— habría exigido dibujar una estrella por debajo del límite
declarado, dejando fuera a todas las demás del mismo rango. Eso sería cambiar
los datos sin necesidad y mentir sobre la magnitud límite.

### Vía elegida: excluirlo de toda evidencia

Un punto de figura sólo sostiene evidencia si **su estrella se dibuja**. En
concreto:

- no se cuenta como observado ni como visible;
- no suma al mínimo semántico;
- no entra en el trozo seguido, y **la adyacencia de evidencia no puentea por
  encima de él**: si dos estrellas sólo estaban unidas a través suyo, para la
  evidencia no están unidas (`vecinosObs`);
- `trozoQueCabe` —el mínimo que de verdad cabe en la apertura— se calcula sólo
  sobre puntos observables;
- nunca puede aparecer como marca de evidencia en pantalla.

Se cuenta aparte, en `ocultos.no_renderizados`, para que el recorte quede
declarado y no escondido.

**No se ha tocado ningún master.** La figura aprobada de Perseo sigue teniendo
sus 23 vértices y sus 23 aristas, y se dibuja entera. Lo único que cambia es qué
puede sostener una identificación.

### En los datos, además

`datos/cielo3d.js` declara ahora, por constelación, `puntos_no_observables` con
el índice, la posición, el motivo, la estrella real del catálogo y su magnitud,
más una `regla_observabilidad` global. La exclusión se puede auditar sin
deducirla de un `null`.

### Consecuencia medida

- El caso de Axioma pasa de `unico → Per` a **`ninguno`** (`U17`, `N23`).
- Perseo **sigue siendo identificable** desde un punto de puntería razonable, y
  con la misma decisión a 320/390/1440 (`U15`). Quitar el vértice 17 no parte la
  figura: sigue siendo un solo trozo de 22 puntos.
- Barriendo el cielo entero, **ninguna** decisión se apoya en un punto no
  dibujado (`U16`).

### Oráculo nuevo · `VISIBLE_RENDERED_POINTS_ONLY_ORACLE` → `U16`

Falla si un punto con `estrella=null` cuenta, si un punto no renderizado
contribuye al mínimo, si la adyacencia de evidencia lo puentea, si lo declarado
en los datos no coincide con lo que hace el motor, o si el overlay marca
evidencia que el cielo no dibuja. `N23` lo comprueba además en la interfaz real:
en el encuadre de Axioma, de 1.974 puntos de evidencia barriendo la pantalla,
cero corresponden a un punto no dibujado.

## P1-02 · un guardado de versión futura se ignoraba y luego se destruía

**Reproducido tal cual**: con
`{"v":99,"descubiertas":["Ori"],"future":"KEEP"}` en el navegador, `cargar()`
hacía bien lo suyo —no contaminaba el estado— pero a la primera interacción el
guardado diferido escribía encima y los bytes se perdían.

### Corrección

Si `stored.v > VERSION_GUARDADO`, el paquete entra en **sólo lectura para esa
clave**:

- `guardar()` no escribe nada, nunca;
- `borrarHallazgos()` vacía esta sesión pero **no borra** lo guardado;
- no se anuncia ningún guardado: se avisa de lo contrario, de que lo de esta
  sesión no se guardará;
- la sesión funciona entera, en memoria;
- los bytes originales quedan **idénticos**.

El aviso está en ES y EN y se vuelve a escribir al cambiar de idioma, en vez de
quedarse congelado.

Qué NO cambia: una versión **anterior** o un contenido corrupto se siguen
descartando y sobrescribiendo como en R02 (`N18`). Lo que se protege es lo que
viene de una versión que este paquete no entiende.

### Oráculo nuevo · `FUTURE_STORAGE_PRESERVED_BYTES_ORACLE` → `N22`

Compara los bytes en ocho momentos: al cargar, al entrar, tras mover la cámara,
tras descubrir, tras abrir y cerrar la ficha, tras cambiar de idioma, al volver
a la portada y tras borrar los hallazgos de la sesión. Idénticos en los ocho. Y
comprueba que se avisa, que el aviso se traduce y que no se promete ningún
guardado.

## P2 · la interfaz ya no nombra a Orión

La orden lo marcaba como no bloqueante, a tocar sólo si era trivial y no
alteraba el comportamiento. Lo era:

- `camaraInicial()` toma la raíz de `orden_saltos` en vez de `porAbbr('Ori')`, y
  el punto de referencia es el centro del subpatrón documentado si lo hay, o el
  ancla medida de la figura si no. Ningún índice adivinado.
- **La cámara de entrada resultante es idéntica**, dígito a dígito:
  AR 6,9536 h, Dec 13,8°, 60°. Lo comprueba `U18`, que además verifica que se
  sigue entrando a 15,3° del patrón —más que el radio de la zona de examen—, así
  que hay que buscarlo igual que antes.
- Ya no queda ninguna abreviatura de constelación escrita en `js/`.

**Queda pendiente para el escalado**: el desvío de entrada (+1,35 h de AR, +15°
de declinación) sigue siendo una constante declarada en la interfaz
(`DESVIO_DE_ENTRADA`). Debería pasar a los datos antes de 88/88.

## HUMAN QA · lo que María debe mirar

Las pistas de salto nombran un ancla ya aprendida: *«Desde Rigel…»*. La ficha de
Orión presenta a Rigel, Betelgeuse y Bellatrix, pero **el cielo no etiqueta a
Rigel en su posición**.

La pregunta para HUMAN QA es si el nombre aprendido en la ficha queda
suficientemente conectado con su posición real para empezar el salto sin ayuda
extra.

**No se ha añadido ninguna etiqueta permanente**, como pide la orden. Si falla,
las vías permitidas —sin revelar el objetivo— serían señalar temporalmente el
ancla ya aprendida, o describirla por su posición dentro de la figura ya
encontrada. Ninguna de las dos está implementada aquí: sería adelantarse a la
respuesta.

## Retest

| | R02 | R02.1 |
|---|---|---|
| Unitarias | 15 | **18** |
| Navegador | 35 | **37** |
| Total | 50 | **55**, 0 fallos |

Las 15 unitarias de R02 siguen pasando. Nuevas: `U16` (oráculo de puntos
renderizados), `U17` (caso exacto de Axioma), `U18` (P2 sin cambio de
comportamiento), `N22` (oráculo de bytes del storage futuro), `N23` (Perseo en la
interfaz real). Sin regresión de foco, pinza, panel, idioma ni rendimiento, en
320/390/1440.

Un ajuste de banco, no de producto: el cielo de prueba de `U14` se construye
ahora con `construirCielo` para que sus puntos sean observables de verdad. Antes
los fabricaba a mano con `estrella: null` y, con la regla nueva, habría pasado
por el motivo equivocado.
