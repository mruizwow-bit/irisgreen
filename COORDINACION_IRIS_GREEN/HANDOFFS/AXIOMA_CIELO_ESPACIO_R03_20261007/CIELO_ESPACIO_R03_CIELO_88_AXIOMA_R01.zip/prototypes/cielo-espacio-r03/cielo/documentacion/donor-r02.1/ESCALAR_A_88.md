# De 12 a 88 · qué está demostrado y qué falta

2026-10-06. La orden pide documentar el escalado, **no** escalar. Esto es lo que
esta ampliación deja probado, lo que ya está calculado para las 88 y lo que
sigue abierto.

## 1. Lo que cambia al escalar, y lo que no

Nada de lo que se ha hecho aquí depende de que sean 12.

| Pieza | ¿Depende del número de constelaciones? |
|---|---|
| Geometría de la esfera, cámara `{ra, dec, fov}` | No |
| Evidencia: cono de 6° de radio, mínimo semántico derivado de la figura | No. Se calcula por figura, al construir el cielo |
| Decisión `examinar` | No. Recorre las figuras del cielo que haya |
| Recorrido y pistas | No. Salen de los datos: `orden_saltos`, `salto`, `pista`, `rasgos` |
| Interfaz | No. Desde R02 no hay ninguna lista de constelaciones escrita en el programa |
| Dibujado | Sí, linealmente con las estrellas que entren en el catálogo |
| Generación de datos | Sí: `gen_3d_r02.py` recorre las constelaciones que se le den |

Dicho de otra forma: pasar a 88 es **cambiar el fichero de datos**, no reescribir
la aplicación. Esta entrega se hizo así a propósito, para que el salto sea
comprobable y no un rediseño.

## 2. Lo que ya está medido aquí

- **Reachability.** Las 12 se identifican desde un punto de puntería razonable y
  con la misma decisión a 320/390/1440 (`U15`). El mismo tipo de prueba que en el
  paquete 2D llegó a 88/88 bajo la regla angular nueva, después de derivar el
  mínimo de la figura (`minimoSemantico` / `trozoQueCabe`).
- **Vecindad.** El grafo de saltos se construye midiendo separaciones angulares
  entre las estrellas más claras de cada figura. Con 88 el algoritmo es el mismo;
  lo único que crece es el número de aristas candidatas.
- **Rendimiento con el catálogo entero de la región.** Ya se dibujan 1.660
  estrellas y 3.731 puntos de Vía Láctea: 5.391 dibujables, entre 0,86 y 1,08 ms
  por cuadro según el ancho, 9,5 MB de heap, arranque por debajo de 110 ms
  (`MEDIDAS_R02.json`). El coste por cuadro lo manda el **número de estrellas**,
  no el de figuras.
- **Continuidad sin selector.** Las 12 están repartidas en dos zonas del
  catálogo de origen (`campo-03` y `campo-06`) y se recorren arrastrando, sin
  selector de campo y sin ninguna carga intermedia (`N01h`).

## 3. Lo que hay que medir antes de 88/88

1. **Cuántas estrellas entran.** Un casquete para las dos zonas da 1.660. El
   cielo completo a magnitud 5,6 son del orden de 5.000–6.000 estrellas. Hay que
   medirlo de verdad, no estimarlo: la curva de coste por cuadro es lineal, pero
   el dibujado de la Vía Láctea y las etiquetas no se han medido a esa escala.
2. **Ambigüedad, que aquí no se puede provocar.** Con 12 figuras y un cono de 6°
   no hay ni un punto del cielo con dos patrones sostenidos. Con 88 habrá zonas
   densas donde sí (la región de Virgo/Coma, el triángulo de verano, el campo de
   Sagitario). El camino de C3D-02 está construido y probado con un cielo de
   prueba (`U14`) y en la interfaz (`N15`), pero **con 88 hay que volver a barrer
   el cielo y medir cuántos puntos quedan ambiguos**: si son muchos, el problema
   ya no es la decisión, es el tamaño del cono.
3. **Mínimos semánticos de figuras grandes y deshilachadas.** Perseo y Piscis ya
   avisan: 23 y 22 puntos con un mínimo de 3. Con 88 entran Hidra, Eridano y
   Serpiente, que no caben en 6° ni de lejos. `trozoQueCabe` ya limita el mínimo
   a lo que cabe en la apertura, pero ninguna de esas figuras está probada.
4. **Fichas y pesos.** Hay 88 fichas en el paquete 2D y aquí se cargan bajo
   demanda, una por constelación. A 88 hay que medir el peso total del paquete y
   el tiempo de la primera carga de ficha con el disco frío.
5. **Recorrido con 88 nodos.** El coste del árbol es trivial de calcular, pero un
   recorrido de 88 pasos no es una experiencia: habrá que decidir si se agrupa
   por estaciones, por regiones o por rutas cortas. **Esa es una decisión de
   producto, no técnica**, y no la toma este paquete.
6. **Accesibilidad a esa escala.** La vía descriptiva funciona con 12. Con 88, la
   descripción del entorno puede volverse ruido; hay que probarla con lector de
   pantalla real, que es cosa de Axioma.

## 4. Lo que NO habría que hacer al escalar

- No bajar el mínimo semántico para que «entren más». El mínimo sale de la
  figura; si una figura no se sostiene en 6°, lo que hay que revisar es la
  apertura o la figura, no el mínimo.
- No volver a meter proximidad en píxeles para resolver ambigüedades. Con 88 la
  tentación será mayor y el error sería el mismo.
- No inventar estrellas ni retocar figuras aprobadas para que el patrón cierre.
- No escalar y rehacer masters en el mismo paso: si algo se rompe, no se sabría
  qué lo rompió.
