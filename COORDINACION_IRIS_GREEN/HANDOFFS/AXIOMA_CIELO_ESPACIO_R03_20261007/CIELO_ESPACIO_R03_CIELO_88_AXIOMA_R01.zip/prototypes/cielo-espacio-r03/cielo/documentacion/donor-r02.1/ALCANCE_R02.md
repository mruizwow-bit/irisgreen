# Alcance de esta entrega · Cielo 3D · R02.1

2026-10-07. Esta entrega es **R02 con dos P1 de integridad de datos
corregidos**. Lo que sigue describe el alcance de R02; lo que cambia en R02.1
está en `PATCH_R02_1.md`.

Orden de R02.1: `ORDEN_CLAUDE_CIELO_3D_R02_1_DATA_INTEGRITY.md`, commit
`889abc2cabec6ee81509a18da8aa039a9f0a6b4e`.
Base: `CIELO_3D_R02.zip`,
SHA256 `e64780f272fb21ed880e020bc2ac74364e456e1e533476a70d72401cc8d79bba`,
comprobado antes de empezar.

Orden de R02: `ORDEN_CLAUDE_CIELO_3D_AMPLIACION_R02.md`, commit
`5b880bc3ce33b36a67f0a29ad82da8c91bbde2e2`, registrada en #323, comentario
`6018816163`. Base de R02: `CIELO_3D_PILOTO_R01.zip`,
SHA256 `369b37a569a26689f7b52197a6393280d538ef4a413d65ceae98042a19dfb813`.

## 1. Qué es esto

La esfera celeste continua del piloto, ampliada a **12 constelaciones reales
encadenadas por relaciones de vecindad medidas**. El mínimo que pedía la orden
eran 8, con Orión y Tauro dentro: están las dos, y diez más.

La dirección de producto no se discute aquí. María la eligió después de probar
el piloto. **En esta entrega no hay ninguna comparación 2D vs 3D**, ni una
versión 2D con la que comparar: R02.1 queda como referencia y como rollback, en
su propio paquete.

## 2. Lo que sí se afirma

- Las 12 constelaciones se identifican señalándolas, y la decisión es **la misma
  a 320, 390 y 1440** (`U15`, `N02`).
- El recorrido entre ellas es un **grafo de vecindad medido sobre el catálogo**,
  no una lista escrita a mano: cada salto parte de una constelación ya
  encontrada, con su separación angular y su dirección en pantalla
  comprobadas (`U12`).
- Ninguna pista nombra lo que hay que encontrar, ni nombra ninguna de sus
  estrellas, ni cita una magnitud (`U13`, `N01f`, `N19`).
- Encontrar fuera de orden vale (`N01h`).
- **Un punto de figura que el cielo no dibuja no sostiene ninguna
  identificación**, y lo que se marca en pantalla es exactamente lo que sostuvo
  la decisión (`U16`, `U17`, `N23`).
- **Un guardado hecho por una versión posterior no se lee, no se pisa y no se
  borra**: los bytes siguen idénticos después de jugar una sesión entera
  (`N22`).
- 55 comprobaciones del autor en verde: 18 de funciones puras y 37 en navegador.
- El vídeo de `video/` es el recorrido real grabado por el navegador durante la
  prueba, sin montaje y sin acelerar.

## 3. Lo que NO se afirma

- **No es PASS independiente.** Todas las comprobaciones son del autor. Nada de
  lo que hay aquí sustituye el retest técnico de Nexo ni la revisión de Axioma.
- **No hay PASS científico global ni HUMAN QA.** La preferencia que María ya
  expresó sobre el piloto R01 no se presenta como validación de esta ampliación.
- **No es una prueba en teléfono físico.** Los gestos táctiles van por eventos
  del navegador (CDP `Input.dispatchTouchEvent`): reproducen la lógica del
  gesto. Las cifras de 320 y 390 px son de un navegador de escritorio con el
  recuadro a ese tamaño.
- **No es una prueba con lector de pantalla real.**
- **No se ha escalado a 88/88.** Cómo escalaría está en `ESCALAR_A_88.md`, con
  lo que ya está medido y lo que no.
- No se ha tocado `main`, no hay despliegue público y no se ha rehecho ningún
  master ni ninguna ficha.

## 4. Gate

Gate propuesto, **NO emitido**:
`CLAUDE_SKY_3D_R02_1_DATA_INTEGRITY_PATCH_READY_FOR_NEXO`.

(El de R02, `CLAUDE_SKY_3D_R02_EXPANSION_READY_FOR_NEXO`, tampoco lo emitió este
paquete.)

Lo emite Nexo después de su retest, no este paquete. El orden sigue siendo:
Nexo retest corto → Axioma precheck corto → HUMAN QA de María → decidir el
escalado 88/88.

En HUMAN QA hay una pregunta concreta anotada: si el ancla de las pistas de
salto —«Desde Rigel…»— queda suficientemente conectada con su posición en el
cielo. No se ha añadido ninguna etiqueta permanente para resolverla por
adelantado. Está en `PATCH_R02_1.md`.
