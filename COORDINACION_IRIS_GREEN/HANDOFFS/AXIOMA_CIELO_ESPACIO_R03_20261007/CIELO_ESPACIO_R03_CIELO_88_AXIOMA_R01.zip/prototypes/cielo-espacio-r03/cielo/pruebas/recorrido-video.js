/* Cielo 3D · R02 · GRABACIÓN DEL RECORRIDO REAL.

   ALCANCE DECLARADO: graba en vídeo lo que hace el banco de navegador, sobre el
   paquete tal como se entrega y abierto con file://. El cielo se orienta
   ARRASTRANDO y los patrones se señalan pulsando: no se inyecta cámara, no se
   acelera nada y no hay montaje. Es Chromium automatizado en un contenedor
   Linux: NO es un teléfono real, ni un lector de pantalla, ni HUMAN QA.

   PW_CHROMIUM=/ruta/al/chromium node pruebas/recorrido-video.js                */
const { chromium } = require('playwright');
const path = require('path');
const fs = require('fs');
const { enPantalla, pistaActual, puntoQueIdentifica, seguirPista,
        orientarHastaVer } = require('./ayudantes.js');

const RAIZ = path.resolve(__dirname, '..');
const URL = 'file://' + path.join(RAIZ, 'index.html');
const DESTINO_VIDEO = path.join(RAIZ, 'video');
const EXE = process.env.PW_CHROMIUM;

/* Pausas de lectura: el vídeo es para mirarlo, no para medir tiempos. */
const LEER = 1400;

async function centro(page) {
  return await page.evaluate(() => {
    const r = document.getElementById('lienzo').getBoundingClientRect();
    return { x: r.left + r.width / 2, y: r.top + r.height / 2 };
  });
}

async function recorrido(browser, w, h, nombre) {
  const ctx = await browser.newContext({
    viewport: { width: w, height: h }, deviceScaleFactor: 1,
    recordVideo: { dir: DESTINO_VIDEO, size: { width: w, height: h } }
  });
  const page = await ctx.newPage();
  const bitacora = [];
  const anota = async (q) => {
    bitacora.push({ paso: q, objetivo: (await pistaActual(page)).texto.slice(0, 90) });
  };
  await page.goto(URL);
  await page.waitForTimeout(LEER);

  /* 1 · la portada no nombra nada de lo que hay que encontrar */
  await page.click('#btn-empezar');
  await page.waitForTimeout(LEER);
  await anota('entrada: primera pista, sin nombres');

  /* 2 · orientar arrastrando y encontrar el cinturón */
  const cj = await centro(page);
  await orientarHastaVer(page, 'Ori', 22);
  await page.waitForTimeout(600);
  const p1 = await puntoQueIdentifica(page, 'Ori');
  if (!p1) throw new Error('no se ve el cinturón después de orientar');
  await page.mouse.move(p1.x, p1.y);
  await page.waitForTimeout(500);
  await page.mouse.click(p1.x, p1.y);
  await page.waitForTimeout(LEER);
  await page.click('#btn-revelar');
  await page.waitForTimeout(LEER);
  await anota('Orión encontrada señalando el cinturón');

  /* 3 · la ficha: se acopla al lado que no tapa el hallazgo */
  await page.click('#btn-saber-mas');
  await page.waitForTimeout(LEER + 600);
  await page.click('#btn-cerrar-panel');
  await page.waitForTimeout(800);

  /* 4 · seguir la pista medida: Can Mayor y Can Menor, arrastrando */
  await page.click('#btn-continuar-pista');
  await page.waitForTimeout(LEER);
  const s1 = await seguirPista(page, cj);
  await page.waitForTimeout(800);
  await anota('salto 1: ' + s1.abbr + ' → ' + s1.encontrada);
  await page.click('#btn-continuar-pista');
  await page.waitForTimeout(900);
  const s2 = await seguirPista(page, cj);
  await page.waitForTimeout(800);
  await anota('salto 2: ' + s2.abbr + ' → ' + s2.encontrada);

  /* 5 · fuera de orden: Tauro, que no es lo que se pedía */
  await page.click('#btn-continuar-pista');
  await page.waitForTimeout(900);
  const pedido = await pistaActual(page);
  await orientarHastaVer(page, 'Tau', 7, 16);
  let pT = await puntoQueIdentifica(page, 'Tau');
  if (!pT) { await orientarHastaVer(page, 'Tau', 1, 8); pT = await puntoQueIdentifica(page, 'Tau'); }
  let fueraDeOrden = null;
  if (pT) {
    await page.mouse.click(pT.x, pT.y);
    await page.waitForTimeout(LEER);
    fueraDeOrden = await page.evaluate(() => (IG_DEBUG.estado.localizada || {}).abbr || null);
    if (fueraDeOrden === 'Tau') { await page.click('#btn-revelar'); await page.waitForTimeout(LEER); }
  }
  bitacora.push({ paso: 'fuera de orden: se pedía ' + pedido.abbr + ' y se encuentra ' + fueraDeOrden });

  /* 6 · la capa de hallazgos y el cuaderno */
  await page.click('#btn-capa');
  await page.waitForTimeout(LEER);
  await page.click('#btn-cuaderno');
  await page.waitForTimeout(LEER + 400);
  const vuelta = await page.evaluate(() => {
    const f = [...document.querySelectorAll('.ig-cuaderno-fila')][0];
    const b = [...f.querySelectorAll('button')].find(x => /Volver a donde|Back to where/.test(x.textContent));
    const nombre = f.querySelector('.ig-cuaderno-nombre').textContent;
    b.click();
    return nombre;
  });
  await page.waitForTimeout(LEER + 600);
  bitacora.push({ paso: 'cuaderno: vuelta a donde se encontró ' + vuelta });

  /* 7 · sólo con teclado: la marca del centro aparece ahora, no antes */
  await page.evaluate(() => document.getElementById('escenario').focus());
  for (const k of ['ArrowLeft', 'ArrowLeft', 'ArrowUp']) {
    await page.keyboard.press(k);
    await page.waitForTimeout(350);
  }
  await page.waitForTimeout(LEER);
  const fin = await page.evaluate(() => ({
    descubiertas: Object.keys(IG_DEBUG.estado.descubiertas),
    centro: IG_DEBUG.estado.tecladoActivo
  }));
  bitacora.push({ paso: 'teclado: marca central ' + (fin.centro ? 'visible' : 'no visible'),
                  encontradas: fin.descubiertas.join(', ') });
  await page.waitForTimeout(900);
  await ctx.close();                                /* cerrar escribe el vídeo */

  const grabados = fs.readdirSync(DESTINO_VIDEO).filter(f => /\.webm$/.test(f))
    .map(f => ({ f, t: fs.statSync(path.join(DESTINO_VIDEO, f)).mtimeMs }))
    .sort((a, b) => b.t - a.t);
  const destino = path.join(DESTINO_VIDEO, nombre);
  if (fs.existsSync(destino)) fs.unlinkSync(destino);
  fs.renameSync(path.join(DESTINO_VIDEO, grabados[0].f), destino);
  return { nombre, bytes: fs.statSync(destino).size, bitacora, encontradas: fin.descubiertas };
}

(async () => {
  fs.mkdirSync(DESTINO_VIDEO, { recursive: true });
  const browser = await chromium.launch(EXE ? { executablePath: EXE } : {});
  const hechos = [];
  hechos.push(await recorrido(browser, 1440, 900, 'recorrido-1440.webm'));
  hechos.push(await recorrido(browser, 390, 844, 'recorrido-390.webm'));
  await browser.close();
  const resumen = {
    declaracion: 'Vídeo del recorrido REAL grabado por el propio navegador durante la prueba. El cielo se orienta ' +
      'arrastrando y los patrones se señalan pulsando; no se inyecta cámara, no se acelera y no hay montaje. ' +
      'Chromium automatizado en contenedor Linux: el de 390 px NO es un teléfono real.',
    fecha: new Date().toISOString().slice(0, 10),
    grabaciones: hechos
  };
  fs.writeFileSync(path.join(DESTINO_VIDEO, 'RECORRIDO.json'), JSON.stringify(resumen, null, 2));
  hechos.forEach(h => {
    console.log(`✔ ${h.nombre} · ${(h.bytes / 1048576).toFixed(2)} MB · encontradas: ${h.encontradas.join(', ')}`);
    h.bitacora.forEach(b => console.log('   · ' + b.paso + (b.objetivo ? ' — «' + b.objetivo + '»' : '')));
  });
  console.log('\nVídeo del recorrido real. No es HUMAN QA ni una prueba en teléfono físico.');
})().catch(e => { console.error('ERROR VÍDEO:', e); process.exit(1); });
