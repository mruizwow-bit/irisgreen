#!/usr/bin/env node
const fs=require('fs'),vm=require('vm'),path=require('path');
const ROOT=path.resolve(__dirname,'..'), CFG=require(path.join(ROOT,'js','config.js'));
global.window={IG_CONFIG:CFG};const E=require(path.join(ROOT,'js','esfera.js'));
function load(){const c={window:{}};vm.createContext(c);vm.runInContext(fs.readFileSync(path.join(ROOT,'datos','cielo3d.js'),'utf8'),c);return c.window.IG3D}
const data=load(),sky=E.construirCielo(data),W=1440,H=900,C={x:W/2,y:H/2};
const coord=v=>E.aCoordenadas(v),cam=v=>{const q=coord(v);return {ra:q.ra,dec:q.dec,fov:60}};
const avg=vs=>E.unitario(vs.reduce((s,v)=>({x:s.x+v.x,y:s.y+v.y,z:s.z+v.z}),{x:0,y:0,z:0}));
function dirs(k){
 const out=[];k.observables.forEach(i=>out.push({kind:'point',v:k.puntos[i].v,index:i}));
 k.aristas.forEach((a,i)=>{if(k.puntos[a[0]].observable&&k.puntos[a[1]].observable)out.push({kind:'edge',v:avg([k.puntos[a[0]].v,k.puntos[a[1]].v]),index:i})});
 for(let i=0;i<k.puntos.length;i++){if(!k.puntos[i].observable)continue;const ns=k.vecinosObs[i]||[];
   for(let x=0;x<ns.length;x++)for(let y=x+1;y<ns.length;y++){const j=ns[x],l=ns[y];out.push({kind:'triple',v:avg([k.puntos[i].v,k.puntos[j].v,k.puntos[l].v]),index:[i,j,l]})}}
 return out;
}
const overlaps=[], per=[];
for(const k of sky.constelaciones){
 let n=0,correct=0,ambTarget=0,other=0,none=0; const pairs={};
 for(const d of dirs(k)){n++;const r=E.examinar(sky,cam(d.v),W,H,[],C,{});
   if(r.resultado==='unico'){
     if(r.mejor.abbr===k.abbr) correct++;
     else{other++;const key=r.mejor.abbr;pairs[key]=(pairs[key]||0)+1;if(overlaps.length<500)overlaps.push({target:k.abbr,winner:key,kind:d.kind,index:d.index,winner_points:r.mejor.dentro})}
   }else if(r.resultado==='ambiguo'&&r.plausibles.some(x=>x.abbr===k.abbr)){ambTarget++;r.plausibles.forEach(x=>{if(x.abbr!==k.abbr){pairs[x.abbr]=(pairs[x.abbr]||0)+1}})}
   else none++;
 }
 per.push({abbr:k.abbr,samples:n,unique_correct:correct,ambiguous_with_target:ambTarget,unique_other:other,none,competitors:pairs});
}
const grid={samples:0,none:0,unique:0,ambiguous:0,max_candidates:0,pairs:{}}, examples=[];
for(let dec=-80;dec<=80;dec+=5)for(let ra=0;ra<24;ra+=0.5){
 const r=E.examinar(sky,{ra,dec,fov:60},W,H,[],C,{});
 grid.samples++; if(r.resultado==='ninguno')grid.none++; else if(r.resultado==='unico')grid.unique++; else{grid.ambiguous++;const ps=r.plausibles.map(x=>x.abbr).sort();const key=ps.join('+');grid.pairs[key]=(grid.pairs[key]||0)+1;examples.push({ra,dec,pairs:ps,detail:r.plausibles})}
 grid.max_candidates=Math.max(grid.max_candidates,r.candidatas||0);
}
const report={
 schema:'iris-green.sky-r03.ambiguity-88.r01',aperture_radius_deg:CFG.EVIDENCIA.apertura_radio_grados,
 semantic_default:CFG.EVIDENCIA.minimo_puntos,advantage_ratio:CFG.EVIDENCIA.ventaja_minima,
 grid,grid_ambiguity_rate:+(grid.ambiguous/grid.samples).toFixed(6),grid_examples:examples,
 targeted_summary:{constellations:88,total_samples:per.reduce((s,x)=>s+x.samples,0),
  unique_correct:per.reduce((s,x)=>s+x.unique_correct,0),ambiguous_with_target:per.reduce((s,x)=>s+x.ambiguous_with_target,0),
  unique_other:per.reduce((s,x)=>s+x.unique_other,0),none:per.reduce((s,x)=>s+x.none,0),
  constellations_with_unique_correct:per.filter(x=>x.unique_correct>0).length},
 targeted_by_constellation:per,
 overlap_samples:overlaps,
 decision:'KEEP_6_DEG_PENDING_HUMAN_QA',
 interpretation:'Grid ambiguity is rare. Targeted unique-other samples are declared overlap competition, not automatically false positives: the same 6° cone can contain stronger evidence for a neighbouring real figure.'
};
fs.writeFileSync(path.join(ROOT,'evidence','AMBIGUITY_88_REPORT.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({grid:report.grid,rate:report.grid_ambiguity_rate,targeted_summary:report.targeted_summary,
 constellations_with_other:per.filter(x=>x.unique_other).map(x=>({abbr:x.abbr,n:x.unique_other,competitors:x.competitors}))},null,2));
