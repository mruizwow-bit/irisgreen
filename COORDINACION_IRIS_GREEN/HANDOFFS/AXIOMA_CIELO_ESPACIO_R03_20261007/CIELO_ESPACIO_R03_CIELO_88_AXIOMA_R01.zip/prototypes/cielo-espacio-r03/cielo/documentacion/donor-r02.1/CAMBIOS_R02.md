# Cambios de R01 (piloto) a R02 (ampliación)

2026-10-06. Qué se ha tocado, por qué, y dónde se comprueba.

## 1. Las diez correcciones de la orden, una por una

### C3D-01 · evidencia independiente del viewport

Ya venía resuelto en el piloto y **se vuelve a comprobar aquí con las 12**: la
tolerancia de entrada (`TOLERANCIA_ENTRADA_PX`, 24 px, comodidad para señalar)
no aporta ni un punto de evidencia; la evidencia es un cono angular de 6° de
radio que no cambia con el acercamiento.

- `U03`: misma dirección del cielo y misma cámara → misma apertura, misma
  evidencia y misma decisión a 320/390/1440.
- `U15` (nuevo): las 12 se identifican y la decisión es idéntica en los tres
  anchos. 71 punterías probadas.
- `N02`: lo mismo en el navegador real.

### C3D-02 · ambigüedad · **cambio de verdad**

Antes, cuando dos patrones empataban en evidencia, se desempataba por
**distancia en píxeles** al punto pulsado. Eso dependía del tamaño de la
pantalla: la misma pulsación sobre el mismo cielo podía decidir distinto en un
móvil y en un portátil. Se ha quitado.

Ahora `examinar` sólo resuelve si un candidato tiene una **ventaja clara en
evidencia** (`ventaja_minima`, 1.5×). Si no la tiene:

- no se identifica nada —no hay botón de revelar—;
- se devuelven los candidatos plausibles descritos por **su sitio en el cielo**:
  un octante (`octanteCeleste`) y una separación angular, los dos calculados
  sobre direcciones del cielo y por tanto iguales en cualquier pantalla;
- la interfaz ofrece esas opciones **sin nombrar ninguna constelación ni ninguna
  de sus estrellas** («El grupo abajo a la izquierda, a unos 3,4°»);
- la orientación no se mueve.

Del motor desapareció el campo `distancia`: no queda ni la tentación.

- `U14`: dos patrones con la misma evidencia en la misma zona → decisión
  idéntica a 320/390/1440, sin identificar ninguno y con los dos candidatos
  descritos por su sitio.
- `N15`: en el navegador, con dos candidatos empatados no se revela nada, las
  opciones no sueltan ningún nombre, la cámara no se toca, y al elegir una se
  localiza esa.

**Dato honesto:** con estas 12 constelaciones y un cono de 6° de radio, la
ambigüedad **no se puede provocar**. Se barrió el cielo entero (24 h × 110° de
declinación × tres aperturas) y no hay ni un punto con dos patrones sostenidos.
Por eso `U14` usa un cielo de prueba y `N15` intercepta la respuesta del motor
en la página. Está anotado en `NOTAS_DE_PRUEBAS.md`.

### C3D-03 · foco y modalidad · **cambio de verdad**

Antes bastaba que el foco llegara al escenario —aunque lo moviera el programa—
para que apareciera la marca del centro. Convertía el centro en la metáfora.

Ahora hay una sola variable que recuerda **la última entrada real**
(`ultimaEntrada`: puntero o teclado). La marca central se dibuja sólo si la
última entrada fue de teclado. Un `focus()` del programa no la enciende, y
volver al ratón la apaga. La prioridad es: pulsar donde se mira; el teclado como
alternativa completa; el centro como apoyo del teclado.

- `N17`: no aparece al entrar con ratón, ni al pulsar, ni cuando el programa
  mueve el foco al botón de examinar; aparece con una flecha real; se apaga al
  volver al ratón.
- `N06`: el recorrido entero sólo con teclado sigue funcionando.

### C3D-04 · pinza → un dedo

El oracle se ha rehecho para comprobar lo que pedía la orden, no lo que era
cómodo de medir: el puntero que sobrevive es **uno de los dos que ya estaban**
—no se cambia de dedo para que cuadre—, su desplazamiento es **pequeño y no
nulo** (1 px real) y la cámara no salta: 1 px de dedo mueve el cielo 1,0 px.

- `N05`: punteros 2 y 3 → 2, deriva de la pinza 12 px, sin salto al levantar, y
  el final del gesto no selecciona nada ni deja punteros colgados.

### C3D-05 · selección visible · **comprobación nueva**

Un patrón no se localiza por una fracción insuficiente de estrellas, y lo que se
dibuja tiene que ser lo mismo que sostuvo la decisión. Para poder comprobarlo
desde fuera, el dibujante registra lo último que ha pintado
(`IG_ESCENA.ultimoDibujo()`), sin que ese registro decida nada.

- `N21`: las estrellas que sostienen la decisión son **exactamente** las que se
  marcan en el lienzo, y al revelar se dibuja la figura de esa misma
  constelación. Señalar, marcar y revelar miran una sola observabilidad.
- `U04`, `U06`, `N03`: ocultar evidencia no rebaja el mínimo.

### C3D-06 · fichas async · **comprobación nueva**

- `N08`: una ficha pedida y abandonada al salir de la pantalla no abre nada
  cuando su carga llega tarde.
- `N08b` (nuevo): y **sin salir de la zona** tampoco. Se piden dos fichas
  seguidas; cuando la carga de la primera llega tarde, manda la última pedida.

### C3D-07 · persistencia · **comprobación nueva**

- `N18`: recargando, el progreso vuelve y el sitio del hallazgo es el mismo.
  Con la memoria corrupta, de una versión futura, con una constelación inventada
  o con una cámara imposible, la escena abre igual y nada de eso se cuela: lo
  que no se reconoce se descarta en vez de adivinarlo.
- La clave de guardado pasa a `iris-green.cielo-3d.r02`, para no mezclar el
  progreso de este paquete con el del piloto.

### C3D-08 · paneles · **cambio de verdad**

La ficha ya no cae siempre a la derecha. En pantalla ancha se acopla **al lado
opuesto a lo que se acaba de observar**; el lado se decide al abrirla y se
conserva mientras está abierta, para que no salte de sitio cuando el cielo se
mueve por detrás. En pantalla estrecha no se pone al lado: el cielo se queda
arriba a ancho completo y la ficha va debajo.

- `N16`: con el hallazgo en la mitad derecha, la ficha se acopla a la izquierda
  y no cae encima; abrirla y cerrarla no cambia la orientación ni el campo.
- `N16b`: a 390 px el cielo se queda arriba y la ficha debajo.

### C3D-09 · pistas · **cambio de verdad**

Las pistas ya no están escritas a mano en el programa. Salen de los datos, y los
datos las derivan de medidas sobre el catálogo: cuántas estrellas claras tiene la
figura, si una destaca mucho sobre las demás, qué forma hace (alineada, apretada,
repartida, cerrada), cuánto mide, y desde qué estrella ya conocida se salta,
cuántos grados y en qué dirección de pantalla.

Ninguna pista cita una magnitud. El brillo se dice como se ve: «una mucho más
clara que las demás». Las distancias se dicen en puños con el brazo estirado
(unos 10°), y esa convención se declara como lo que es: una costumbre
observacional, no un dato del catálogo.

- `U13`: las 12 pistas no nombran su objetivo, no nombran ninguna de sus
  estrellas y no citan magnitudes. La pista de salto sólo nombra la estrella de
  la que se parte, y su respaldo —cuando ese patrón todavía no se ha
  encontrado— no nombra ninguna.
- `U12`: las separaciones y direcciones declaradas se vuelven a medir, y la
  dirección que dice la pista es la que se ve en pantalla.

### C3D-10 · continuidad de foco

- `N09`: el foco va a un destino visible al cambiar de pantalla y sobrevive al
  cambio de tamaño con la ficha abierta.
- `N19`: cambiar de idioma con el teclado conserva orientación, hallazgos y el
  foco en el botón que se pulsó.

## 2. Lo demás que ha cambiado

| Cambio | Por qué |
|---|---|
| 12 constelaciones en vez de 2 | la orden pedía 8+ conectadas, con Orión y Tauro |
| El recorrido sale de `orden_saltos` en los datos | antes era `PILOTO = ['Ori','Tau']` escrito en la interfaz. Ahora la interfaz no sabe qué constelaciones hay: lo lee |
| Cuaderno de hallazgos | lo pedía el KEEP de la orden. Lista lo encontrado, dice desde qué orientación se vio cada cosa y vuelve a esa misma vista, sin recalcular encuadre |
| `datos/cielo3d.js` incorpora `rasgos`, `ancla`, `salto`, `pista` por constelación, más `orden_saltos`, `regla_orden_saltos` y `convencion_distancias` | para que las pistas y el recorrido sean datos medidos y declarados, no texto |
| `ancla` lleva dos índices con nombres distintos (`estrella_indice`, `punto_indice`) | confundirlos fue un error de esta misma sesión: el nombre lo evita |
| `pruebas/ayudantes.js` | el mismo recorrido que graba el vídeo es el que comprueba el banco |
| Se retira `COMPARACION_CON_2D.md` | la comparación está cerrada por decisión de María. No se repite |

## 3. La regla del recorrido, declarada

El orden de los saltos no es el árbol más corto: es el más seguible.

    coste = separación angular + 12° por magnitud del ancla de destino

Prefiere saltos cortos hacia estrellas claras, porque se salta a lo que se ve.
Está en los datos, en `regla_orden_saltos`, y el resultado es:

Orión → Can Mayor → Can Menor → Géminis → Auriga → Tauro → Perseo → Liebre →
Aries → Triángulo → Piscis → Unicornio.

Ninguno de los once saltos pasa de 40°; el mayor mide 34,2°.
